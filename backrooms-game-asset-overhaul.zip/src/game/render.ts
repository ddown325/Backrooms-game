import type { Level, SpriteDef, Tex } from "./types";
import type { ThemeTex } from "./textures";
import type { Lighting } from "./lighting";
import { LM } from "./lighting";
import type { LevelDef } from "./levels";

export const WALL_H = 1;

export interface View {
  x: number;
  y: number;
  a: number;
  pitch: number;
  eye: number;
  fov: number;
  brightness: number;
  lampScale: number;
  ambScale: number;
  torch: number;
  time: number;
}

export interface SpriteInst {
  x: number;
  y: number;
  def: SpriteDef;
  frame: number;
  flip: boolean;
  alpha: number;
  glow: number; // added on top of the def's own glow
  scale: number;
  zoff: number;
  flash: number;
}

export interface CenterHit {
  cell: number;
  face: number;
  dist: number;
  wallX: number;
  z: number;
}

const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5].map((v) => (v / 16 - 0.47) * 1.4);

export class Renderer {
  readonly W = 480;
  readonly H = 270;
  frame: ImageData;
  private buf32: Uint32Array;
  private buf8: Uint8ClampedArray;
  private zbuf = new Float32Array(this.W);
  private wallTop = new Int16Array(this.W);
  private wallBot = new Int16Array(this.W);
  private torchMask: Float32Array;
  private lut = new Uint8Array(1536);
  centerHit: CenterHit = { cell: -1, face: 0, dist: 99, wallX: 0, z: 0 };

  private level!: Level;
  private light!: Lighting;
  private def!: LevelDef;
  private theme!: ThemeTex;
  private floorK!: Uint8Array;

  constructor(private ctx: CanvasRenderingContext2D) {
    this.frame = ctx.createImageData(this.W, this.H);
    this.buf32 = new Uint32Array(this.frame.data.buffer);
    this.buf8 = this.frame.data;
    for (let i = 0; i < this.lut.length; i++) {
      const x = i / 255;
      const y = (1 - Math.exp(-1.45 * x)) / (1 - Math.exp(-1.45));
      this.lut[i] = Math.min(255, Math.pow(Math.min(y, 1.2), 0.96) * 255);
    }
    this.torchMask = new Float32Array(this.W * this.H);
    const { W, H } = this;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const dx = (x - W / 2) / (W * 0.34), dy = (y - H * 0.56) / (H * 0.46);
      const r2 = dx * dx + dy * dy;
      const m = Math.max(0, 1 - r2);
      this.torchMask[y * W + x] = m * m * (0.7 + 0.3 * m);
    }
  }

  setLevel(level: Level, light: Lighting, def: LevelDef, theme: ThemeTex) {
    this.level = level;
    this.light = light;
    this.def = def;
    this.theme = theme;
    this.floorK = level.floor;
  }

  render(v: View, sprites: SpriteInst[]) {
    const { W, H, level: lv, def, theme, light } = this;
    const n = lv.n, map = lv.map;
    const buf32 = this.buf32, buf8 = this.buf8, lut = this.lut, tmask = this.torchMask;
    const lm = light.lm, lw = light.lw, lampCur = light.lampCur;
    const dyn = light.dyn;
    const nd = dyn.length;
    const tint = def.tint;
    const fogR = def.fog[0] * 255, fogG = def.fog[1] * 255, fogB = def.fog[2] * 255, fd = def.fogDensity;
    const bright = v.brightness * 1.0;
    const amb = def.ambient * v.ambScale, lampS = v.lampScale;
    const torchP = v.torch;

    const pl = Math.tan(v.fov / 2);
    const f = (W / 2) / pl;
    const dirX = Math.cos(v.a), dirY = Math.sin(v.a);
    const planeX = -dirY * pl, planeY = dirX * pl;
    const horizon = H / 2 + v.pitch * H;
    const eye = v.eye;
    const px = v.x, py = v.y;
    const wallAD = theme.wallA, wallBD = theme.wallB;
    const decals = lv.decals;
    const zbuf = this.zbuf, wallTop = this.wallTop, wallBot = this.wallBot;

    /* ------------------------------------------------ walls */
    for (let x = 0; x < W; x++) {
      const camX = (2 * x) / W - 1;
      const rdx = dirX + planeX * camX, rdy = dirY + planeY * camX;
      let mx = px | 0, my = py | 0;
      const ddx = rdx === 0 ? 1e30 : Math.abs(1 / rdx), ddy = rdy === 0 ? 1e30 : Math.abs(1 / rdy);
      const sx = rdx < 0 ? -1 : 1, sy = rdy < 0 ? -1 : 1;
      let tx = rdx < 0 ? (px - mx) * ddx : (mx + 1 - px) * ddx;
      let ty = rdy < 0 ? (py - my) * ddy : (my + 1 - py) * ddy;
      let side = 0, hitV = 0;
      for (let i = 0; i < 96; i++) {
        if (tx < ty) { tx += ddx; mx += sx; side = 0; } else { ty += ddy; my += sy; side = 1; }
        if (mx < 0 || my < 0 || mx >= n || my >= n) { hitV = 1; break; }
        hitV = map[my * n + mx];
        if (hitV > 0) break;
      }
      let perp = side === 0 ? tx - ddx : ty - ddy;
      if (perp < 0.02) perp = 0.02;
      zbuf[x] = perp;
      const lineTop = horizon - (f * (WALL_H - eye)) / perp;
      const lineBot = horizon + (f * eye) / perp;
      let y0 = Math.ceil(lineTop - 0.5), y1 = Math.floor(lineBot - 0.5);
      if (y0 < 0) y0 = 0;
      if (y1 > H - 1) y1 = H - 1;
      wallTop[x] = y0;
      wallBot[x] = y1 + 1;

      let wx = side === 0 ? py + perp * rdy : px + perp * rdx;
      wx -= Math.floor(wx);
      if (side === 0 && rdx > 0) wx = 1 - wx;
      if (side === 1 && rdy < 0) wx = 1 - wx;
      const face = side === 0 ? (sx > 0 ? 0 : 1) : sy > 0 ? 2 : 3;
      const cellI = my * n + mx;

      if (x === W >> 1) {
        const ch = this.centerHit;
        ch.cell = cellI; ch.face = face; ch.dist = perp; ch.wallX = 1 - wx;
        ch.z = eye + ((horizon - H / 2) * perp) / f;
      }

      const tex = hitV === 1 ? wallAD : wallBD;
      const tw = tex.w, th = tex.h, td = tex.d;
      const texX = Math.min(tw - 1, (wx * tw) | 0);
      const dl = decals[cellI * 4 + face];

      // light on this wall column, sampled just in front of the face
      const hx = px + perp * rdx - (side === 0 ? sx * 0.27 : 0), hy = py + perp * rdy - (side === 1 ? sy * 0.27 : 0);
      let lmv = 0;
      {
        const fx = hx * LM - 0.5, fy = hy * LM - 0.5;
        let ix = Math.floor(fx), iy = Math.floor(fy);
        const ax = fx - ix, ay = fy - iy;
        if (ix < 0) ix = 0; if (iy < 0) iy = 0; if (ix > lw - 2) ix = lw - 2; if (iy > lw - 2) iy = lw - 2;
        const i0 = iy * lw + ix;
        lmv = (lm[i0] * (1 - ax) + lm[i0 + 1] * ax) * (1 - ay) + (lm[i0 + lw] * (1 - ax) + lm[i0 + lw + 1] * ax) * ay;
      }
      let baseL = amb + lmv * lampS;
      for (let k = 0; k < nd; k++) {
        const d = dyn[k];
        const ddd = Math.hypot(hx - d.x, hy - d.y) / d.r;
        if (ddd < 1) baseL += d.i * (1 - ddd * ddd) * (1 - ddd * ddd);
      }
      if (side === 1) baseL *= 0.9;
      const tAtt = (torchP * 1.5) / (1 + 0.16 * perp * perp);
      const fw = 1 - Math.exp(-perp * fd);
      const invLen = 1 / (lineBot - lineTop);

      for (let y = y0; y <= y1; y++) {
        const t = (y + 0.5 - lineTop) * invLen;
        let ty2 = (t * th) | 0;
        if (ty2 >= th) ty2 = th - 1;
        const ti = (ty2 * tw + texX) * 4;
        let r = td[ti], g = td[ti + 1], b = td[ti + 2];
        let L = baseL * (0.78 + 0.4 * (1 - t));
        if (t > 0.86) L *= 1 - (t - 0.86) * 1.4;
        else if (t < 0.07) L *= 0.88 + t * 1.7;
        if (dl !== undefined) {
          const z = WALL_H * (1 - t);
          for (let k = 0; k < dl.length; k++) {
            const d = dl[k];
            const wd = 1 - wx;
            if (wd < d.u0 || wd > d.u1 || z < d.z0 || z > d.z1) continue;
            const dt = d.tex;
            const du = ((wd - d.u0) / (d.u1 - d.u0)) * dt.w | 0;
            const dv = ((d.z1 - z) / (d.z1 - d.z0)) * dt.h | 0;
            const di = (Math.min(dt.h - 1, dv) * dt.w + Math.min(dt.w - 1, du)) * 4;
            const a = dt.d[di + 3] / 255;
            if (a > 0.02) {
              r += (dt.d[di] - r) * a; g += (dt.d[di + 1] - g) * a; b += (dt.d[di + 2] - b) * a;
              L += d.glow * a * (0.4 + 0.6 * Math.min(1, lampS + 0.3));
            }
          }
        }
        L += tmask[y * W + x] * tAtt * (0.85 + 0.3 * (1 - t));
        let kr = r * L * tint[0], kg = g * L * tint[1], kb = b * L * tint[2];
        if (fw > 0.003) {
          const fl = (L > 1 ? 1 : L) * 0.85 + 0.15;
          kr = kr * (1 - fw) + fogR * fl * fw; kg = kg * (1 - fw) + fogG * fl * fw; kb = kb * (1 - fw) + fogB * fl * fw;
        }
        const dd = BAYER[(x & 3) | ((y & 3) << 2)];
        let ir = (kr * bright + dd) | 0, ig = (kg * bright + dd) | 0, ib = (kb * bright + dd) | 0;
        if (ir < 0) ir = 0; else if (ir > 1535) ir = 1535;
        if (ig < 0) ig = 0; else if (ig > 1535) ig = 1535;
        if (ib < 0) ib = 0; else if (ib > 1535) ib = 1535;
        buf32[y * W + x] = 0xff000000 | (lut[ib] << 16) | (lut[ig] << 8) | lut[ir];
      }
    }

    /* ------------------------------------------------ floor + ceiling */
    const floorA = theme.floorA, waterFrames = theme.floorB;
    const frameIdx = ((v.time * 2.5) | 0) % waterFrames.length;
    const floorB = waterFrames[frameIdx];
    const ceilT = theme.ceil, ceilLamp = theme.ceilLamp;
    const isWater = def.altSurface === "water";
    for (let y = 0; y < H; y++) {
      const p = y + 0.5 - horizon;
      if (p > -0.3 && p < 0.3) continue;
      const isFloor = p > 0;
      const rowDist = (f * (isFloor ? eye : WALL_H - eye)) / Math.abs(p);
      const fw = 1 - Math.exp(-rowDist * fd);
      const tAtt = (torchP * (isFloor ? 1.5 : 0.8)) / (1 + 0.16 * rowDist * rowDist);
      let wx = px + rowDist * (dirX - planeX), wy = py + rowDist * (dirY - planeY);
      const stX = (rowDist * 2 * planeX) / W, stY = (rowDist * 2 * planeY) / W;
      const rowOff = y * W;
      for (let x = 0; x < W; x++, wx += stX, wy += stY) {
        if (isFloor ? y < wallBot[x] : y >= wallTop[x]) continue;
        const cx = wx | 0, cy = wy | 0;
        if (wx < 0 || wy < 0 || cx >= n || cy >= n) continue;
        const ci = cy * n + cx;
        // bilinear lightmap
        const fx = wx * LM - 0.5, fy = wy * LM - 0.5;
        let ix = fx | 0, iy = fy | 0;
        const ax = fx - ix, ay = fy - iy;
        if (ix < 0) ix = 0; if (iy < 0) iy = 0; if (ix > lw - 2) ix = lw - 2; if (iy > lw - 2) iy = lw - 2;
        const i0 = iy * lw + ix;
        const lmv = (lm[i0] * (1 - ax) + lm[i0 + 1] * ax) * (1 - ay) + (lm[i0 + lw] * (1 - ax) + lm[i0 + lw + 1] * ax) * ay;
        let r: number, g: number, b: number, L: number;
        if (isFloor) {
          const k = this.floorK[ci];
          const tex: Tex = k ? floorB : floorA;
          const tu = ((wx - cx) * tex.w) | 0, tv = ((wy - cy) * tex.h) | 0;
          const ti = (tv * tex.w + tu) * 4;
          r = tex.d[ti]; g = tex.d[ti + 1]; b = tex.d[ti + 2];
          L = amb + lmv * lampS * (k && isWater ? 1.25 : 1);
          // soft pool of light under the lamp itself
        } else {
          const lc = lampCur[ci];
          const lampCell = lc >= 0;
          const tex: Tex = lampCell ? ceilLamp : ceilT;
          const tu = ((wx - cx) * tex.w) | 0, tv = ((wy - cy) * tex.h) | 0;
          const ti = (tv * tex.w + tu) * 4;
          r = tex.d[ti]; g = tex.d[ti + 1]; b = tex.d[ti + 2];
          if (lampCell && tex.d[ti + 3] === 254) {
            L = 0.12 + lc * 1.15 * (0.4 + 0.6 * Math.min(1, lampS + 0.2));
          } else {
            L = amb * 0.7 + lmv * lampS * 0.3 + (lampCell ? lc * 0.1 * lampS : 0);
          }
        }
        for (let k = 0; k < nd; k++) {
          const d = dyn[k];
          const ddd = Math.hypot(wx - d.x, wy - d.y) / d.r;
          if (ddd < 1) L += d.i * (1 - ddd * ddd) * (1 - ddd * ddd) * (isFloor ? 1 : 0.5);
        }
        L += tmask[rowOff + x] * tAtt;
        let kr = r * L * tint[0], kg = g * L * tint[1], kb = b * L * tint[2];
        if (fw > 0.003) {
          const fl = (L > 1 ? 1 : L) * 0.85 + 0.15;
          kr = kr * (1 - fw) + fogR * fl * fw; kg = kg * (1 - fw) + fogG * fl * fw; kb = kb * (1 - fw) + fogB * fl * fw;
        }
        const dd = BAYER[(x & 3) | ((y & 3) << 2)];
        let ir = (kr * bright + dd) | 0, ig = (kg * bright + dd) | 0, ib = (kb * bright + dd) | 0;
        if (ir < 0) ir = 0; else if (ir > 1535) ir = 1535;
        if (ig < 0) ig = 0; else if (ig > 1535) ig = 1535;
        if (ib < 0) ib = 0; else if (ib > 1535) ib = 1535;
        buf32[rowOff + x] = 0xff000000 | (lut[ib] << 16) | (lut[ig] << 8) | lut[ir];
      }
    }

    /* ------------------------------------------------ sprites */
    const invDet = 1 / (planeX * dirY - dirX * planeY);
    const items: { s: SpriteInst; tX: number; tY: number }[] = [];
    for (const s of sprites) {
      const dx = s.x - px, dy = s.y - py;
      const tY = invDet * (-planeY * dx + planeX * dy);
      if (tY < 0.1 || tY > 30) continue;
      const tX = invDet * (dirY * dx - dirX * dy);
      if (Math.abs(tX / tY) > 1.5) continue;
      items.push({ s, tX, tY });
    }
    items.sort((a, b) => b.tY - a.tY);

    // contact shadows first, so every body sits on the floor
    for (const { s, tX, tY } of items) {
      if (!s.def.shadow || s.alpha < 0.2 || s.zoff > 0.05) continue;
      const scrX = (W / 2) * (1 + tX / tY);
      const rx = (f * s.def.w * s.scale * 0.55) / tY;
      const gy = horizon + (f * eye) / tY;
      const ry = Math.max(1.5, (f * eye * s.def.w * 0.3) / (tY * tY));
      const xa = Math.max(0, Math.floor(scrX - rx)), xb = Math.min(W - 1, Math.ceil(scrX + rx));
      const ya = Math.max(0, Math.floor(gy - ry)), yb = Math.min(H - 1, Math.ceil(gy + ry));
      for (let x = xa; x <= xb; x++) {
        if (tY >= zbuf[x]) continue;
        const ex = (x - scrX) / rx;
        for (let y = ya; y <= yb; y++) {
          const ey = (y - gy) / ry;
          const q = ex * ex + ey * ey;
          if (q >= 1) continue;
          const k = 1 - 0.55 * (1 - q) * s.alpha;
          const o = (y * W + x) * 4;
          buf8[o] *= k; buf8[o + 1] *= k; buf8[o + 2] *= k;
        }
      }
    }

    for (const { s, tX, tY } of items) {
      const def2 = s.def;
      const tex = def2.frames[Math.min(def2.frames.length - 1, s.frame)];
      const scrX = (W / 2) * (1 + tX / tY);
      const spW = (f * def2.w * s.scale) / tY, spH = (f * def2.h * s.scale) / tY;
      const bottomY = horizon - (f * (def2.elev + s.zoff - eye)) / tY;
      const topY = bottomY - spH;
      const xs = scrX - spW / 2;
      const xa = Math.max(0, Math.floor(xs)), xb = Math.min(W - 1, Math.ceil(xs + spW));
      const ya = Math.max(0, Math.floor(topY)), yb = Math.min(H - 1, Math.ceil(bottomY));
      if (xa > xb || ya > yb) continue;
      // lighting of this body
      let sL = amb + light.sample(s.x, s.y) * lampS;
      for (let k = 0; k < nd; k++) {
        const d = dyn[k];
        const ddd = Math.hypot(s.x - d.x, s.y - d.y) / d.r;
        if (ddd < 1) sL += d.i * (1 - ddd * ddd) * (1 - ddd * ddd);
      }
      const glow = def2.glow + s.glow;
      const tAtt = (torchP * 1.5) / (1 + 0.16 * tY * tY);
      const fw = 1 - Math.exp(-tY * fd);
      const invW = 1 / spW, invH = 1 / spH;
      const tw = tex.w, th = tex.h, td = tex.d;
      for (let x = xa; x <= xb; x++) {
        if (tY >= zbuf[x]) continue;
        let u = (x + 0.5 - xs) * invW;
        if (u < 0 || u >= 1) continue;
        if (s.flip) u = 1 - u;
        const texX = (u * tw) | 0;
        for (let y = ya; y <= yb; y++) {
          const vv = (y + 0.5 - topY) * invH;
          if (vv < 0 || vv >= 1) continue;
          const ti = (((vv * th) | 0) * tw + texX) * 4;
          const al = (td[ti + 3] / 255) * s.alpha;
          if (al < 0.03) continue;
          let L = sL * (0.85 + 0.2 * (1 - vv)) + tmask[y * W + x] * tAtt + glow;
          let r = td[ti], g = td[ti + 1], b = td[ti + 2];
          r = r * L * tint[0]; g = g * L * tint[1]; b = b * L * tint[2];
          if (fw > 0.003) {
            const fl = (L > 1 ? 1 : L) * 0.85 + 0.15;
            r = r * (1 - fw) + fogR * fl * fw; g = g * (1 - fw) + fogG * fl * fw; b = b * (1 - fw) + fogB * fl * fw;
          }
          r *= bright; g *= bright; b *= bright;
          let ir = r | 0, ig = g | 0, ib = b | 0;
          if (ir > 1535) ir = 1535; if (ig > 1535) ig = 1535; if (ib > 1535) ib = 1535;
          r = lut[ir]; g = lut[ig]; b = lut[ib];
          if (s.flash > 0) { r += (255 - r) * s.flash; g += (255 - g) * s.flash; b += (255 - b) * s.flash; }
          const o = (y * W + x) * 4;
          buf8[o] += (r - buf8[o]) * al;
          buf8[o + 1] += (g - buf8[o + 1]) * al;
          buf8[o + 2] += (b - buf8[o + 2]) * al;
        }
      }
    }

    this.ctx.putImageData(this.frame, 0, 0);
  }
}
