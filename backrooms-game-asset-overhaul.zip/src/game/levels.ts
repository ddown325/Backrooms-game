import type { Difficulty, ThemeId } from "./types";

export type TaskKind = "power" | "code" | "valves" | "keys" | "generator";
export type Surface = "carpet" | "concrete" | "metal" | "tile";

export interface RoomKind {
  type: string;
  label: string;
  weight: number;
}

export interface LevelDef {
  id: number;
  name: string;
  sub: string;
  theme: ThemeId;
  layout: "office" | "halls" | "maze" | "pool" | "plant";
  size: number;
  roomCount: number;
  roomMin: number;
  roomMax: number;
  wideChance: number;
  pillars: boolean;
  ambient: number;
  lampGain: number;
  lampRadius: number;
  lampMod: number;
  deadChance: number;
  flickerChance: number;
  tint: [number, number, number];
  fog: [number, number, number];
  fogDensity: number;
  surface: Surface;
  altSurface: Surface | "water";
  altRooms: string[]; // room types that use the alternate floor
  wallBRooms: string[];
  rooms: RoomKind[];
  props: string[];
  roomProps: Record<string, string[]>;
  propDensity: number;
  deco: string[];
  water: number;
  cells: number;
  notes: number;
  task: {
    kind: TaskKind;
    count: number;
    itemRooms: string[];
    deviceType: string;
    deviceLabel: string;
    exitLabel: string;
  };
  entities: { listener: boolean; crawler: number; warden: number; mannequin: number; hound: number; drowned: number; watcher: boolean };
  briefing: string;
  tagline: string;
}

export const DIFFICULTIES: Difficulty[] = [
  { id: 0, name: "Easy", desc: "Slower monsters, more supplies, longer grace.", drain: 0.7, speed: 0.85, grace: 80, supply: 1.4, extra: 0 },
  { id: 1, name: "Normal", desc: "The intended experience.", drain: 1, speed: 1, grace: 50, supply: 1, extra: 0 },
  { id: 2, name: "Hard", desc: "Faster, more of them, fewer supplies.", drain: 1.35, speed: 1.15, grace: 28, supply: 0.7, extra: 1 },
];

export const LEVELS: LevelDef[] = [
  {
    id: 0,
    name: "The Yellow Rooms",
    sub: "Level 0",
    theme: "yellow",
    layout: "office",
    size: 41,
    roomCount: 11,
    roomMin: 4,
    roomMax: 8,
    wideChance: 0.35,
    pillars: true,
    ambient: 0.05,
    lampGain: 0.66,
    lampRadius: 6.5,
    lampMod: 4,
    deadChance: 0.12,
    flickerChance: 0.1,
    tint: [1, 0.96, 0.84],
    fog: [0.26, 0.21, 0.09],
    fogDensity: 0.055,
    surface: "carpet",
    altSurface: "tile",
    altRooms: ["break", "restroom"],
    wallBRooms: ["office", "records", "meeting"],
    rooms: [
      { type: "office", label: "Open Office", weight: 3 },
      { type: "storage", label: "Storage", weight: 3 },
      { type: "break", label: "Break Room", weight: 2 },
      { type: "restroom", label: "Restroom", weight: 1 },
      { type: "records", label: "Records", weight: 2 },
      { type: "meeting", label: "Conference", weight: 2 },
    ],
    props: ["desk", "chair", "cabinet", "cooler", "plant", "boxes", "crt", "cone"],
    roomProps: {
      office: ["desk", "chair", "desk", "plant", "crt", "cabinet"],
      storage: ["boxes", "boxes", "cabinet", "cone"],
      break: ["cooler", "plant", "chair"],
      records: ["cabinet", "cabinet", "boxes", "desk"],
      meeting: ["chair", "chair", "plant"],
      restroom: ["cone"],
    },
    propDensity: 1,
    deco: ["poster", "vent", "extinguisher", "clock", "stain", "graffiti"],
    water: 5,
    cells: 4,
    notes: 6,
    task: { kind: "power", count: 3, itemRooms: ["storage", "records", "office"], deviceType: "maintenance", deviceLabel: "Maintenance", exitLabel: "Staff Exit" },
    entities: { listener: true, crawler: 1, warden: 0, mannequin: 2, hound: 0, drowned: 0, watcher: false },
    briefing: "SHIFT BRIEFING — Power to the staff exit is cut. Three fuses are in the building: storage, records or the open offices. Breaker panel is in MAINTENANCE. Do not take the exit until power is back.",
    tagline: "You have been here before.",
  },
  {
    id: 1,
    name: "Habitable Zone",
    sub: "Level 1",
    theme: "concrete",
    layout: "halls",
    size: 45,
    roomCount: 8,
    roomMin: 7,
    roomMax: 12,
    wideChance: 0.9,
    pillars: true,
    ambient: 0.05,
    lampGain: 1.6,
    lampRadius: 6,
    lampMod: 5,
    deadChance: 0.18,
    flickerChance: 0.1,
    tint: [1, 0.9, 0.78],
    fog: [0.14, 0.12, 0.1],
    fogDensity: 0.055,
    surface: "concrete",
    altSurface: "concrete",
    altRooms: [],
    wallBRooms: ["office", "control", "stores"],
    rooms: [
      { type: "warehouse", label: "Warehouse", weight: 4 },
      { type: "stores", label: "Stores", weight: 3 },
      { type: "office", label: "Dispatch Office", weight: 2 },
    ],
    props: ["pallet", "barrel", "boxes", "cone", "rack"],
    roomProps: {
      warehouse: ["pallet", "rack", "pallet", "barrel", "boxes"],
      stores: ["rack", "boxes", "pallet"],
      office: ["desk", "chair", "cabinet"],
    },
    propDensity: 1.1,
    deco: ["vent", "extinguisher", "graffiti", "hazard", "stain", "clock"],
    water: 4,
    cells: 5,
    notes: 6,
    task: { kind: "code", count: 3, itemRooms: ["stores", "office", "warehouse"], deviceType: "control", deviceLabel: "Control Room", exitLabel: "Freight Shutter" },
    entities: { listener: true, crawler: 1, warden: 1, mannequin: 0, hound: 0, drowned: 0, watcher: true },
    briefing: "FREIGHT NOTICE — The shutter keypad takes a three digit code, one digit per dispatch sheet. Sheets were left in stores, the dispatch office and out on the warehouse floor. Keypad is in the CONTROL ROOM. A warden walks the floor. Keep quiet.",
    tagline: "The lights are very far apart.",
  },
  {
    id: 2,
    name: "Pipe Dreams",
    sub: "Level 2",
    theme: "pipes",
    layout: "maze",
    size: 39,
    roomCount: 9,
    roomMin: 3,
    roomMax: 5,
    wideChance: 0,
    pillars: false,
    ambient: 0.055,
    lampGain: 1.35,
    lampRadius: 5,
    lampMod: 4,
    deadChance: 0.15,
    flickerChance: 0.12,
    tint: [1, 0.84, 0.66],
    fog: [0.15, 0.07, 0.03],
    fogDensity: 0.085,
    surface: "metal",
    altSurface: "metal",
    altRooms: [],
    wallBRooms: ["boiler", "pump", "valves", "exit"],
    rooms: [
      { type: "boiler", label: "Boiler Room", weight: 3 },
      { type: "pump", label: "Pump House", weight: 3 },
      { type: "valves", label: "Valve Hall", weight: 3 },
    ],
    props: ["tank", "pipestand", "barrel", "boxes"],
    roomProps: {
      boiler: ["tank", "pipestand", "barrel"],
      pump: ["pipestand", "barrel", "boxes"],
      valves: ["pipestand", "tank"],
    },
    propDensity: 0.8,
    deco: ["gauge", "vent", "hazard", "stain", "graffiti"],
    water: 3,
    cells: 5,
    notes: 6,
    task: { kind: "valves", count: 3, itemRooms: ["boiler", "pump", "valves"], deviceType: "valves", deviceLabel: "Valve Hall", exitLabel: "Surface Hatch" },
    entities: { listener: true, crawler: 1, warden: 0, mannequin: 0, hound: 2, drowned: 0, watcher: true },
    briefing: "PRESSURE LOG — Steam is backing up toward the surface hatch. Three isolation valves need turning by hand: boiler room, pump house, valve hall. They are stiff and they ring when you turn them. Something is tracking by sound down here.",
    tagline: "Everything is warm and nothing is still.",
  },
  {
    id: 3,
    name: "Poolrooms",
    sub: "Level 3",
    theme: "pool",
    layout: "pool",
    size: 41,
    roomCount: 9,
    roomMin: 6,
    roomMax: 10,
    wideChance: 0.8,
    pillars: false,
    ambient: 0.12,
    lampGain: 0.72,
    lampRadius: 8,
    lampMod: 4,
    deadChance: 0.06,
    flickerChance: 0.05,
    tint: [0.82, 0.92, 0.96],
    fog: [0.5, 0.68, 0.72],
    fogDensity: 0.045,
    surface: "tile",
    altSurface: "water",
    altRooms: ["pool"],
    wallBRooms: ["pool", "changing"],
    rooms: [
      { type: "pool", label: "Main Pool", weight: 4 },
      { type: "changing", label: "Changing Rooms", weight: 2 },
      { type: "guard", label: "Lifeguard Office", weight: 2 },
      { type: "sauna", label: "Sauna", weight: 1 },
    ],
    props: ["lounger", "lifebuoy", "palm", "bench"],
    roomProps: {
      pool: ["lounger", "lifebuoy", "palm"],
      changing: ["bench", "cabinet"],
      guard: ["desk", "chair", "cabinet"],
      sauna: ["bench"],
    },
    propDensity: 0.9,
    deco: ["depth", "vent", "clock", "stain", "extinguisher"],
    water: 4,
    cells: 3,
    notes: 6,
    task: { kind: "keys", count: 2, itemRooms: ["guard", "changing"], deviceType: "none", deviceLabel: "", exitLabel: "Staff Stairs" },
    entities: { listener: true, crawler: 0, warden: 0, mannequin: 3, hound: 0, drowned: 3, watcher: false },
    briefing: "POOL STAFF — Staff stairs are locked and the keys are on the hooks in the LIFEGUARD OFFICE and the CHANGING ROOMS. Stay out of the water if you can. Nobody has swum in months, and the water doesn't think so.",
    tagline: "It is very bright and very quiet.",
  },
  {
    id: 4,
    name: "Electrical Station",
    sub: "Level 4",
    theme: "plant",
    layout: "plant",
    size: 43,
    roomCount: 10,
    roomMin: 5,
    roomMax: 10,
    wideChance: 0.5,
    pillars: true,
    ambient: 0.035,
    lampGain: 1.7,
    lampRadius: 5.5,
    lampMod: 5,
    deadChance: 0.22,
    flickerChance: 0.2,
    tint: [0.82, 0.94, 1.1],
    fog: [0.04, 0.08, 0.1],
    fogDensity: 0.07,
    surface: "metal",
    altSurface: "metal",
    altRooms: ["turbine"],
    wallBRooms: ["switch", "stores", "turbine"],
    rooms: [
      { type: "turbine", label: "Turbine Hall", weight: 3 },
      { type: "switch", label: "Switchgear", weight: 3 },
      { type: "stores", label: "Stores", weight: 2 },
    ],
    props: ["transformer", "barrel", "rack", "boxes", "cone"],
    roomProps: {
      turbine: ["transformer", "barrel", "cone"],
      switch: ["rack", "transformer", "cabinet"],
      stores: ["boxes", "rack", "barrel"],
    },
    propDensity: 1,
    deco: ["hazard", "gauge", "vent", "stain", "graffiti"],
    water: 4,
    cells: 5,
    notes: 6,
    task: { kind: "generator", count: 2, itemRooms: ["switch", "stores"], deviceType: "generator", deviceLabel: "Generator Room", exitLabel: "Service Lift" },
    entities: { listener: true, crawler: 1, warden: 1, mannequin: 0, hound: 1, drowned: 0, watcher: true },
    briefing: "SHIFT HANDOVER — The lift only runs off the standby generator. It needs two fuses, from switchgear or stores, and someone to hold the start switch in the GENERATOR ROOM. It is loud. Everything on this level will hear it.",
    tagline: "Something is still running.",
  },
];

export interface Note {
  theme: ThemeId | "any";
  title: string;
  text: string;
}

export const NOTES: Note[] = [
  { theme: "any", title: "Sticky note", text: "Day 41. Carpet's wet again by the north copier. Called facilities. They said they'd 'been told'." },
  { theme: "yellow", title: "Memo, Facilities", text: "The hum is not a fault. Please stop filing tickets about the hum. Please stop describing the hum to new starters." },
  { theme: "yellow", title: "Handwritten", text: "If the hallway is shorter coming back, don't count the lights. Keep walking. Keep your eyes on the far end." },
  { theme: "any", title: "Torn page", text: "It only moves when you can't see it. I tried to blink slowly. I tried to keep it in the light. The light does not stay." },
  { theme: "yellow", title: "Lost property", text: "One almond water, unopened. Owner unknown. Please return it to the room you found it in. We will know." },
  { theme: "yellow", title: "HR notice", text: "Congratulations on your third anniversary with the company. Your desk has been moved down to Level 0. You have always worked here." },
  { theme: "any", title: "Calendar page", text: "Every date is circled and every date is the same date. Underneath, in pen: I AM STILL ON SHIFT." },
  { theme: "any", title: "Incident report", text: "Subject stopped responding at 03:07. Tubes failed across the sector. Last seen walking towards the dark, calmly, like he was late." },
  { theme: "any", title: "Margin note", text: "The torch makes it flinch but only for a moment, and it learns. Do not lean on it. Stand under a real light and wait." },
  { theme: "any", title: "Taped to door", text: "It listens. Don't run. Don't slam anything. If you hear it ticking behind you, stand still and let it decide you were nothing." },
  { theme: "concrete", title: "Forklift log", text: "Pallet 114 moved to bay 9. Pallet 114 is back in bay 3. Nobody drove it. The lights above bay 3 have been off since March." },
  { theme: "concrete", title: "Safety poster", text: "THE WARDEN IS NOT A MEMBER OF STAFF. If you see a lantern, do not approach it. If it sees you, do not run in the open." },
  { theme: "concrete", title: "Shift swap", text: "Can someone take my night on dock 2? I keep hearing someone breathing down the far aisle and when I go to look the aisle is longer." },
  { theme: "pipes", title: "Boiler log", text: "Pressure holds at 40 and I haven't touched anything. Something is turning the valves back at night. I can hear it ringing." },
  { theme: "pipes", title: "Scratched into pipe", text: "THEY FOLLOW THE NOISE. WALK SOFT. THE DOGS DON'T SEE WELL BUT THEY HEAR EVERYTHING. TORCH MAKES THEM BACK OFF." },
  { theme: "pipes", title: "Maintenance tag", text: "Do not use valve 3 without a second person. Valve 3 is warm and has a pulse." },
  { theme: "pool", title: "Pool rules", text: "No running. No diving. No swimming alone. No swimming after hours. No swimming. Please stay out of the water." },
  { theme: "pool", title: "Lifeguard note", text: "Counted 4 swimmers at open and 5 at close. I have been counting for hours. It's always one more." },
  { theme: "pool", title: "Locker note", text: "The mannequins in the viewing gallery are closer to the glass than they were this morning. The staff say they were never there." },
  { theme: "plant", title: "Plant log", text: "Standby gen starts on two fuses. Warning: it can be heard from every hall. Have an exit plan before you hold the switch." },
  { theme: "plant", title: "Safety notice", text: "Static in the dark halls is not static. If you see two small lights in the dark, look away and use your torch." },
  { theme: "plant", title: "Scrawled", text: "Whatever is running down here doesn't want to be switched off. It wants someone to hold the switch." },
  { theme: "any", title: "Polaroid, reverse", text: "'Employee 04, first day.' The face has been rubbed out with a thumb. The thumbprint is yours." },
  { theme: "any", title: "Break room menu", text: "TODAY: almond water. TOMORROW: almond water. THE DAY AFTER: almond water. Please do not ask about the kitchen." },
];

export const DEATH_LINES = [
  "You stopped being a person and became part of the hum.",
  "The lights stayed on. You didn't notice when you stopped.",
  "Somebody will find your desk exactly as it was.",
  "It listened until you stopped making noise.",
];

export const END_LINES = [
  "The lift opens onto a car park. It's raining. It's dark. It's somewhere. You do not remember going to work this morning, and your pass has a name you almost recognise.",
];
