export interface Tex {
  w: number;
  h: number;
  d: Uint8ClampedArray; // RGBA
}

export interface SpriteDef {
  frames: Tex[];
  w: number; // world width
  h: number; // world height
  elev: number;
  glow: number; // 0 = fully lit by the world, 1 = self lit
  shadow: boolean;
  solid: boolean;
  r: number; // collision radius
}

export type ThemeId = "yellow" | "concrete" | "pipes" | "pool" | "plant";

export interface Decal {
  cell: number;
  face: number; // 0:+x 1:-x 2:+y 3:-y  (direction a ray travels to hit it)
  u0: number;
  u1: number;
  z0: number;
  z1: number;
  tex: Tex;
  glow: number;
  kind: "deco" | "note" | "sign" | "fusebox" | "keypad" | "valve" | "generator" | "exit";
  used?: boolean;
  noteId?: number;
  text?: string;
  title?: string;
  alt?: Tex; // alternate art once used
}

export interface Lamp {
  cx: number;
  cy: number;
  base: number;
  cur: number;
  mode: "on" | "dead" | "flicker";
  patch: Float32Array;
  px: number;
  py: number;
  pw: number;
  ph: number;
  flickT: number;
  broken: boolean;
}

export interface Room {
  x: number;
  y: number;
  w: number;
  h: number;
  type: string;
  label: string;
  cells: number[];
  visited: boolean;
}

export interface Prop {
  x: number;
  y: number;
  kind: string;
  sprite: SpriteDef;
  frame: number;
  flip: boolean;
}

export type PickupKind = "water" | "cell" | "fuse" | "key";

export interface Pickup {
  kind: PickupKind;
  x: number;
  y: number;
  taken: boolean;
  phase: number;
  seen?: boolean;
}

export interface Level {
  n: number;
  map: Uint8Array; // 0 open, 1.. wall type
  floor: Uint8Array; // 0 main floor, 1 alt floor (water / tile)
  rooms: Room[];
  roomOf: Int16Array;
  lamps: Lamp[];
  lampAt: Int16Array;
  props: Prop[];
  pickups: Pickup[];
  decals: (Decal[] | undefined)[];
  start: { x: number; y: number };
  exit: Decal;
  exitCell: { x: number; y: number };
  device: Decal | null;
  devices: Decal[];
  explored: Uint8Array;
  spawnCells: number[];
  code: string;
}

export interface Difficulty {
  id: number;
  name: string;
  desc: string;
  drain: number;
  speed: number;
  grace: number;
  supply: number;
  extra: number;
}
