import type { Rng } from "./util";
import type { Difficulty, Level } from "./types";
import type { Lighting } from "./lighting";
import type { LevelDef } from "./levels";
import type { AudioEngine } from "./audio";
import type { SpriteInst } from "./render";
import { entitySprite, type EntityArt } from "./sprites";
import { bfs, isWall, nextStep, los } from "./world";

export type EntityKind = EntityArt;

export interface Ent {
  id: number;
  kind: EntityKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  state: string;
  t: number;
  alpha: number;
  frame: number;
  animT: number;
  field: Int16Array | null;
  fieldCell: number;
  goal: { x: number; y: number } | null;
  home: { x: number; y: number };
  a: number; // general purpose counters
  b: number;
  c: number;
  d: number;
  flag: boolean;
  soundT: number;
  stepT: number;
}

export interface World {
  level: Level;
  light: Lighting;
  def: LevelDef;
  diff: Difficulty;
  rng: Rng;
  audio: AudioEngine;
  time: number;
  blackout: boolean;
  p: { x: number; y: number; a: number; torchOn: boolean; inWater: boolean };
  pf: Int16Array; // distance field to the player
  noiseR: number; // how far the player is currently audible (in path cells)
  loud: { x: number; y: number; r: number; until: number } | null;
  hurt(dmg: number, from: string): void;
  drain(amount: number): void;
  seenBy(x: number, y: number): boolean; // inside the player's view cone with a clear line
  inTorch(x: number, y: number, range: number): boolean;
  lightAt(x: number, y: number): number;
  flickerNear(x: number, y: number, r: number): void;
  slow(t: number): void;
  note(kind: string): void;
  onRetreat(): void;
}

let uid = 1;
export function makeEnt(kind: EntityKind, x: number, y: number): Ent {
  return { id: uid++, kind, x, y, vx: 0, vy: 0, state: "idle", t: 0, alpha: 1, frame: 0, animT: 0, field: null, fieldCell: -1, goal: null, home: { x, y }, a: 0, b: 0, c: 0, d: 0, flag: false, soundT: 3 + Math.random() * 6, stepT: 0 };
}

const dist = (a: { x: number; y: number }, x: number, y: number) => Math.hypot(a.x - x, a.y - y);

function wallBlocked(lv: Level, x: number, y: number, r: number) {
  return isWall(lv, x - r, y - r) || isWall(lv, x + r, y - r) || isWall(lv, x - r, y + r) || isWall(lv, x + r, y + r);
}

function move(w: World, e: Ent, tx: number, ty: number, speed: number, dt: number, canEnter?: (x: number, y: number) => boolean) {
  const dx = tx - e.x, dy = ty - e.y;
  const d = Math.hypot(dx, dy);
  if (d < 0.001) return;
  const m = Math.min(d, speed * dt);
  const nx = e.x + (dx / d) * m, ny = e.y + (dy / d) * m;
  const lv = w.level;
  const ok = (x: number, y: number) => !wallBlocked(lv, x, y, 0.2) && (!canEnter || canEnter(x, y));
  const ox = e.x, oy = e.y;
  if (ok(nx, ny)) { e.x = nx; e.y = ny; }
  else if (ok(nx, e.y)) e.x = nx;
  else if (ok(e.x, ny)) e.y = ny;
  e.vx = (e.x - ox) / Math.max(dt, 1e-4);
  e.vy = (e.y - oy) / Math.max(dt, 1e-4);
}

/** walks along a distance field, cutting straight to the goal once it is in sight */
function follow(w: World, e: Ent, field: Int16Array, gx: number, gy: number, speed: number, dt: number) {
  const d = dist(e, gx, gy);
  if (d < 5 && los(w.level, e.x, e.y, gx, gy)) { move(w, e, gx, gy, speed, dt); return; }
  const st = nextStep(w.level, field, e.x, e.y);
  if (!st) { move(w, e, gx, gy, speed * 0.6, dt); return; }
  // aim slightly past the next cell centre so corners are smooth
  move(w, e, st[0], st[1], speed, dt);
}

function setGoalField(w: World, e: Ent, gx: number, gy: number, allow?: (c: number) => boolean) {
  const cell = Math.floor(gy) * w.level.n + Math.floor(gx);
  if (e.fieldCell !== cell || !e.field) {
    e.field = bfs(w.level, gx, gy, allow);
    e.fieldCell = cell;
  }
  e.goal = { x: gx, y: gy };
}

function randomRoomGoal(w: World) {
  const rooms = w.level.rooms.filter((r) => r.cells.length > 3);
  const r = w.rng.pick(rooms);
  const c = w.rng.pick(r.cells);
  return { x: (c % w.level.n) + 0.5, y: ((c / w.level.n) | 0) + 0.5 };
}

function patrol(w: World, e: Ent, speed: number, dt: number) {
  if (!e.goal || dist(e, e.goal.x, e.goal.y) < 0.9) {
    const g = randomRoomGoal(w);
    setGoalField(w, e, g.x, g.y);
  }
  follow(w, e, e.field as Int16Array, (e.goal as { x: number; y: number }).x, (e.goal as { x: number; y: number }).y, speed, dt);
}

function pathDist(w: World, x: number, y: number) {
  const v = w.pf[Math.floor(y) * w.level.n + Math.floor(x)];
  return v < 0 ? 999 : v;
}

function hearsPlayer(w: World, e: Ent, mult = 1) {
  return pathDist(w, e.x, e.y) < w.noiseR * mult;
}

function hearsLoud(w: World, e: Ent) {
  const l = w.loud;
  return !!l && l.until > w.time && dist(e, l.x, l.y) < l.r;
}

function animate(e: Ent, dt: number, speed: number, rate = 6) {
  if (speed > 0.1) e.animT += dt * rate;
}

/* ================================================================ THE LISTENER */
function updateListener(w: World, e: Ent, dt: number) {
  const P = w.p;
  const d = dist(e, P.x, P.y);
  // a = resist, b = stare time, c = stun time, d = adapt time ; t = state timer
  if (e.state === "idle") { e.state = "dormant"; e.t = w.diff.grace; e.alpha = 0; }
  if (e.state === "dormant") {
    e.alpha = 0;
    e.t -= dt;
    if (e.t <= 0) spawnListener(w, e);
    return;
  }
  if (e.state === "retreat") {
    e.alpha = Math.max(0, e.alpha - dt * 1.2);
    e.t -= dt;
    if (e.t <= 0) { e.state = "dormant"; e.t = 5 + w.rng.range(0, 6); }
    return;
  }
  e.alpha = Math.min(1, e.alpha + dt * 0.8);
  e.a = Math.min(1, e.a + dt * 0.012);
  if (e.d > 0) e.d -= dt;
  const lit = !w.blackout && (w.lightAt(e.x, e.y) > 0.17 || w.inTorch(e.x, e.y, 10));
  const seen = w.seenBy(e.x, e.y);
  const observed = seen && lit && d > 0.9;
  const dark = w.lightAt(P.x, P.y) < 0.13 || w.blackout;
  let speed = 0;
  let rush = false;

  if (e.c > 0) {
    // flinching back from the torch
    e.c -= dt;
    const away = Math.atan2(e.y - P.y, e.x - P.x);
    move(w, e, e.x + Math.cos(away), e.y + Math.sin(away), 1.6, dt);
    speed = 1.6;
  } else if (observed && e.d <= 0) {
    e.b += dt;
    w.drain(0.9 * dt * w.diff.drain);
    if (P.torchOn && w.inTorch(e.x, e.y, 9)) {
      e.c = 1.5 * e.a + 0.25;
      e.a = Math.max(0.2, e.a - 0.25);
      e.flag = false;
      e.stepT += 1; // counts consecutive torch uses
      if (e.stepT >= 3) { e.d = 11; e.stepT = 0; w.note("It has stopped flinching.") ; }
      w.audio.emit("listenerBreath", e.x, e.y, 1);
    }
    if (e.b > 5 && !e.flag) { e.flag = true; w.note("It knows you are looking."); }
    w.audio.duck(0.8);
  } else {
    w.audio.duck(0);
    if (e.flag && !observed) { e.flag = false; e.soundT = 0; e.b = 0; e.state = "rush"; e.t = 3; w.audio.emit("listenerRush", e.x, e.y, 1.2); }
    let base = 2.15 * w.diff.speed * (0.9 + 0.05 * Math.min(4, w.def.id));
    if (observed && e.d > 0) base *= 0.55;
    if (dark) base *= 1.18;
    if (e.state === "rush") { e.t -= dt; base *= 1.75; rush = true; if (e.t <= 0) e.state = "stalk"; }
    if (e.state === "idle") e.state = "stalk";
    let gx = P.x, gy = P.y, field = w.pf;
    if (hearsPlayer(w, e, 1.5) && w.noiseR > 4) { base *= 1.2; }
    if (hearsLoud(w, e) && w.loud) { gx = w.loud.x; gy = w.loud.y; setGoalField(w, e, gx, gy); field = e.field as Int16Array; }
    // it is slow to turn a corner, so it cuts them tight; plain pursuit
    follow(w, e, field, gx, gy, base, dt);
    speed = base;
    e.b = Math.max(0, e.b - dt * 0.5);
    if (d < 0.65) {
      w.hurt(26 + w.def.id * 2, "listener");
      e.state = "retreat";
      e.t = 12 + w.rng.range(0, 8);
      e.b = 0; e.flag = false;
      w.onRetreat();
      return;
    }
  }
  animate(e, dt, speed, 5);
  e.frame = rush ? 3 : speed > 0.1 ? 1 + (Math.floor(e.animT) & 1) : 0;
  if (e.c > 0) e.frame = 0;

  // tells: ticking teeth, breath, lights guttering around it
  e.soundT -= dt;
  if (e.soundT <= 0 && d < 16) {
    e.soundT = 1.6 + Math.random() * 2.8;
    if (Math.random() < 0.35 && d < 10) w.audio.emit("listenerBreath", e.x, e.y, 0.9);
    else w.audio.emit("listenerTick", e.x, e.y, 1);
  }
  if (d < 11 && Math.random() < dt * 0.5) w.flickerNear(e.x, e.y, 4.5);
}

function spawnListener(w: World, e: Ent) {
  const P = w.p;
  const cells = w.level.spawnCells.length ? w.level.spawnCells : w.level.rooms[0].cells;
  let best = -1, bs = -1e9;
  for (let k = 0; k < 40; k++) {
    const c = w.rng.pick(cells);
    const x = (c % w.level.n) + 0.5, y = ((c / w.level.n) | 0) + 0.5;
    const pd = pathDist(w, x, y);
    if (pd < 15 || pd > 40) continue;
    if (w.seenBy(x, y)) continue;
    const s = -w.lightAt(x, y) * 30 - Math.abs(pd - 24);
    if (s > bs) { bs = s; best = c; }
  }
  if (best < 0) { e.t = 3; return; }
  e.x = (best % w.level.n) + 0.5;
  e.y = ((best / w.level.n) | 0) + 0.5;
  e.state = "stalk";
  e.alpha = 0;
  e.b = 0; e.c = 0; e.d = 0; e.flag = false;
  void P;
}

/* ================================================================ CRAWLER */
function updateCrawler(w: World, e: Ent, dt: number) {
  const P = w.p;
  const d = dist(e, P.x, P.y);
  const sp = w.diff.speed;
  const sees = los(w.level, e.x, e.y, P.x, P.y) && d < 9.5 && (w.lightAt(P.x, P.y) > 0.1 || d < 5 || P.torchOn);
  let speed = 0;
  e.alpha = 1;
  switch (e.state) {
    case "idle":
    case "roam":
      e.state = "roam";
      speed = 1.7 * sp;
      patrol(w, e, speed, dt);
      if (sees || hearsPlayer(w, e, 1.1) || hearsLoud(w, e)) { e.state = "stalk"; e.t = 0; e.b = 0; w.audio.emit("chitter", e.x, e.y, 0.8); }
      break;
    case "stalk": {
      speed = 2.2 * sp;
      follow(w, e, w.pf, P.x, P.y, speed, dt);
      if (sees || hearsPlayer(w, e, 1.3)) e.b = 0; else e.b += dt;
      if (e.b > 8) e.state = "roam";
      if (sees && d < 5.2) { e.state = "tele"; e.t = 0.9; e.a = Math.atan2(P.y - e.y, P.x - e.x); w.audio.emit("chitter", e.x, e.y, 1.3); }
      break;
    }
    case "tele":
      e.t -= dt;
      e.a = Math.atan2(P.y - e.y, P.x - e.x);
      e.vx = Math.cos(e.a); e.vy = Math.sin(e.a);
      if (P.torchOn && w.inTorch(e.x, e.y, 8)) { e.state = "flee"; e.t = 3.2; w.audio.emit("skitter", e.x, e.y, 1.2); break; }
      if (e.t <= 0) { e.state = "lunge"; e.t = 0.75; e.flag = false; w.audio.emit("lunge", e.x, e.y, 1.3); }
      break;
    case "lunge": {
      e.t -= dt;
      speed = 6.3 * sp;
      const nx = e.x + Math.cos(e.a) * speed * dt, ny = e.y + Math.sin(e.a) * speed * dt;
      if (wallBlocked(w.level, nx, ny, 0.2)) { e.state = "recover"; e.t = 1.6; break; }
      e.vx = Math.cos(e.a) * speed; e.vy = Math.sin(e.a) * speed;
      e.x = nx; e.y = ny;
      if (dist(e, P.x, P.y) < 0.6 && !e.flag) { e.flag = true; w.hurt(22, "crawler"); }
      if (e.t <= 0) { e.state = "recover"; e.t = 1.8; }
      break;
    }
    case "recover":
      e.t -= dt;
      if (e.t <= 0) e.state = sees ? "stalk" : "roam";
      break;
    case "flee": {
      e.t -= dt;
      speed = 3.6 * sp;
      const away = Math.atan2(e.y - P.y, e.x - P.x);
      move(w, e, e.x + Math.cos(away) * 3, e.y + Math.sin(away) * 3, speed, dt);
      if (e.t <= 0) e.state = "roam";
      break;
    }
  }
  animate(e, dt, speed, 9);
  e.frame = e.state === "tele" || e.state === "lunge" ? 2 : Math.floor(e.animT) & 1;
  e.soundT -= dt;
  if (e.soundT <= 0 && speed > 0.1) {
    e.soundT = e.state === "stalk" ? 1.1 : 3 + Math.random() * 4;
    w.audio.emit("skitter", e.x, e.y, 1);
  }
}

/* ================================================================ WARDEN */
function updateWarden(w: World, e: Ent, dt: number) {
  const P = w.p;
  const d = dist(e, P.x, P.y);
  const sp = w.diff.speed;
  e.alpha = 1;
  const sees = los(w.level, e.x, e.y, P.x, P.y) && d < 9.5 && (w.lightAt(P.x, P.y) > 0.08 || d < 4.5 || P.torchOn);
  let speed = 0;
  if (e.state === "idle") e.state = "patrol";
  switch (e.state) {
    case "patrol":
      speed = 1.2 * sp;
      patrol(w, e, speed, dt);
      if (sees) { e.state = "chase"; e.t = 0; w.audio.emit("wardenSpot", e.x, e.y, 1.4); w.note("The warden has seen you."); }
      else if (hearsPlayer(w, e, 1.15) || hearsLoud(w, e)) {
        const g = hearsLoud(w, e) && w.loud ? { x: w.loud.x, y: w.loud.y } : { x: P.x, y: P.y };
        setGoalField(w, e, g.x, g.y);
        e.state = "investigate"; e.t = 8;
      }
      break;
    case "investigate":
      speed = 1.7 * sp;
      e.t -= dt;
      if (e.goal && e.field) follow(w, e, e.field, e.goal.x, e.goal.y, speed, dt);
      if (sees) { e.state = "chase"; e.t = 0; w.audio.emit("wardenSpot", e.x, e.y, 1.4); }
      else if (e.t <= 0 || (e.goal && dist(e, e.goal.x, e.goal.y) < 0.8)) { e.state = "patrol"; e.goal = null; }
      break;
    case "chase":
      speed = 2.4 * sp;
      follow(w, e, w.pf, P.x, P.y, speed, dt);
      if (sees || hearsPlayer(w, e, 1.2)) e.t = 0; else e.t += dt;
      if (e.t > 7) { e.state = "patrol"; e.goal = null; }
      if (d < 0.8 && e.b <= 0) { w.hurt(34, "warden"); e.b = 2.2; }
      break;
    case "recover":
      break;
  }
  if (e.b > 0) { e.b -= dt; speed = 0; }
  // lantern light, swinging a little
  const sway = Math.sin(w.time * 3) * 0.12;
  w.light.dyn.push({ x: e.x + sway, y: e.y, r: 5.2, i: 0.7, r0: 1, g0: 0.7, b0: 0.4 });
  animate(e, dt, speed, 4);
  e.frame = speed > 0.1 ? 1 + (Math.floor(e.animT) & 1) : 0;
  if (speed > 0.1) {
    e.stepT -= dt;
    if (e.stepT <= 0) { e.stepT = e.state === "chase" ? 0.45 : 0.8; w.audio.emit("wardenStep", e.x, e.y, 1); }
  }
  e.soundT -= dt;
  if (e.soundT <= 0 && d < 16) { e.soundT = 4 + Math.random() * 4; w.audio.emit("wardenBreath", e.x, e.y, 1); }
}

/* ================================================================ HOUND */
function updateHound(w: World, e: Ent, dt: number) {
  const P = w.p;
  const d = dist(e, P.x, P.y);
  const sp = w.diff.speed;
  e.alpha = 1;
  let speed = 0;
  if (e.state === "idle") e.state = "wander";
  const heard = hearsPlayer(w, e, 1.6) || hearsLoud(w, e);
  switch (e.state) {
    case "wander":
      speed = 1.5 * sp;
      patrol(w, e, speed, dt);
      if (heard && w.noiseR > 3.5) { e.state = "hunt"; e.t = 0; w.audio.emit("howl", e.x, e.y, 1.3); w.note("Something is hunting by sound."); }
      break;
    case "hunt": {
      speed = 3.35 * sp;
      let gx = P.x, gy = P.y, f = w.pf;
      if (!heard && d > 3 && w.loud && w.loud.until > w.time) { gx = w.loud.x; gy = w.loud.y; setGoalField(w, e, gx, gy); f = e.field as Int16Array; }
      follow(w, e, f, gx, gy, speed, dt);
      if (heard || d < 6) e.t = 0; else e.t += dt;
      if (e.t > 7) e.state = "wander";
      if (P.torchOn && w.inTorch(e.x, e.y, 7)) { e.state = "flee"; e.t = 4.2; w.audio.emit("growl", e.x, e.y, 1); break; }
      if (d < 0.8 && e.b <= 0) { w.hurt(10, "hound"); e.b = 0.9; w.audio.emit("growl", e.x, e.y, 1); }
      break;
    }
    case "flee": {
      e.t -= dt;
      speed = 3 * sp;
      const away = Math.atan2(e.y - P.y, e.x - P.x);
      move(w, e, e.x + Math.cos(away) * 3, e.y + Math.sin(away) * 3, speed, dt);
      if (e.t <= 0) e.state = "wander";
      break;
    }
  }
  if (e.b > 0) e.b -= dt;
  animate(e, dt, speed, speed > 2.5 ? 11 : 7);
  e.frame = e.b > 0.45 ? 2 : speed > 0.1 ? Math.floor(e.animT) & 1 : 0;
  e.soundT -= dt;
  if (e.soundT <= 0) {
    e.soundT = e.state === "hunt" ? 0.7 : 5 + Math.random() * 6;
    w.audio.emit(e.state === "hunt" ? "paws" : "pant", e.x, e.y, 1);
  }
}

/* ================================================================ MANNEQUIN */
function updateMannequin(w: World, e: Ent, dt: number) {
  const P = w.p;
  const d = dist(e, P.x, P.y);
  e.alpha = e.state === "spent" ? Math.max(0, e.alpha - dt) : 1;
  if (e.state === "spent") return;
  if (e.state === "idle") { e.state = "dormant"; e.frame = Math.floor(w.rng.range(0, 2)); e.c = e.frame; }
  if (e.state === "dormant" && d < 6.5) { e.state = "awake"; e.a = 0.4; }
  if (e.state === "awake" && d > 24) { e.state = "dormant"; e.x = e.home.x; e.y = e.home.y; }
  if (e.state !== "awake") return;
  const seen = w.seenBy(e.x, e.y) && (d < 4.5 || w.lightAt(e.x, e.y) > 0.12 || w.inTorch(e.x, e.y, 9)) && !(w.blackout && d > 2);
  if (seen) {
    e.frame = d < 3.5 ? 2 : e.c;
    return;
  }
  e.a -= dt;
  if (e.a <= 0) {
    e.a = 0.5 + Math.random() * 0.15;
    const st = nextStep(w.level, w.pf, e.x, e.y);
    const tx = st && d > 1.4 ? st[0] : P.x, ty = st && d > 1.4 ? st[1] : P.y;
    const ang = Math.atan2(ty - e.y, tx - e.x);
    const hop = 0.95 * w.diff.speed;
    const nx = e.x + Math.cos(ang) * hop, ny = e.y + Math.sin(ang) * hop;
    if (!wallBlocked(w.level, nx, ny, 0.2)) { e.vx = nx - e.x; e.vy = ny - e.y; e.x = nx; e.y = ny; }
    w.audio.emit("clack", e.x, e.y, 1);
    e.frame = d < 3.5 ? 2 : (e.c + 1) % 3;
  }
  if (dist(e, P.x, P.y) < 0.7) {
    w.hurt(28, "mannequin");
    e.state = "spent";
  }
}

/* ================================================================ WATCHER */
function updateWatcher(w: World, e: Ent, dt: number) {
  const P = w.p;
  // a = cooldown, b = darkness timer, c = observed time, t = life
  const dark = w.lightAt(P.x, P.y) < 0.12 || w.blackout;
  if (e.state === "idle") { e.state = "away"; e.a = 6; e.alpha = 0; }
  if (e.state === "away") {
    e.alpha = Math.max(0, e.alpha - dt * 2);
    e.a -= dt;
    e.b = dark ? e.b + dt : Math.max(0, e.b - dt);
    if (e.a <= 0 && e.b > 2.5) {
      for (let k = 0; k < 24; k++) {
        const ang = P.a + w.rng.range(-0.7, 0.7);
        const r = w.rng.range(6, 12);
        const x = P.x + Math.cos(ang) * r, y = P.y + Math.sin(ang) * r;
        if (isWall(w.level, x, y)) continue;
        if (!los(w.level, P.x, P.y, x, y)) continue;
        if (w.lightAt(x, y) > 0.1) continue;
        e.x = x; e.y = y; e.state = "watch"; e.t = 0; e.c = 0; e.alpha = 0;
        break;
      }
    }
    return;
  }
  // watching
  e.t += dt;
  e.alpha = Math.min(1, e.alpha + dt * 1.2);
  const seen = w.seenBy(e.x, e.y);
  const d = dist(e, P.x, P.y);
  if (seen) {
    e.c += dt;
    w.drain(2.2 * dt * w.diff.drain);
    e.soundT -= dt;
    if (e.soundT <= 0) { e.soundT = 1.8; w.audio.emit("ring", e.x, e.y, 1.4); }
  }
  const lit = w.lightAt(e.x, e.y) > 0.2 || w.lightAt(P.x, P.y) > 0.3;
  const torched = P.torchOn && w.inTorch(e.x, e.y, 12);
  if (torched || lit || e.c > 5 || e.t > 14 || d < 2.5) {
    e.state = "away";
    e.a = 10 + Math.random() * 8;
    e.b = 0;
  }
  e.frame = Math.floor(w.time * 1.5) & 1;
}

/* ================================================================ DROWNED */
function updateDrowned(w: World, e: Ent, dt: number) {
  const P = w.p;
  const lv = w.level;
  const water = (x: number, y: number) => lv.floor[Math.floor(y) * lv.n + Math.floor(x)] === 1;
  const d = dist(e, P.x, P.y);
  let speed = 0;
  if (e.state === "idle") { e.state = "drift"; e.a = Math.random() * 6.28; }
  const pNearWater = P.inWater || (d < 3 && water(P.x + Math.cos(P.a) * 0.5, P.y + Math.sin(P.a) * 0.5));
  if (e.state === "drift") {
    speed = 0.5 * w.diff.speed;
    e.t -= dt;
    if (e.t <= 0) { e.a += w.rng.range(-1.5, 1.5); e.t = 1 + Math.random() * 2; }
    move(w, e, e.x + Math.cos(e.a), e.y + Math.sin(e.a), speed, dt, water);
    if (d < 9 && pNearWater) { e.state = "hunt"; w.audio.emit("gurgle", e.x, e.y, 1.2); }
  } else {
    speed = 2.15 * w.diff.speed;
    move(w, e, P.x, P.y, speed, dt, water);
    if (d > 13 || (!pNearWater && d > 5)) e.state = "drift";
    if (d < 0.9) { w.hurt(15, "drowned"); w.slow(2.2); e.state = "drift"; e.t = 3; e.a = Math.atan2(e.y - P.y, e.x - P.x); w.audio.emit("splash", e.x, e.y, 1.2); }
  }
  e.alpha = Math.max(0.0, Math.min(1, (10 - d) / 5)) * (e.state === "hunt" ? 1 : 0.85);
  animate(e, dt, speed, 3);
  e.frame = Math.floor(e.animT) & 1;
  e.soundT -= dt;
  if (e.soundT <= 0 && d < 15) { e.soundT = 3 + Math.random() * 3; w.audio.emit(e.state === "hunt" ? "gurgle" : "splash", e.x, e.y, 0.9); }
}

/* ================================================================ driver */
export function updateEntities(w: World, list: Ent[], dt: number) {
  w.light.dyn.length = 0;
  for (const e of list) {
    switch (e.kind) {
      case "listener": updateListener(w, e, dt); break;
      case "crawler": updateCrawler(w, e, dt); break;
      case "warden": updateWarden(w, e, dt); break;
      case "hound": updateHound(w, e, dt); break;
      case "mannequin": updateMannequin(w, e, dt); break;
      case "watcher": updateWatcher(w, e, dt); break;
      case "drowned": updateDrowned(w, e, dt); break;
    }
  }
}

export function entitySprites(list: Ent[], camA: number): SpriteInst[] {
  const out: SpriteInst[] = [];
  const rx = -Math.sin(camA), ry = Math.cos(camA);
  for (const e of list) {
    if (e.alpha < 0.02) continue;
    if (e.kind === "listener" && e.state === "dormant") continue;
    const def = entitySprite(e.kind);
    const lateral = e.vx * rx + e.vy * ry;
    let flip = false;
    if (e.kind === "crawler" || e.kind === "hound") flip = lateral < 0;
    let zoff = 0;
    if (e.kind === "drowned") zoff = Math.sin(e.animT) * 0.01;
    out.push({ x: e.x, y: e.y, def, frame: e.frame, flip, alpha: e.alpha, glow: 0, scale: 1, zoff, flash: 0 });
  }
  return out;
}

