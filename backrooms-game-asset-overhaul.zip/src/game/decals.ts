import { paint } from "./sprites";
import type { Decal, Tex } from "./types";

type G = CanvasRenderingContext2D;

export interface DecalArt {
  tex: Tex;
  alt?: Tex;
  u0: number;
  u1: number;
  z0: number;
  z1: number;
  glow: number;
  kind: Decal["kind"];
}

const PX = 320; // texels per world unit on a wall

const dims = (u0: number, u1: number, z0: number, z1: number) => ({ w: Math.round((u1 - u0) * PX), h: Math.round((z1 - z0) * PX) });

function grain(g: G, w: number, h: number, amt: number) {
  const id = g.getImageData(0, 0, w, h);
  const d = id.data;
  let s = 12345;
  for (let i = 0; i < d.length; i += 4) {
    s = (s * 1664525 + 1013904223) >>> 0;
    if (d[i + 3] < 8) continue;
    const n = ((s >>> 16) / 65535 - 0.5) * amt;
    d[i] += n; d[i + 1] += n; d[i + 2] += n;
  }
  g.putImageData(id, 0, 0);
}

function wrap(g: G, text: string, x: number, y: number, maxW: number, lh: number) {
  const words = text.split(" ");
  let line = "";
  let yy = y;
  for (const w of words) {
    const t = line ? line + " " + w : w;
    if (g.measureText(t).width > maxW && line) { g.fillText(line, x, yy); line = w; yy += lh; } else line = t;
  }
  g.fillText(line, x, yy);
}

function mk(kind: Decal["kind"], u0: number, u1: number, z0: number, z1: number, glow: number, draw: (g: G, w: number, h: number) => void, alt?: (g: G, w: number, h: number) => void): DecalArt {
  const { w, h } = dims(u0, u1, z0, z1);
  const tex = paint(w, h, (g, ww, hh) => { draw(g, ww, hh); grain(g, ww, hh, 10); });
  const altTex = alt ? paint(w, h, (g, ww, hh) => { alt(g, ww, hh); grain(g, ww, hh, 10); }) : undefined;
  return { tex, alt: altTex, u0, u1, z0, z1, glow, kind };
}

const cache = new Map<string, DecalArt>();

function shadowed(g: G, w: number, h: number) {
  g.fillStyle = "rgba(0,0,0,0.25)";
  g.fillRect(3, 4, w - 3, h - 3);
}

export function decalArt(name: string, text = "", extra = ""): DecalArt {
  const key = name + "|" + text + "|" + extra;
  const hit = cache.get(key);
  if (hit) return hit;
  const art = build(name, text, extra);
  cache.set(key, art);
  return art;
}

function build(name: string, text: string, extra: string): DecalArt {
  switch (name) {
    case "note":
      return mk("note", 0.4, 0.6, 0.42, 0.66, 0, (g, w, h) => {
        g.save();
        g.translate(w / 2, h / 2);
        g.rotate((text.length % 5 - 2) * 0.02);
        g.translate(-w / 2, -h / 2);
        shadowed(g, w, h);
        g.fillStyle = extra === "code" ? "#e5dfc6" : "#ebe6d0";
        g.fillRect(0, 0, w - 4, h - 4);
        g.fillStyle = "rgba(120,100,60,0.12)";
        g.fillRect(0, h * 0.72, w - 4, h * 0.28);
        g.fillStyle = "#3a3630";
        for (let i = 0; i < 7; i++) g.fillRect(8, 14 + i * 7.5, (w - 22) * (0.55 + ((i * 37) % 10) / 24), 1.8);
        g.fillStyle = "#a33a2a";
        g.beginPath(); g.arc(w / 2, 6, 3.4, 0, Math.PI * 2); g.fill();
        g.restore();
      });
    case "sign":
      return mk("sign", 0.28, 0.72, 0.66, 0.8, 0.08, (g, w, h) => {
        shadowed(g, w, h);
        g.fillStyle = "#20262c";
        g.fillRect(0, 0, w - 3, h - 3);
        g.strokeStyle = "#cfd2cc";
        g.lineWidth = 2;
        g.strokeRect(5, 5, w - 13, h - 13);
        g.fillStyle = "#e8e8e0";
        g.font = `bold ${Math.min(24, Math.floor((w - 24) / Math.max(6, text.length) * 1.7))}px Arial, Helvetica, sans-serif`;
        g.textAlign = "center";
        g.textBaseline = "middle";
        g.fillText(text.toUpperCase(), w / 2 - 1, h / 2 - 1);
      });
    case "fusebox":
      return mk("fusebox", 0.32, 0.68, 0.3, 0.72, 0.0, (g, w, h) => {
        shadowed(g, w, h);
        g.fillStyle = "#6c7378"; g.fillRect(0, 0, w - 3, h - 3);
        g.fillStyle = "#8a9196"; g.fillRect(4, 4, w - 11, h - 11);
        g.strokeStyle = "#454b50"; g.lineWidth = 2; g.strokeRect(4, 4, w - 11, h - 11);
        g.fillStyle = "#1b1d1f"; g.fillRect(w * 0.16, h * 0.12, w * 0.6, h * 0.5);
        for (let i = 0; i < 3; i++) { g.fillStyle = "#050505"; g.fillRect(w * 0.2 + i * w * 0.18, h * 0.18, w * 0.12, h * 0.38); }
        g.fillStyle = "#d1a62e"; g.fillRect(w * 0.12, h * 0.7, w * 0.76, h * 0.07);
        g.fillStyle = "#b02a22"; g.beginPath(); g.arc(w * 0.82, h * 0.2, 5, 0, 7); g.fill();
        g.fillStyle = "#1b1d1f"; g.font = "bold 11px Arial"; g.fillText("HV", w * 0.2, h * 0.86);
      }, (g, w, h) => {
        shadowed(g, w, h);
        g.fillStyle = "#6c7378"; g.fillRect(0, 0, w - 3, h - 3);
        g.fillStyle = "#8a9196"; g.fillRect(4, 4, w - 11, h - 11);
        g.strokeStyle = "#454b50"; g.lineWidth = 2; g.strokeRect(4, 4, w - 11, h - 11);
        g.fillStyle = "#1b1d1f"; g.fillRect(w * 0.16, h * 0.12, w * 0.6, h * 0.5);
        for (let i = 0; i < 3; i++) { g.fillStyle = "#e9e5d5"; g.fillRect(w * 0.2 + i * w * 0.18, h * 0.18, w * 0.12, h * 0.38); g.fillStyle = "#c79a4a"; g.fillRect(w * 0.2 + i * w * 0.18, h * 0.18, w * 0.12, 5); }
        g.fillStyle = "#d1a62e"; g.fillRect(w * 0.12, h * 0.7, w * 0.76, h * 0.07);
        g.fillStyle = "#3ccf5a"; g.beginPath(); g.arc(w * 0.82, h * 0.2, 5, 0, 7); g.fill();
      });
    case "keypad": {
      const draw = (led: string) => (g: G, w: number, h: number) => {
        shadowed(g, w, h);
        g.fillStyle = "#2c3034"; g.fillRect(0, 0, w - 3, h - 3);
        g.fillStyle = "#14171a"; g.fillRect(8, 8, w - 19, h * 0.17);
        g.fillStyle = led; g.fillRect(12, 12, w - 27, h * 0.17 - 8);
        for (let r = 0; r < 4; r++) for (let c = 0; c < 3; c++) {
          g.fillStyle = "#9aa0a0"; g.fillRect(10 + c * ((w - 20) / 3), h * 0.3 + r * ((h * 0.64) / 4), (w - 20) / 3 - 4, (h * 0.64) / 4 - 4);
        }
      };
      return mk("keypad", 0.4, 0.6, 0.38, 0.66, 0.15, draw("#c22"), draw("#2d2"));
    }
    case "valve":
      return mk("valve", 0.28, 0.72, 0.26, 0.7, 0, (g, w, h) => {
        const cx = w / 2, cy = h * 0.5, r = Math.min(w, h) * 0.38;
        g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(cx + 4, cy + 6, r, r, 0, 0, 7); g.fill();
        g.strokeStyle = "#6a6f6f"; g.lineWidth = 12; g.beginPath(); g.moveTo(0, cy); g.lineTo(w, cy); g.stroke();
        g.strokeStyle = "#a83a2a"; g.lineWidth = 7; g.beginPath(); g.arc(cx, cy, r, 0, 7); g.stroke();
        for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); g.stroke(); }
        g.fillStyle = "#3a3d3e"; g.beginPath(); g.arc(cx, cy, 9, 0, 7); g.fill();
        g.fillStyle = "#e0b030"; g.fillRect(w - 28, cy - 24, 20, 12);
      }, (g, w, h) => {
        const cx = w / 2, cy = h * 0.5, r = Math.min(w, h) * 0.38;
        g.strokeStyle = "#6a6f6f"; g.lineWidth = 12; g.beginPath(); g.moveTo(0, cy); g.lineTo(w, cy); g.stroke();
        g.strokeStyle = "#8a4a3a"; g.lineWidth = 7; g.beginPath(); g.arc(cx, cy, r, 0, 7); g.stroke();
        for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3 + 0.5; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); g.stroke(); }
        g.fillStyle = "#3a3d3e"; g.beginPath(); g.arc(cx, cy, 9, 0, 7); g.fill();
        g.fillStyle = "#3ccf5a"; g.fillRect(w - 28, cy - 24, 20, 12);
      });
    case "generator":
      return mk("generator", 0.3, 0.7, 0.3, 0.7, 0, (g, w, h) => {
        shadowed(g, w, h);
        g.fillStyle = "#c7a02a"; g.fillRect(0, 0, w - 3, h - 3);
        g.fillStyle = "#1e2022"; g.fillRect(10, 10, w - 23, h - 23);
        g.fillStyle = "#c22"; g.fillRect(w * 0.42, h * 0.2, w * 0.16, h * 0.34);
        g.fillStyle = "#555"; g.fillRect(w * 0.38, h * 0.54, w * 0.24, h * 0.2);
        g.fillStyle = "#d8d4c0"; g.font = "bold 12px Arial"; g.textAlign = "center"; g.fillText("MAIN FEED", w / 2, h * 0.88);
      }, (g, w, h) => {
        shadowed(g, w, h);
        g.fillStyle = "#c7a02a"; g.fillRect(0, 0, w - 3, h - 3);
        g.fillStyle = "#1e2022"; g.fillRect(10, 10, w - 23, h - 23);
        g.fillStyle = "#3c3"; g.fillRect(w * 0.42, h * 0.5, w * 0.16, h * 0.3);
        g.fillStyle = "#555"; g.fillRect(w * 0.38, h * 0.26, w * 0.24, h * 0.2);
        g.fillStyle = "#d8d4c0"; g.font = "bold 12px Arial"; g.textAlign = "center"; g.fillText("MAIN FEED", w / 2, h * 0.88);
      });
    case "exit": {
      const door = (locked: boolean) => (g: G, w: number, h: number) => {
        g.fillStyle = "#1a1c1c"; g.fillRect(0, 0, w, h);
        g.fillStyle = "#59615f"; g.fillRect(8, 8, w - 16, h - 8);
        g.fillStyle = "rgba(255,255,255,0.08)"; g.fillRect(8, 8, 8, h - 8);
        g.strokeStyle = "#2c3030"; g.lineWidth = 3; g.strokeRect(24, 28, w - 48, h * 0.4);
        g.fillStyle = "#222"; g.fillRect(w - 44, h * 0.55, 10, 34);
        g.fillStyle = locked ? "#2a0c0c" : "#0c2a14"; g.fillRect(w / 2 - 30, 6, 60, 18);
        g.fillStyle = locked ? "#d83a2a" : "#3be06a"; g.font = "bold 13px Arial"; g.textAlign = "center"; g.textBaseline = "middle";
        g.fillText(extra === "lift" ? (locked ? "LIFT" : "LIFT") : "EXIT", w / 2, 15.5);
        g.fillStyle = locked ? "#d83a2a" : "#3be06a"; g.beginPath(); g.arc(w - 30, h * 0.5, 4, 0, 7); g.fill();
        g.fillStyle = "#e0b030";
        for (let i = 0; i < 8; i++) g.fillRect(8 + i * ((w - 16) / 8), h - 14, (w - 16) / 16, 14);
      };
      return mk("exit", 0.1, 0.9, 0, 0.86, 0.3, door(true), door(false));
    }
    case "poster":
      return mk("deco", 0.3, 0.7, 0.34, 0.78, 0, (g, w, h) => {
        g.fillStyle = "#d9d3bc"; g.fillRect(0, 0, w - 3, h - 3);
        g.fillStyle = "#2a2620"; g.font = "bold 20px Arial"; g.textAlign = "center"; g.textBaseline = "top";
        g.fillText(text.split("|")[0], w / 2, 10);
        g.fillStyle = "#8a8878"; g.fillRect(14, 40, w - 31, h * 0.4);
        g.fillStyle = "rgba(60,56,46,0.55)"; g.beginPath(); g.arc(w / 2, 40 + h * 0.2, 17, 0, 7); g.fill(); g.fillRect(w / 2 - 26, 40 + h * 0.2 + 12, 52, h * 0.2);
        g.fillStyle = "#2a2620"; g.font = "13px Arial"; wrap(g, text.split("|")[1] || "", w / 2, h * 0.7, w - 30, 15);
      });
    case "graffiti":
      return mk("deco", 0.1, 0.9, 0.28, 0.58, 0, (g, w, h) => {
        g.fillStyle = "#6a1612"; g.font = `bold ${Math.floor(Math.min(h * 0.72, w / Math.max(4, text.length) * 1.5))}px Impact, Arial Black, sans-serif`;
        g.textAlign = "center"; g.textBaseline = "middle";
        g.globalAlpha = 0.8;
        g.fillText(text, w / 2, h / 2);
        g.strokeStyle = "#6a1612"; g.lineWidth = 3;
        for (let i = 0; i < 6; i++) { const x = w * (0.2 + i * 0.12); g.beginPath(); g.moveTo(x, h * 0.62); g.lineTo(x + 1, h * 0.62 + 10 + (i * 7) % 20); g.stroke(); }
      });
    case "vent":
      return mk("deco", 0.3, 0.7, 0.74, 0.92, 0, (g, w, h) => {
        g.fillStyle = "#8d9090"; g.fillRect(0, 0, w - 3, h - 3);
        g.fillStyle = "#1a1a1a";
        for (let i = 0; i < 6; i++) g.fillRect(8, 8 + i * ((h - 16) / 6), w - 22, (h - 16) / 6 - 4);
        g.fillStyle = "rgba(255,255,255,0.15)"; g.fillRect(0, 0, w, 3);
      });
    case "extinguisher":
      return mk("deco", 0.42, 0.58, 0.22, 0.62, 0, (g, w, h) => {
        g.fillStyle = "#b02a22"; g.beginPath(); g.roundRect(4, 20, w - 12, h - 24, 12); g.fill();
        g.fillStyle = "#2a2a2a"; g.fillRect(w * 0.3, 6, w * 0.3, 18);
        g.fillStyle = "#e8e4d6"; g.fillRect(8, h * 0.5, w - 20, h * 0.2);
        g.fillStyle = "rgba(255,255,255,0.25)"; g.fillRect(10, 26, 5, h - 40);
      });
    case "clock":
      return mk("deco", 0.4, 0.6, 0.62, 0.84, 0, (g, w, h) => {
        const r = Math.min(w, h) / 2 - 2;
        g.fillStyle = "#1c1c1c"; g.beginPath(); g.arc(w / 2, h / 2, r, 0, 7); g.fill();
        g.fillStyle = "#e6e2d0"; g.beginPath(); g.arc(w / 2, h / 2, r - 4, 0, 7); g.fill();
        g.strokeStyle = "#222"; g.lineWidth = 2.4;
        g.beginPath(); g.moveTo(w / 2, h / 2); g.lineTo(w / 2 + 2, h / 2 - r * 0.6); g.stroke();
        g.beginPath(); g.moveTo(w / 2, h / 2); g.lineTo(w / 2 - r * 0.4, h / 2 + r * 0.2); g.stroke();
      });
    case "gauge":
      return mk("deco", 0.4, 0.6, 0.36, 0.58, 0, (g, w, h) => {
        const r = Math.min(w, h) / 2 - 2;
        g.fillStyle = "#3a3a38"; g.beginPath(); g.arc(w / 2, h / 2, r, 0, 7); g.fill();
        g.fillStyle = "#e0dcc8"; g.beginPath(); g.arc(w / 2, h / 2, r - 4, 0, 7); g.fill();
        g.strokeStyle = "#b02a22"; g.lineWidth = 3; g.beginPath(); g.arc(w / 2, h / 2, r - 8, 0.2, 1.0); g.stroke();
        g.strokeStyle = "#222"; g.lineWidth = 2.4; g.beginPath(); g.moveTo(w / 2, h / 2); g.lineTo(w / 2 + r * 0.55, h / 2 - r * 0.3 + (text ? 12 : 0)); g.stroke();
      });
    case "depth":
      return mk("deco", 0.38, 0.62, 0.46, 0.7, 0, (g, w, h) => {
        g.fillStyle = "#1c5a78"; g.fillRect(0, 0, w - 2, h - 2);
        g.fillStyle = "#e8f0f2"; g.font = "bold 26px Arial"; g.textAlign = "center"; g.textBaseline = "middle";
        g.fillText(text || "1.5 m", w / 2, h / 2);
      });
    case "hazard":
      return mk("deco", 0.36, 0.64, 0.4, 0.7, 0, (g, w, h) => {
        g.fillStyle = "#e0b030"; g.beginPath(); g.moveTo(w / 2, 4); g.lineTo(w - 6, h - 6); g.lineTo(6, h - 6); g.closePath(); g.fill();
        g.strokeStyle = "#111"; g.lineWidth = 5; g.stroke();
        g.fillStyle = "#111"; g.fillRect(w / 2 - 3, h * 0.35, 6, h * 0.28); g.fillRect(w / 2 - 3, h * 0.7, 6, 6);
      });
    case "stain":
      return mk("deco", 0.2, 0.8, 0.0, 0.5, 0, (g, w, h) => {
        g.fillStyle = "rgba(20,16,10,0.4)";
        for (let i = 0; i < 9; i++) {
          const x = w * (0.1 + (i * 0.37) % 0.8);
          const lw = 6 + (i * 11) % 14;
          g.fillRect(x, 0, lw, h * (0.3 + ((i * 29) % 70) / 100));
        }
      });
    default:
      return mk("deco", 0.4, 0.6, 0.4, 0.6, 0, () => {});
  }
}
