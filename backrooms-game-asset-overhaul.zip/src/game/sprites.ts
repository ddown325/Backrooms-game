import { makeCanvas, hash2 } from "./util";
import type { SpriteDef, Tex } from "./types";

type G = CanvasRenderingContext2D;
type P = [number, number];

/* ---------------------------------------------------------------- helpers */
export function paint(w: number, h: number, draw: (g: G, w: number, h: number) => void): Tex {
  const c = makeCanvas(w, h);
  const g = c.getContext("2d") as G;
  g.lineJoin = "round";
  g.lineCap = "round";
  draw(g, w, h);
  return { w, h, d: g.getImageData(0, 0, w, h).data };
}

const bez = (a: P, b: P, c: P, n = 12): P[] => {
  const out: P[] = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n, m = 1 - t;
    out.push([m * m * a[0] + 2 * m * t * b[0] + t * t * c[0], m * m * a[1] + 2 * m * t * b[1] + t * t * c[1]]);
  }
  return out;
};

/** tapered limb with a highlight pass */
function limb(g: G, pts: P[], w0: number, w1: number, base: string, hi?: string) {
  const n = pts.length - 1;
  for (let pass = 0; pass < (hi ? 2 : 1); pass++) {
    g.strokeStyle = pass === 0 ? base : (hi as string);
    for (let i = 0; i < n; i++) {
      const t = i / n;
      const w = w0 + (w1 - w0) * t;
      g.lineWidth = pass === 0 ? w : w * 0.4;
      g.beginPath();
      const off = pass === 0 ? 0 : -w * 0.2;
      g.moveTo(pts[i][0] + off, pts[i][1]);
      g.lineTo(pts[i + 1][0] + off, pts[i + 1][1]);
      g.stroke();
    }
  }
}

function ell(g: G, x: number, y: number, rx: number, ry: number, fill: string | CanvasGradient, rot = 0) {
  g.beginPath();
  g.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2);
  g.fillStyle = fill;
  g.fill();
}

function rgrad(g: G, x: number, y: number, r: number, stops: [number, string][], fx?: number, fy?: number) {
  const gr = g.createRadialGradient(fx ?? x, fy ?? y, 0, x, y, r);
  for (const [o, c] of stops) gr.addColorStop(o, c);
  return gr;
}

function lgrad(g: G, x0: number, y0: number, x1: number, y1: number, stops: [number, string][]) {
  const gr = g.createLinearGradient(x0, y0, x1, y1);
  for (const [o, c] of stops) gr.addColorStop(o, c);
  return gr;
}

/** side lighting + grain, only where something has been painted */
function finish(g: G, w: number, h: number, grainAmt = 10, dark = 0.34) {
  g.globalCompositeOperation = "source-atop";
  g.fillStyle = lgrad(g, 0, 0, w, 0, [[0, "rgba(255,255,255,0.10)"], [0.45, "rgba(0,0,0,0)"], [1, `rgba(0,0,0,${dark})`]]);
  g.fillRect(0, 0, w, h);
  g.fillStyle = lgrad(g, 0, 0, 0, h, [[0, "rgba(255,255,255,0.05)"], [0.6, "rgba(0,0,0,0)"], [1, "rgba(0,0,0,0.28)"]]);
  g.fillRect(0, 0, w, h);
  g.globalCompositeOperation = "source-over";
  if (grainAmt > 0) {
    const id = g.getImageData(0, 0, w, h);
    const d = id.data;
    for (let i = 0, p = 0; i < d.length; i += 4, p++) {
      if (d[i + 3] < 8) continue;
      const n = (hash2(p % w, (p / w) | 0, 77) - 0.5) * grainAmt;
      d[i] += n; d[i + 1] += n; d[i + 2] += n;
    }
    g.putImageData(id, 0, 0);
  }
}

function sprite(frames: Tex[], w: number, h: number, o: Partial<SpriteDef> = {}): SpriteDef {
  return { frames, w, h, elev: 0, glow: 0, shadow: true, solid: false, r: 0, ...o };
}

/* ---------------------------------------------------------------- THE LISTENER */
function listenerFrame(f: number): Tex {
  return paint(112, 288, (g, w, h) => {
    const cx = 56;
    const sway = f === 1 ? -8 : f === 2 ? 8 : 0;
    const rush = f === 3;
    const skin = "#c9c3b4", skinHi = "#e6e1d3", skinLo = "#8d887c";
    // legs
    for (const s of [-1, 1]) {
      const hip: P = [cx + s * 9, 174];
      const knee: P = [cx + s * 11 + sway * s * 0.5, 228];
      const foot: P = [cx + s * 13 + sway * s * (f === 0 ? 0 : 1.2), 281];
      limb(g, bez(hip, knee, foot, 14), 13, 6, skinLo, skin);
      ell(g, foot[0] + s * 3, 282, 11, 4, skinLo);
    }
    // torso
    g.beginPath();
    g.moveTo(34, 68);
    g.quadraticCurveTo(28, 124, 43, 180);
    g.lineTo(69, 180);
    g.quadraticCurveTo(84, 124, 78, 68);
    g.quadraticCurveTo(56, 58, 34, 68);
    g.fillStyle = lgrad(g, 30, 0, 82, 0, [[0, skinHi], [0.5, skin], [1, skinLo]]);
    g.fill();
    // ribs
    g.strokeStyle = "rgba(60,56,50,0.4)";
    g.lineWidth = 1.6;
    for (let i = 0; i < 6; i++) {
      g.beginPath();
      g.moveTo(40 + i * 0.6, 84 + i * 9);
      g.quadraticCurveTo(56, 90 + i * 9, 72 - i * 0.6, 84 + i * 9);
      g.stroke();
    }
    // the ruin of a shirt and tie
    g.beginPath();
    g.moveTo(33, 70);
    g.lineTo(33, 150); g.lineTo(38, 142); g.lineTo(42, 158); g.lineTo(47, 146); g.lineTo(53, 162);
    g.lineTo(60, 148); g.lineTo(66, 160); g.lineTo(71, 144); g.lineTo(76, 152); g.lineTo(79, 70);
    g.quadraticCurveTo(56, 60, 33, 70);
    g.fillStyle = lgrad(g, 30, 0, 82, 0, [[0, "#7d7a70"], [1, "#4a483f"]]);
    g.fill();
    g.strokeStyle = "rgba(20,18,14,.5)";
    g.lineWidth = 1.2;
    g.beginPath(); g.moveTo(56, 66); g.lineTo(56, 150); g.stroke();
    g.beginPath();
    g.moveTo(53, 66); g.lineTo(59, 66); g.lineTo(61, 84); g.lineTo(58, 128); g.lineTo(54, 126); g.lineTo(52, 84);
    g.fillStyle = "#5c1d1a";
    g.fill();
    // veins
    g.strokeStyle = "rgba(70,86,110,0.35)";
    g.lineWidth = 1;
    for (const [a, b, c] of [[[44, 70], [30, 100], [40, 130]], [[70, 72], [86, 104], [74, 140]]] as P[][]) {
      g.beginPath(); g.moveTo(a[0], a[1]); g.quadraticCurveTo(b[0], b[1], c[0], c[1]); g.stroke();
    }
    // arms
    for (const s of [-1, 1]) {
      const sh: P = [cx + s * 21, 72];
      let el: P, hd: P;
      if (rush) { el = [cx + s * 48, 108]; hd = [cx + s * 30, 66]; }
      else { el = [cx + s * 45, 152]; hd = [cx + s * 36 - sway * s * 0.4 + sway * 0.5, 236]; }
      limb(g, bez(sh, el, hd, 16), 10, 5, skinLo, skin);
      // long fingers
      g.strokeStyle = skinLo;
      g.lineWidth = 2.4;
      for (let i = -2; i <= 2; i++) {
        g.beginPath();
        g.moveTo(hd[0], hd[1]);
        const dir = rush ? -1 : 1;
        g.lineTo(hd[0] + i * 4 + s * 2, hd[1] + dir * (22 - Math.abs(i) * 3));
        g.stroke();
      }
    }
    // neck + head
    g.fillStyle = skinLo;
    g.fillRect(50, 50, 12, 24);
    const hy = rush ? 40 : 32;
    g.save();
    g.translate(56, hy);
    g.rotate(rush ? 0.2 : 0.08);
    // ears: it listens
    for (const s of [-1, 1]) {
      g.beginPath();
      g.moveTo(s * 17, -4);
      g.quadraticCurveTo(s * 40, -22, s * 36, -34);
      g.quadraticCurveTo(s * 28, -10, s * 17, 16);
      g.fillStyle = "#a7a194";
      g.fill();
      g.beginPath();
      g.moveTo(s * 19, -2);
      g.quadraticCurveTo(s * 33, -16, s * 33, -28);
      g.quadraticCurveTo(s * 26, -8, s * 19, 10);
      g.fillStyle = "rgba(110,60,60,0.45)";
      g.fill();
    }
    ell(g, 0, 0, 19, 28, rgrad(g, 0, 0, 30, [[0, skinHi], [0.7, skin], [1, skinLo]], -5, -8));
    // no eyes, only the suggestion of where they were
    ell(g, -7, -4, 5.5, 3, "rgba(40,34,34,0.28)");
    ell(g, 7, -4, 5.5, 3, "rgba(40,34,34,0.28)");
    if (rush) {
      ell(g, 0, 14, 9, 14, rgrad(g, 0, 14, 14, [[0, "#14090a"], [1, "#3a1a1a"]]));
      g.fillStyle = "#d8d2c0";
      for (let i = -3; i <= 3; i++) g.fillRect(i * 2.4 - 0.6, 2, 1.4, 4);
    } else {
      g.strokeStyle = "#2b2220";
      g.lineWidth = 1.8;
      g.beginPath(); g.moveTo(-12, 15); g.quadraticCurveTo(0, 18, 12, 14); g.stroke();
      g.lineWidth = 1;
      for (let i = -4; i <= 4; i++) { g.beginPath(); g.moveTo(i * 2.6, 13); g.lineTo(i * 2.6, 19); g.stroke(); }
    }
    g.restore();
    finish(g, w, h, 12);
  });
}

/* ---------------------------------------------------------------- CRAWLER */
function crawlerFrame(f: number): Tex {
  return paint(192, 96, (g, w, h) => {
    const lunge = f === 2;
    const gy = 90;
    const body = "#b9a9a0", bodyLo = "#6b5d58";
    // eight jointed legs
    for (let i = 0; i < 8; i++) {
      const ax = 56 + (i >> 1) * 20 + (i & 1) * 5;
      const alt = (i + f) & 1;
      let fx = ax + (i & 1 ? -30 : 22);
      let fy = gy;
      if (lunge) fx = ax - 34 - (i >> 1) * 5;
      if (!lunge && alt) { fx += 7; fy = gy - 7; }
      const kx = (ax + fx) / 2 + (i & 1 ? -10 : 8), ky = lunge ? 44 : 28 + (alt ? 4 : 0);
      limb(g, [...bez([ax, 56], [kx, ky], [kx + (fx - kx) * 0.5, ky + 10], 6), ...bez([kx + (fx - kx) * 0.5, ky + 10], [fx - 2, (ky + fy) / 2], [fx, fy], 6)], 5, 1.6, "#241b19", "#463a36");
    }
    // tail segments
    for (let i = 0; i < 4; i++) ell(g, 62 - i * 11, 58 - i * 2, 15 - i * 2.4, 12 - i * 2, rgrad(g, 62 - i * 11, 58, 18, [[0, body], [1, bodyLo]]));
    // torso
    ell(g, 100, 54, 46, 20, rgrad(g, 100, 54, 50, [[0, "#d1c3b9"], [0.7, body], [1, bodyLo]], 92, 44));
    g.strokeStyle = "rgba(50,38,36,0.45)";
    g.lineWidth = 1.5;
    for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(72 + i * 9, 40); g.quadraticCurveTo(76 + i * 9, 54, 72 + i * 9, 68); g.stroke(); }
    for (let i = 0; i < 9; i++) ell(g, 62 + i * 9, 36 + Math.abs(i - 4) * 0.8, 2.2, 3, "#7a6a64");
    // head with a face that is far too wide
    const hx = 150, hy = lunge ? 36 : 44;
    ell(g, hx, hy, 22, 21, rgrad(g, hx, hy, 26, [[0, "#e3d6cc"], [0.75, "#b8a89d"], [1, "#74645e"]], hx - 6, hy - 8));
    ell(g, hx - 8, hy - 5, 4.5, 6, "#140d0d");
    ell(g, hx + 8, hy - 5, 4.5, 6, "#140d0d");
    ell(g, hx - 8, hy - 6, 1.3, 1.6, "#d8d0c0");
    ell(g, hx + 8, hy - 6, 1.3, 1.6, "#d8d0c0");
    g.beginPath();
    const open = lunge ? 14 : 5;
    g.moveTo(hx - 19, hy + 4);
    g.quadraticCurveTo(hx, hy + 8 + open * 2, hx + 19, hy + 4);
    g.quadraticCurveTo(hx, hy + 4 + open * 0.2, hx - 19, hy + 4);
    g.fillStyle = "#1b0c0d";
    g.fill();
    g.fillStyle = "#e6dfcc";
    for (let i = -8; i <= 8; i++) {
      const tx = hx + i * 2.2;
      const ty = hy + 5 + (1 - (i / 9) ** 2) * (2 + open * 0.2);
      g.fillRect(tx - 0.5, ty - 1, 1.2, 3.4);
    }
    finish(g, w, h, 12);
  });
}

/* ---------------------------------------------------------------- WARDEN */
function wardenFrame(f: number): Tex {
  return paint(128, 240, (g, w, h) => {
    const step = f === 1 ? 1 : f === 2 ? -1 : 0;
    const coat = "#3d3a2a", coatHi = "#6a6446", coatLo = "#17160f";
    // chain / pipe dragged behind
    g.strokeStyle = "#2a2a28";
    g.lineWidth = 4;
    g.beginPath(); g.moveTo(100, 140); g.quadraticCurveTo(116, 200, 96 + step * 6, 234); g.stroke();
    g.strokeStyle = "#8c8c86";
    g.lineWidth = 1.4;
    g.beginPath(); g.moveTo(98, 142); g.quadraticCurveTo(114, 200, 94 + step * 6, 233); g.stroke();
    // boots + legs
    for (const s of [-1, 1]) {
      const x = 64 + s * 16 + step * s * 5;
      limb(g, [[64 + s * 12, 160], [x, 200], [x, 224]], 24, 18, coatLo, "#2c2a1c");
      ell(g, x + s * 3, 230, 18, 8, "#0f0f0c");
    }
    // coat body, wide shoulders
    g.beginPath();
    g.moveTo(26, 78);
    g.quadraticCurveTo(20, 60, 42, 52);
    g.lineTo(86, 52);
    g.quadraticCurveTo(108, 60, 102, 78);
    g.quadraticCurveTo(108, 130, 98, 190);
    g.lineTo(30, 190);
    g.quadraticCurveTo(20, 130, 26, 78);
    g.fillStyle = lgrad(g, 20, 0, 108, 0, [[0, coatHi], [0.5, coat], [1, coatLo]]);
    g.fill();
    // reflective strips and coat seams
    g.fillStyle = "#c2a52e";
    g.fillRect(28, 150, 72, 5);
    g.fillRect(28, 165, 72, 3);
    g.fillStyle = "rgba(255,255,255,0.18)";
    g.fillRect(28, 150, 72, 1.4);
    g.strokeStyle = "rgba(0,0,0,0.5)";
    g.lineWidth = 1.5;
    g.beginPath(); g.moveTo(64, 70); g.lineTo(64, 190); g.stroke();
    for (const y of [96, 120]) { g.beginPath(); g.moveTo(30, y); g.quadraticCurveTo(64, y + 8, 98, y); g.stroke(); }
    // arms
    limb(g, [[34, 70], [14, 112], [20, 152 + step * 5]], 22, 14, coat, coatHi);
    ell(g, 20, 156 + step * 5, 10, 9, "#111");
    limb(g, [[94, 70], [112, 108], [104, 146]], 22, 14, coat, coatHi);
    ell(g, 103, 150, 10, 9, "#111");
    // lantern
    const lx = 20, ly = 168 + step * 5;
    g.globalCompositeOperation = "lighter";
    ell(g, lx, ly + 6, 34, 34, rgrad(g, lx, ly + 6, 34, [[0, "rgba(255,190,90,0.7)"], [0.4, "rgba(255,150,60,0.22)"], [1, "rgba(255,120,40,0)"]]));
    g.globalCompositeOperation = "source-over";
    g.strokeStyle = "#1a1a18";
    g.lineWidth = 2.4;
    g.beginPath(); g.moveTo(lx, ly - 8); g.lineTo(lx, ly - 3); g.stroke();
    g.fillStyle = "#2a2a26";
    g.fillRect(lx - 8, ly - 4, 16, 3);
    g.fillRect(lx - 8, ly + 15, 16, 3);
    g.fillStyle = rgrad(g, lx, ly + 7, 10, [[0, "#fff2c4"], [0.5, "#ffb54a"], [1, "#b8641e"]]);
    g.fillRect(lx - 6, ly - 1, 12, 16);
    g.strokeStyle = "#1a1a18";
    g.lineWidth = 1;
    g.beginPath(); g.moveTo(lx, ly - 1); g.lineTo(lx, ly + 15); g.stroke();
    // hood + mask
    g.beginPath();
    g.moveTo(34, 62);
    g.quadraticCurveTo(30, 14, 64, 10);
    g.quadraticCurveTo(98, 14, 94, 62);
    g.quadraticCurveTo(64, 48, 34, 62);
    g.fillStyle = lgrad(g, 30, 0, 98, 0, [[0, coatHi], [1, coatLo]]);
    g.fill();
    ell(g, 64, 38, 20, 22, rgrad(g, 64, 38, 24, [[0, "#3c3f38"], [1, "#0f100d"]], 58, 30));
    for (const s of [-1, 1]) {
      ell(g, 64 + s * 9, 34, 7.5, 7.5, "#0a0b09");
      ell(g, 64 + s * 9, 34, 6, 6, rgrad(g, 64 + s * 9, 34, 7, [[0, "#7a8e6c"], [1, "#1c2418"]], 62 + s * 9, 31));
      ell(g, 62 + s * 9, 31, 1.8, 1.8, "rgba(255,255,255,0.7)");
    }
    // filter canister and hose
    ell(g, 64, 54, 9, 8, "#232420");
    g.strokeStyle = "#1a1b17";
    g.lineWidth = 5;
    g.beginPath(); g.moveTo(64, 60); g.quadraticCurveTo(58, 90, 70, 108); g.stroke();
    finish(g, w, h, 12, 0.4);
  });
}

/* ---------------------------------------------------------------- MANNEQUIN */
function mannequinFrame(pose: number): Tex {
  return paint(96, 240, (g, w, h) => {
    const cx = 48;
    const plas = "#d9cdb6", hi = "#f3ead8", lo = "#8f836c";
    const seam = () => { g.strokeStyle = "rgba(60,50,38,0.55)"; g.lineWidth = 1.2; };
    // legs
    for (const s of [-1, 1]) {
      limb(g, [[cx + s * 8, 138], [cx + s * 10, 186], [cx + s * 10, 226]], 16, 10, lo, plas);
      ell(g, cx + s * 10, 228, 7, 3, lo);
    }
    // plinth stub left on one foot
    g.fillStyle = "#3a3630";
    g.fillRect(cx - 24, 232, 48, 4);
    // torso
    g.beginPath();
    g.moveTo(cx - 24, 60);
    g.quadraticCurveTo(cx - 30, 100, cx - 16, 146);
    g.lineTo(cx + 16, 146);
    g.quadraticCurveTo(cx + 30, 100, cx + 24, 60);
    g.quadraticCurveTo(cx, 52, cx - 24, 60);
    g.fillStyle = lgrad(g, cx - 30, 0, cx + 30, 0, [[0, hi], [0.5, plas], [1, lo]]);
    g.fill();
    seam();
    g.beginPath(); g.moveTo(cx - 19, 112); g.quadraticCurveTo(cx, 118, cx + 19, 112); g.stroke();
    g.beginPath(); g.moveTo(cx, 62); g.lineTo(cx, 144); g.stroke();
    // arms by pose
    const arm = (s: number, up: number) => {
      const sh: P = [cx + s * 24, 66];
      let el: P, hd: P;
      if (pose === 2) { el = [cx + s * 34, 98]; hd = [cx + s * 20, 70 - up * 0]; }
      else if (up) { el = [cx + s * 40, 52]; hd = [cx + s * 30, 12]; }
      else { el = [cx + s * 32, 108]; hd = [cx + s * 30, 150]; }
      limb(g, bez(sh, el, hd, 12), 11, 7, lo, plas);
      ell(g, el[0], el[1], 4.5, 4.5, lo);
      // hand: stiff, fingers fused
      ell(g, hd[0], hd[1] + (up || pose === 2 ? -4 : 6), 5, 9, plas, up || pose === 2 ? 0.2 * s : 0);
    };
    arm(-1, pose === 1 ? 1 : 0);
    arm(1, 0);
    // neck + blank head
    g.fillStyle = lo;
    g.fillRect(cx - 5, 44, 10, 18);
    const tilt = pose === 2 ? 0.28 : pose === 1 ? -0.12 : 0;
    g.save();
    g.translate(cx, 30);
    g.rotate(tilt);
    ell(g, 0, 0, 15, 20, rgrad(g, 0, 0, 24, [[0, hi], [0.65, plas], [1, lo]], -5, -7));
    g.fillStyle = "rgba(90,78,60,0.35)";
    ell(g, 0, 3, 2.2, 5, "rgba(90,78,60,0.35)");
    if (pose === 2) {
      // it has learned to smile
      g.strokeStyle = "#2a1a16";
      g.lineWidth = 1.4;
      g.beginPath(); g.moveTo(-8, 11); g.quadraticCurveTo(0, 17, 8, 11); g.stroke();
    }
    g.restore();
    // hairline crack
    g.strokeStyle = "rgba(40,34,26,0.5)";
    g.lineWidth = 1;
    g.beginPath(); g.moveTo(cx + 6, 20); g.lineTo(cx + 9, 32); g.lineTo(cx + 5, 38); g.stroke();
    finish(g, w, h, 8);
  });
}

/* ---------------------------------------------------------------- WATCHER */
function watcherFrame(f: number): Tex {
  return paint(96, 200, (g) => {
    g.shadowColor = "rgba(0,0,0,0.95)";
    g.shadowBlur = 9;
    g.fillStyle = "#050505";
    // long, wrong proportions
    limb(g, bez([48, 60], [40, 130], [44, 198], 12), 16, 7, "#050505");
    limb(g, bez([54, 60], [60, 130], [54, 198], 12), 16, 7, "#050505");
    g.beginPath();
    g.moveTo(26, 64); g.quadraticCurveTo(48, 50, 70, 64); g.quadraticCurveTo(66, 120, 56, 140); g.lineTo(40, 140); g.quadraticCurveTo(28, 120, 26, 64);
    g.fill();
    limb(g, bez([28, 66], [6, 120], [10, 178 + f * 4], 12), 7, 3, "#050505");
    limb(g, bez([68, 66], [92, 120], [86, 176 - f * 4], 12), 7, 3, "#050505");
    ell(g, 48, 36, 15, 24, "#050505", 0.04 * (f ? 1 : -1));
    g.shadowBlur = 0;
    // eyes
    g.globalCompositeOperation = "lighter";
    for (const s of [-1, 1]) {
      const ex = 48 + s * 7, ey = 33 + (s > 0 ? 1.5 : 0);
      ell(g, ex, ey, 20, 14, rgrad(g, ex, ey, 20, [[0, "rgba(220,230,200,0.5)"], [1, "rgba(220,230,200,0)"]]));
    }
    g.globalCompositeOperation = "source-over";
    for (const s of [-1, 1]) {
      ell(g, 48 + s * 7, 33 + (s > 0 ? 1.5 : 0), 3.2, 5.2, "#f2f6df", s * 0.25);
    }
  });
}

/* ---------------------------------------------------------------- DROWNED */
function drownedFrame(f: number): Tex {
  return paint(128, 128, (g, w, h) => {
    const bob = f === 1 ? 3 : 0;
    // ripples
    for (let i = 0; i < 3; i++) {
      g.strokeStyle = `rgba(190,225,235,${0.5 - i * 0.14})`;
      g.lineWidth = 2;
      g.beginPath(); g.ellipse(64, 112 + bob * 0.3, 30 + i * 12, 7 + i * 3, 0, 0, Math.PI * 2); g.stroke();
    }
    // shoulders and arm
    g.beginPath();
    g.moveTo(26, 118); g.quadraticCurveTo(24, 76 + bob, 52, 70 + bob); g.lineTo(78, 70 + bob); g.quadraticCurveTo(104, 76 + bob, 102, 118);
    g.fillStyle = lgrad(g, 24, 0, 104, 0, [[0, "#9db0b2"], [0.6, "#6f8688"], [1, "#3c4d52"]]);
    g.fill();
    limb(g, bez([92, 84 + bob], [118, 56], [108, 18 + bob * 2], 12), 12, 5, "#506468", "#88a0a2");
    g.strokeStyle = "#506468";
    g.lineWidth = 2;
    for (let i = -2; i <= 2; i++) { g.beginPath(); g.moveTo(108, 20 + bob * 2); g.lineTo(108 + i * 4, 2 + Math.abs(i) * 2 + bob * 2); g.stroke(); }
    // head
    ell(g, 60, 52 + bob, 17, 21, rgrad(g, 60, 52, 24, [[0, "#b6c6c6"], [1, "#4f6468"]], 54, 44));
    // plastered hair
    g.strokeStyle = "#0a0d10";
    for (let i = 0; i < 22; i++) {
      const x0 = 46 + i * 1.5;
      g.lineWidth = 2.2;
      g.beginPath(); g.moveTo(x0, 36 + bob); g.quadraticCurveTo(x0 + (i % 2 ? 7 : -7), 66 + bob, x0 + (i - 11) * 1.4, 100 + bob); g.stroke();
    }
    ell(g, 60, 49 + bob, 11, 4, "rgba(0,0,0,0.5)");
    ell(g, 56, 49 + bob, 1.6, 1.4, "#d8e8e0");
    ell(g, 65, 49 + bob, 1.6, 1.4, "#d8e8e0");
    // drips
    g.strokeStyle = "rgba(210,235,240,0.55)";
    g.lineWidth = 1.6;
    for (const x of [44, 62, 80]) { g.beginPath(); g.moveTo(x, 90 + bob); g.lineTo(x, 100 + bob + (x % 3) * 3); g.stroke(); }
    finish(g, w, h, 8, 0.3);
  });
}

/* ---------------------------------------------------------------- HOUND */
function houndFrame(f: number): Tex {
  return paint(192, 112, (g, w, h) => {
    const snarl = f === 2;
    const skin = "#7d746a", hi = "#a39a8e", lo = "#3a342e";
    const gy = 106;
    const cyc = f === 0 ? 0 : f === 1 ? 1 : 0.5;
    // four long legs
    const legs: [number, number, number][] = [[58, -1, 0], [74, 1, 0.5], [130, -1, 0.5], [146, 1, 0]];
    for (const [ax, dir, ph] of legs) {
      const reach = snarl ? 4 : Math.sin((cyc + ph) * Math.PI * 2) * 18;
      const lift = snarl ? 0 : Math.max(0, Math.cos((cyc + ph) * Math.PI * 2)) * 10;
      const foot: P = [ax + dir * 6 + reach, gy - lift];
      const knee: P = [ax + dir * 14 + reach * 0.4, 78];
      limb(g, [...bez([ax, 56], knee, [knee[0] - dir * 6, 86], 6), ...bez([knee[0] - dir * 6, 86], [foot[0] - 4, 96], foot, 6)], 12, 3.4, lo, skin);
      ell(g, foot[0] + 2, foot[1], 7, 3, lo);
    }
    // gaunt body
    g.beginPath();
    g.moveTo(34, 44); g.quadraticCurveTo(68, 30, 112, 38); g.quadraticCurveTo(150, 36, 156, 56);
    g.quadraticCurveTo(110, 82, 74, 70); g.quadraticCurveTo(44, 66, 34, 44);
    g.fillStyle = lgrad(g, 0, 30, 0, 84, [[0, hi], [0.5, skin], [1, lo]]);
    g.fill();
    g.strokeStyle = "rgba(20,16,14,0.55)";
    g.lineWidth = 1.6;
    for (let i = 0; i < 7; i++) { g.beginPath(); g.moveTo(80 + i * 9, 40 + i * 0.4); g.quadraticCurveTo(84 + i * 9, 56, 78 + i * 9, 70); g.stroke(); }
    for (let i = 0; i < 12; i++) ell(g, 40 + i * 9, 38 - Math.sin(i / 11 * Math.PI) * 8 + 8, 2.3, 2.8, "#5a5249");
    // skull-like head
    const hy = snarl ? 50 : 56;
    g.beginPath();
    g.moveTo(138, hy - 14); g.quadraticCurveTo(160, hy - 22, 180, hy - 4); g.lineTo(184, hy + 2);
    g.lineTo(136, hy + 10); g.quadraticCurveTo(128, hy - 2, 138, hy - 14);
    g.fillStyle = lgrad(g, 0, hy - 20, 0, hy + 10, [[0, hi], [1, skin]]);
    g.fill();
    // jaw
    const jaw = snarl ? 22 : 7;
    g.beginPath();
    g.moveTo(138, hy + 8); g.lineTo(184, hy + 3 + jaw * 0.2); g.lineTo(176, hy + 6 + jaw); g.lineTo(142, hy + 10 + jaw * 0.6);
    g.fillStyle = lo;
    g.fill();
    g.fillStyle = "#1a0b0b";
    g.beginPath(); g.moveTo(140, hy + 8); g.lineTo(184, hy + 3); g.lineTo(178, hy + 5 + jaw * 0.6); g.lineTo(144, hy + 9 + jaw * 0.4); g.fill();
    g.fillStyle = "#e4dcc6";
    for (let i = 0; i < 8; i++) {
      const tx = 144 + i * 5;
      g.beginPath(); g.moveTo(tx, hy + 6); g.lineTo(tx + 1.8, hy + 6 + 5); g.lineTo(tx + 3.6, hy + 6); g.fill();
      g.beginPath(); g.moveTo(tx + 1, hy + 9 + jaw * 0.6); g.lineTo(tx + 2.6, hy + 9 + jaw * 0.6 - 5); g.lineTo(tx + 4, hy + 9 + jaw * 0.6); g.fill();
    }
    // eyes: milky, sunken
    ell(g, 156, hy - 8, 4.5, 3.4, "#0c0908");
    ell(g, 156, hy - 8, 2, 1.6, "#d6d9b8");
    // ears
    g.beginPath(); g.moveTo(142, hy - 12); g.lineTo(138, hy - 30); g.lineTo(152, hy - 17); g.fillStyle = lo; g.fill();
    finish(g, w, h, 12);
  });
}

/* ---------------------------------------------------------------- PROPS */
interface PropDef {
  h: number;
  aspect: number;
  solid: boolean;
  r: number;
  glow?: number;
  draw: (g: G, w: number, h: number) => void;
}

const box = (g: G, x: number, y: number, w: number, h: number, c: string, hi = "rgba(255,255,255,0.16)", lo = "rgba(0,0,0,0.3)") => {
  g.fillStyle = c;
  g.fillRect(x, y, w, h);
  g.fillStyle = lgrad(g, x, 0, x + w, 0, [[0, hi], [0.5, "rgba(0,0,0,0)"], [1, lo]]);
  g.fillRect(x, y, w, h);
};

const PROPS: Record<string, PropDef> = {
  desk: { h: 0.4, aspect: 1.9, solid: true, r: 0.3, draw(g, w, h) {
    box(g, 0, h * 0.2, w, h * 0.1, "#6e5638");
    box(g, 4, h * 0.3, 8, h * 0.7, "#4a3a26"); box(g, w - 12, h * 0.3, 8, h * 0.7, "#4a3a26");
    box(g, w * 0.55, h * 0.3, w * 0.4, h * 0.5, "#5a4630");
    g.fillStyle = "#2a2118"; g.fillRect(w * 0.7, h * 0.42, w * 0.1, 4);
    // papers and a lamp
    g.fillStyle = "#d7d0b8"; g.fillRect(w * 0.12, h * 0.13, w * 0.2, 4); g.fillRect(w * 0.16, h * 0.1, w * 0.17, 4);
    g.strokeStyle = "#222"; g.lineWidth = 3; g.beginPath(); g.moveTo(w * 0.8, h * 0.2); g.lineTo(w * 0.82, 4); g.lineTo(w * 0.7, 2); g.stroke();
  } },
  chair: { h: 0.46, aspect: 0.7, solid: true, r: 0.12, draw(g, w, h) {
    box(g, w * 0.12, h * 0.02, w * 0.76, h * 0.42, "#2c3138");
    box(g, w * 0.06, h * 0.44, w * 0.88, h * 0.12, "#363c44");
    box(g, w * 0.46, h * 0.56, w * 0.08, h * 0.28, "#222");
    g.strokeStyle = "#1c1c1c"; g.lineWidth = 3;
    for (const x of [0.1, 0.5, 0.9]) { g.beginPath(); g.moveTo(w * 0.5, h * 0.84); g.lineTo(w * x, h * 0.97); g.stroke(); }
  } },
  cabinet: { h: 0.62, aspect: 0.5, solid: true, r: 0.15, draw(g, w, h) {
    box(g, 0, 0, w, h, "#7b8187");
    g.strokeStyle = "rgba(0,0,0,0.5)"; g.lineWidth = 2;
    for (let i = 0; i < 4; i++) {
      const y = 4 + i * (h / 4);
      g.strokeRect(4, y, w - 8, h / 4 - 6);
      g.fillStyle = "#3b3f42"; g.fillRect(w * 0.35, y + h / 8 - 4, w * 0.3, 4);
      g.fillStyle = "#d3d0c0"; g.fillRect(w * 0.3, y + 6, w * 0.4, 7);
    }
  } },
  cooler: { h: 0.58, aspect: 0.42, solid: true, r: 0.11, draw(g, w, h) {
    box(g, 2, h * 0.36, w - 4, h * 0.64, "#cfd3d4");
    g.fillStyle = "#2e6fa8"; g.fillRect(w * 0.34, h * 0.56, w * 0.12, 7); g.fillStyle = "#b03a2e"; g.fillRect(w * 0.56, h * 0.56, w * 0.12, 7);
    const gr = lgrad(g, 0, 0, w, 0, [[0, "rgba(140,200,235,0.8)"], [0.5, "rgba(190,230,250,0.85)"], [1, "rgba(80,140,180,0.8)"]]);
    g.fillStyle = gr;
    g.beginPath(); g.moveTo(6, h * 0.36); g.quadraticCurveTo(0, h * 0.06, w * 0.5, 0); g.quadraticCurveTo(w, h * 0.06, w - 6, h * 0.36); g.fill();
    g.fillStyle = "rgba(255,255,255,0.45)"; g.fillRect(w * 0.2, h * 0.08, 3, h * 0.2);
  } },
  plant: { h: 0.54, aspect: 0.7, solid: true, r: 0.1, draw(g, w, h) {
    box(g, w * 0.28, h * 0.7, w * 0.44, h * 0.3, "#6b3d2a");
    for (let i = 0; i < 9; i++) {
      const a = -Math.PI / 2 + (i - 4) * 0.34;
      const L = h * (0.42 + (i % 3) * 0.06);
      g.strokeStyle = "#2f5a2c"; g.lineWidth = 3;
      g.beginPath(); g.moveTo(w / 2, h * 0.72); g.quadraticCurveTo(w / 2 + Math.cos(a) * L * 0.5, h * 0.72 + Math.sin(a) * L * 0.9, w / 2 + Math.cos(a) * L, h * 0.72 + Math.sin(a) * L); g.stroke();
      ell(g, w / 2 + Math.cos(a) * L, h * 0.72 + Math.sin(a) * L, 9, 5, i % 2 ? "#3f7a3a" : "#2d5e2c", a + Math.PI / 2);
    }
  } },
  boxes: { h: 0.34, aspect: 1.4, solid: true, r: 0.18, draw(g, w, h) {
    box(g, 0, h * 0.4, w * 0.58, h * 0.6, "#a27e51");
    box(g, w * 0.4, h * 0.1, w * 0.58, h * 0.9, "#b58b58");
    box(g, w * 0.08, h * 0.02, w * 0.4, h * 0.4, "#94714a");
    g.fillStyle = "rgba(220,200,150,0.55)"; g.fillRect(w * 0.6, h * 0.1, 5, h * 0.9); g.fillRect(0, h * 0.4, w * 0.58, 5);
    g.fillStyle = "#2a2a28"; g.fillRect(w * 0.7, h * 0.46, w * 0.15, h * 0.18);
  } },
  crt: { h: 0.24, aspect: 1.1, solid: false, r: 0, glow: 0.12, draw(g, w, h) {
    box(g, 0, 0, w, h * 0.82, "#b5ad98");
    g.fillStyle = rgrad(g, w * 0.5, h * 0.4, w * 0.5, [[0, "#6f8f86"], [1, "#1c2a28"]]);
    g.beginPath(); g.roundRect(w * 0.1, h * 0.08, w * 0.7, h * 0.62, 7); g.fill();
    g.fillStyle = "rgba(255,255,255,0.18)"; g.fillRect(w * 0.14, h * 0.12, w * 0.3, 3);
    box(g, w * 0.3, h * 0.82, w * 0.4, h * 0.18, "#8d8674");
  } },
  cone: { h: 0.24, aspect: 0.7, solid: false, r: 0, draw(g, w, h) {
    g.fillStyle = "#d9611e"; g.beginPath(); g.moveTo(w * 0.5, 0); g.lineTo(w * 0.86, h * 0.88); g.lineTo(w * 0.14, h * 0.88); g.fill();
    g.fillStyle = "#e8e4d6"; g.beginPath(); g.moveTo(w * 0.4, h * 0.32); g.lineTo(w * 0.6, h * 0.32); g.lineTo(w * 0.68, h * 0.55); g.lineTo(w * 0.32, h * 0.55); g.fill();
    box(g, 0, h * 0.88, w, h * 0.12, "#a84a18");
  } },
  pallet: { h: 0.4, aspect: 1.5, solid: true, r: 0.24, draw(g, w, h) {
    box(g, 0, h * 0.82, w, h * 0.18, "#8a6b43");
    for (let i = 0; i < 3; i++) box(g, w * (0.02 + i * 0.38), h * 0.72, w * 0.18, h * 0.12, "#6c5232");
    box(g, w * 0.04, h * 0.1, w * 0.46, h * 0.64, "#a8845a");
    box(g, w * 0.5, h * 0.3, w * 0.46, h * 0.44, "#9b7a50");
    g.fillStyle = "rgba(230,230,220,0.6)"; g.fillRect(w * 0.04, h * 0.1, w * 0.92, 3); g.fillRect(w * 0.04, h * 0.4, w * 0.92, 3);
  } },
  barrel: { h: 0.42, aspect: 0.62, solid: true, r: 0.12, draw(g, w, h) {
    g.fillStyle = lgrad(g, 0, 0, w, 0, [[0, "#38557a"], [0.35, "#5d82ad"], [1, "#1e3350"]]);
    g.beginPath(); g.roundRect(0, 0, w, h, 8); g.fill();
    g.fillStyle = "rgba(0,0,0,0.4)";
    for (const y of [0.12, 0.45, 0.82]) g.fillRect(0, h * y, w, 4);
    g.fillStyle = "#e0b030"; g.fillRect(w * 0.3, h * 0.55, w * 0.4, h * 0.2);
    g.fillStyle = "#2a2a2a"; g.fillRect(w * 0.36, h * 0.6, w * 0.28, 3);
  } },
  rack: { h: 0.72, aspect: 0.9, solid: true, r: 0.22, draw(g, w, h) {
    g.fillStyle = "#3b4b66"; g.fillRect(0, 0, 6, h); g.fillRect(w - 6, 0, 6, h);
    for (let i = 0; i < 4; i++) {
      const y = h * (0.04 + i * 0.24);
      box(g, 6, y + h * 0.18, w - 12, 5, "#2e3b52");
      if (i % 2 === 0) { box(g, w * 0.12, y + h * 0.04, w * 0.3, h * 0.14, "#9c7a4e"); box(g, w * 0.5, y + h * 0.08, w * 0.34, h * 0.1, "#7a8791"); }
      else { box(g, w * 0.16, y + h * 0.02, w * 0.6, h * 0.16, "#b69062"); }
    }
  } },
  tank: { h: 0.78, aspect: 0.8, solid: true, r: 0.28, draw(g, w, h) {
    g.fillStyle = lgrad(g, 0, 0, w, 0, [[0, "#6c5d4a"], [0.35, "#93806a"], [1, "#2e261d"]]);
    g.beginPath(); g.roundRect(w * 0.06, h * 0.06, w * 0.88, h * 0.88, w * 0.3); g.fill();
    g.fillStyle = "rgba(0,0,0,0.35)";
    for (const y of [0.3, 0.62]) g.fillRect(w * 0.06, h * y, w * 0.88, 4);
    g.fillStyle = "#2a2a28"; g.fillRect(w * 0.45, 0, w * 0.1, h * 0.1);
    g.strokeStyle = "#7a3a20"; g.lineWidth = 3; g.beginPath(); g.moveTo(w * 0.72, h * 0.2); g.quadraticCurveTo(w * 1.0, h * 0.3, w * 0.9, h * 0.85); g.stroke();
    ell(g, w * 0.34, h * 0.44, 9, 9, "#d8d2c0"); ell(g, w * 0.34, h * 0.44, 7, 7, "#222");
    g.strokeStyle = "#e8d89c"; g.lineWidth = 1.5; g.beginPath(); g.moveTo(w * 0.34, h * 0.44); g.lineTo(w * 0.34 + 5, h * 0.44 - 3); g.stroke();
  } },
  pipestand: { h: 0.9, aspect: 0.34, solid: true, r: 0.1, draw(g, w, h) {
    for (const [x, r] of [[0.35, 0.22], [0.7, 0.16]] as [number, number][]) {
      g.fillStyle = lgrad(g, w * (x - r), 0, w * (x + r), 0, [[0, "#6c6a64"], [0.4, "#a8a59a"], [1, "#2e2d2a"]]);
      g.fillRect(w * (x - r), 0, w * r * 2, h);
      g.fillStyle = "rgba(0,0,0,0.4)";
      for (const y of [0.2, 0.7]) g.fillRect(w * (x - r) - 1, h * y, w * r * 2 + 2, 5);
    }
    g.fillStyle = "#b8341f"; ell(g, w * 0.7, h * 0.45, 9, 9, "#b8341f");
  } },
  lounger: { h: 0.3, aspect: 2.1, solid: true, r: 0.28, draw(g, w, h) {
    g.fillStyle = "#e3e6e4";
    g.beginPath(); g.moveTo(0, h * 0.5); g.lineTo(w * 0.24, 0); g.lineTo(w * 0.36, 0); g.lineTo(w * 0.34, h * 0.5); g.lineTo(w, h * 0.5); g.lineTo(w, h * 0.7); g.lineTo(0, h * 0.7); g.fill();
    g.fillStyle = "#4fa8b8"; g.fillRect(w * 0.36, h * 0.46, w * 0.62, 5);
    g.strokeStyle = "#9ea5a5"; g.lineWidth = 4;
    for (const x of [0.12, 0.9]) { g.beginPath(); g.moveTo(w * x, h * 0.7); g.lineTo(w * x, h); g.stroke(); }
  } },
  lifebuoy: { h: 0.62, aspect: 0.5, solid: false, r: 0, draw(g, w, h) {
    g.strokeStyle = "#8c8f90"; g.lineWidth = 4; g.beginPath(); g.moveTo(w * 0.5, h * 0.4); g.lineTo(w * 0.5, h); g.stroke();
    g.strokeStyle = "#d6d6d0"; g.lineWidth = 12; g.beginPath(); g.arc(w * 0.5, h * 0.28, w * 0.34, 0, Math.PI * 2); g.stroke();
    g.strokeStyle = "#c13a2c"; g.lineWidth = 12;
    for (let i = 0; i < 4; i++) { g.beginPath(); g.arc(w * 0.5, h * 0.28, w * 0.34, i * Math.PI / 2 + 0.2, i * Math.PI / 2 + Math.PI / 4 + 0.2); g.stroke(); }
  } },
  palm: { h: 0.6, aspect: 0.8, solid: true, r: 0.1, draw(g, w, h) {
    box(g, w * 0.3, h * 0.76, w * 0.4, h * 0.24, "#c8c8c0");
    g.strokeStyle = "#6a5a3e"; g.lineWidth = 6; g.beginPath(); g.moveTo(w * 0.5, h * 0.78); g.quadraticCurveTo(w * 0.56, h * 0.4, w * 0.5, h * 0.2); g.stroke();
    for (let i = 0; i < 8; i++) {
      const a = -Math.PI / 2 + (i - 3.5) * 0.45;
      g.strokeStyle = i % 2 ? "#356b34" : "#2a5a2b"; g.lineWidth = 4;
      g.beginPath(); g.moveTo(w * 0.5, h * 0.2); g.quadraticCurveTo(w * 0.5 + Math.cos(a) * w * 0.3, h * 0.2 + Math.sin(a) * h * 0.1 - 6, w * 0.5 + Math.cos(a) * w * 0.46, h * 0.2 + Math.sin(a) * h * 0.14 + h * 0.18); g.stroke();
    }
  } },
  generator: { h: 0.52, aspect: 1.5, solid: true, r: 0.3, draw(g, w, h) {
    box(g, 0, h * 0.18, w, h * 0.72, "#b04a24");
    box(g, w * 0.04, h * 0.9, w * 0.92, h * 0.1, "#2c2c2c");
    g.fillStyle = "#222"; for (let i = 0; i < 6; i++) g.fillRect(w * 0.08 + i * 8, h * 0.3, 4, h * 0.34);
    box(g, w * 0.55, h * 0.28, w * 0.36, h * 0.4, "#3a3d3e");
    ell(g, w * 0.66, h * 0.48, 7, 7, "#d6d1b4"); ell(g, w * 0.82, h * 0.48, 7, 7, "#d6d1b4");
    g.fillStyle = "#e9c24a"; g.fillRect(w * 0.18, 0, w * 0.1, h * 0.2);
    g.strokeStyle = "#222"; g.lineWidth = 3; g.beginPath(); g.moveTo(w * 0.1, h * 0.18); g.lineTo(w * 0.1, 0); g.lineTo(w * 0.4, 0); g.stroke();
  } },
  transformer: { h: 0.7, aspect: 0.9, solid: true, r: 0.22, draw(g, w, h) {
    box(g, w * 0.08, h * 0.3, w * 0.84, h * 0.7, "#566066");
    for (let i = 0; i < 7; i++) box(g, w * 0.08 + i * 3, h * 0.38, 2, h * 0.52, "#3a4348");
    for (let i = 0; i < 3; i++) {
      const x = w * (0.22 + i * 0.28);
      g.fillStyle = "#c9c2b0"; g.fillRect(x - 4, h * 0.05, 8, h * 0.28);
      for (let k = 0; k < 4; k++) ell(g, x, h * (0.08 + k * 0.06), 8, 3, "#e0d9c6");
    }
    g.fillStyle = "#e9c24a"; g.fillRect(w * 0.7, h * 0.7, w * 0.16, h * 0.14);
  } },
  bench: { h: 0.28, aspect: 1.8, solid: true, r: 0.24, draw(g, w, h) {
    box(g, 0, 0, w, h * 0.22, "#a3855a");
    box(g, w * 0.06, h * 0.22, 8, h * 0.78, "#4a4a48"); box(g, w * 0.88, h * 0.22, 8, h * 0.78, "#4a4a48");
    g.fillStyle = "rgba(0,0,0,0.3)"; for (let i = 1; i < 5; i++) g.fillRect(w * i / 5, 0, 2, h * 0.22);
  } },
};

/* ---------------------------------------------------------------- PICKUPS */
const PICKUPS: Record<string, { h: number; aspect: number; draw: (g: G, w: number, h: number) => void }> = {
  water: { h: 0.17, aspect: 0.4, draw(g, w, h) {
    g.fillStyle = lgrad(g, 0, 0, w, 0, [[0, "rgba(180,215,230,0.95)"], [0.5, "rgba(235,248,252,0.95)"], [1, "rgba(120,160,185,0.95)"]]);
    g.beginPath(); g.roundRect(w * 0.14, h * 0.2, w * 0.72, h * 0.8, 6); g.fill();
    g.fillRect(w * 0.34, h * 0.06, w * 0.32, h * 0.18);
    g.fillStyle = "#d8bd8c"; g.fillRect(w * 0.14, h * 0.42, w * 0.72, h * 0.28);
    g.fillStyle = "#6b4a2a"; g.fillRect(w * 0.3, h * 0.52, w * 0.4, 3);
    g.fillStyle = "#e8d9c0"; g.fillRect(w * 0.32, h * 0.02, w * 0.36, h * 0.06);
  } },
  cell: { h: 0.14, aspect: 0.55, draw(g, w, h) {
    g.fillStyle = lgrad(g, 0, 0, w, 0, [[0, "#d6a71e"], [0.45, "#f2cc4a"], [1, "#8c6a10"]]);
    g.beginPath(); g.roundRect(w * 0.1, h * 0.16, w * 0.8, h * 0.84, 5); g.fill();
    g.fillStyle = "#1c1c1c"; g.fillRect(w * 0.1, h * 0.16, w * 0.8, h * 0.2);
    g.fillStyle = "#b8b8b0"; g.fillRect(w * 0.34, 0, w * 0.32, h * 0.18);
    g.fillStyle = "#1c1c1c"; g.fillRect(w * 0.22, h * 0.54, w * 0.56, h * 0.14);
  } },
  fuse: { h: 0.12, aspect: 1.1, draw(g, w, h) {
    g.fillStyle = lgrad(g, 0, 0, 0, h, [[0, "#f2efe6"], [1, "#9c988c"]]);
    g.beginPath(); g.roundRect(w * 0.14, h * 0.2, w * 0.72, h * 0.6, 6); g.fill();
    g.fillStyle = "#c79a4a"; g.fillRect(0, h * 0.12, w * 0.18, h * 0.76); g.fillRect(w * 0.82, h * 0.12, w * 0.18, h * 0.76);
    g.fillStyle = "#d9d0b6"; g.fillRect(w * 0.18, h * 0.12, 2, h * 0.76);
    g.strokeStyle = "#b02a22"; g.lineWidth = 2; g.beginPath(); g.moveTo(w * 0.24, h * 0.5); g.lineTo(w * 0.76, h * 0.5); g.stroke();
  } },
  key: { h: 0.14, aspect: 0.8, draw(g, w, h) {
    g.strokeStyle = "#d1a948"; g.lineWidth = 6; g.beginPath(); g.arc(w * 0.5, h * 0.24, w * 0.24, 0, Math.PI * 2); g.stroke();
    g.fillStyle = "#c29a38"; g.fillRect(w * 0.45, h * 0.4, w * 0.1, h * 0.56);
    g.fillRect(w * 0.55, h * 0.74, w * 0.2, h * 0.08); g.fillRect(w * 0.55, h * 0.88, w * 0.14, h * 0.08);
    g.fillStyle = "rgba(255,255,255,0.4)"; g.fillRect(w * 0.45, h * 0.4, 2, h * 0.5);
    g.fillStyle = "#c33"; g.fillRect(w * 0.2, h * 0.5, w * 0.2, h * 0.14);
  } },
};

/* ---------------------------------------------------------------- registry */
const cache = new Map<string, SpriteDef>();

export function propSprite(kind: string): SpriteDef {
  const hit = cache.get("p:" + kind);
  if (hit) return hit;
  const d = PROPS[kind];
  const ph = 128;
  const pw = Math.max(24, Math.round(ph * d.aspect));
  const tex = paint(pw, ph, (g, w, h) => { d.draw(g, w, h); finish(g, w, h, 9); });
  const s = sprite([tex], d.h * d.aspect, d.h, { solid: d.solid, r: d.r, glow: d.glow ?? 0, shadow: true });
  cache.set("p:" + kind, s);
  return s;
}

export function pickupSprite(kind: string): SpriteDef {
  const hit = cache.get("i:" + kind);
  if (hit) return hit;
  const d = PICKUPS[kind];
  const ph = 96;
  const pw = Math.round(ph * d.aspect);
  const tex = paint(pw, ph, (g, w, h) => { d.draw(g, w, h); finish(g, w, h, 6, 0.2); });
  const s = sprite([tex], d.h * d.aspect, d.h, { glow: 0.28, shadow: true, elev: 0.0 });
  cache.set("i:" + kind, s);
  return s;
}

export type EntityArt = "listener" | "crawler" | "warden" | "mannequin" | "watcher" | "drowned" | "hound";

export function entitySprite(kind: EntityArt): SpriteDef {
  const hit = cache.get("e:" + kind);
  if (hit) return hit;
  let s: SpriteDef;
  switch (kind) {
    case "listener": s = sprite([0, 1, 2, 3].map(listenerFrame), 0.36, 0.93); break;
    case "crawler": s = sprite([0, 1, 2].map(crawlerFrame), 0.84, 0.42); break;
    case "warden": s = sprite([0, 1, 2].map(wardenFrame), 0.5, 0.94); break;
    case "mannequin": s = sprite([0, 1, 2].map(mannequinFrame), 0.36, 0.9); break;
    case "watcher": s = sprite([0, 1].map(watcherFrame), 0.4, 0.94, { glow: 1, shadow: false }); break;
    case "drowned": s = sprite([0, 1].map(drownedFrame), 0.6, 0.6, { elev: -0.04, shadow: false }); break;
    default: s = sprite([0, 1, 2].map(houndFrame), 0.86, 0.5); break;
  }
  cache.set("e:" + kind, s);
  return s;
}
