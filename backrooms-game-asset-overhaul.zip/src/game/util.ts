export const TAU = Math.PI * 2;
export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smooth = (t: number) => t * t * (3 - 2 * t);
export const pad2 = (n: number) => String(Math.floor(n)).padStart(2, "0");

export function angleDiff(a: number, b: number) {
  let d = (a - b) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

export function mulberry32(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let x = t;
    x = Math.imul(x ^ (x >>> 15), x | 1);
    x ^= x + Math.imul(x ^ (x >>> 7), x | 61);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

export class Rng {
  private f: () => number;
  constructor(seed: number) {
    this.f = mulberry32(seed);
  }
  next() {
    return this.f();
  }
  range(a: number, b: number) {
    return a + this.f() * (b - a);
  }
  /** integer in [a, b] inclusive */
  int(a: number, b: number) {
    return a + Math.floor(this.f() * (b - a + 1));
  }
  pick<T>(arr: T[]): T {
    return arr[Math.floor(this.f() * arr.length)];
  }
  chance(p: number) {
    return this.f() < p;
  }
  shuffle<T>(arr: T[]): T[] {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(this.f() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
}

export function hash2(x: number, y: number, s: number) {
  let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(s | 0, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

/** Value noise; px / py are optional integer periods so textures tile on that axis. */
export function vnoise(x: number, y: number, seed: number, px = 0, py = 0) {
  const ix = Math.floor(x), iy = Math.floor(y);
  const fx = x - ix, fy = y - iy;
  let x0 = ix, x1 = ix + 1, y0 = iy, y1 = iy + 1;
  if (px) {
    x0 = ((x0 % px) + px) % px;
    x1 = ((x1 % px) + px) % px;
  }
  if (py) {
    y0 = ((y0 % py) + py) % py;
    y1 = ((y1 % py) + py) % py;
  }
  const a = hash2(x0, y0, seed), b = hash2(x1, y0, seed);
  const c = hash2(x0, y1, seed), d = hash2(x1, y1, seed);
  const u = smooth(fx), v = smooth(fy);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}

export function fbm(x: number, y: number, oct: number, seed: number, px = 0, py = 0) {
  let amp = 0.5, freq = 1, sum = 0, norm = 0;
  for (let o = 0; o < oct; o++) {
    sum += amp * vnoise(x * freq, y * freq, seed + o * 17, px * freq, py * freq);
    norm += amp;
    amp *= 0.5;
    freq *= 2;
  }
  return sum / norm;
}

/* canvas factory so the engine can also run headless in tests */
let factory: (w: number, h: number) => HTMLCanvasElement = (w, h) => {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return c;
};
export const setCanvasFactory = (f: (w: number, h: number) => HTMLCanvasElement) => {
  factory = f;
};
export const makeCanvas = (w: number, h: number) => factory(w, h);

/* packed 0xRRGGBB helpers */
export const c8 = (n: number) => (n < 0 ? 0 : n > 255 ? 255 : n | 0);
export const pack = (r: number, g: number, b: number) => (c8(r) << 16) | (c8(g) << 8) | c8(b);
export const mixc = (a: number, b: number, t: number) =>
  pack(
    (a >> 16 & 255) + ((b >> 16 & 255) - (a >> 16 & 255)) * t,
    (a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * t,
    (a & 255) + ((b & 255) - (a & 255)) * t,
  );
export const shade = (c: number, k: number) => pack((c >> 16 & 255) * k, (c >> 8 & 255) * k, (c & 255) * k);
export const css = (c: number, a = 1) => `rgba(${c >> 16 & 255},${c >> 8 & 255},${c & 255},${a})`;
