import { Rng, angleDiff, clamp, hash2 } from "./util";
import { DIFFICULTIES, LEVELS, DEATH_LINES, type LevelDef } from "./levels";
import { generateLevel } from "./mapgen";
import { buildTheme, type ThemeTex } from "./textures";
import { Lighting } from "./lighting";
import { Renderer, type SpriteInst, type View } from "./render";
import { AudioEngine } from "./audio";
import { castGrid, los, bfs, moveCircle } from "./world";
import { pickupSprite } from "./sprites";
import { entitySprites, makeEnt, updateEntities, type Ent, type World } from "./entities";
import type { Decal, Difficulty, Level, Pickup } from "./types";
import { loadRecords, loadSettings, saveRecords, saveSettings, type Records, type Settings } from "./store";

export type Phase = "menu" | "loading" | "playing" | "paused" | "note" | "keypad" | "dead" | "complete";

export interface TaskLine {
  text: string;
  progress?: string;
  state: "done" | "active" | "todo";
  hint?: string;
}

export interface Hud {
  coh: number;
  stamina: number;
  battery: number;
  torchOn: boolean;
  water: number;
  cells: number;
  fuses: number;
  keys: number;
  prompt: string | null;
  promptKey: string;
  hold: number;
  message: string;
  msgId: number;
  tasks: TaskLine[];
  code: string;
  levelName: string;
  levelSub: string;
  time: number;
  danger: number;
  hurt: number;
  dark: number;
  fps: number;
  noise: number;
}

export interface GameEvents {
  onPhase(p: Phase): void;
  onNote(title: string, text: string): void;
  onDead(line: string): void;
  onComplete(info: { time: number; level: number; last: boolean }): void;
}

type Target =
  | { kind: "pickup"; pk: Pickup }
  | { kind: "decal"; d: Decal };

const PLAYER_R = 0.2;

export class Game {
  readonly canvas: HTMLCanvasElement;
  renderer: Renderer;
  audio = new AudioEngine();
  settings: Settings = loadSettings();
  records: Records = loadRecords();
  phase: Phase = "menu";

  def!: LevelDef;
  level!: Level;
  light!: Lighting;
  theme!: ThemeTex;
  diff: Difficulty = DIFFICULTIES[1];
  levelIdx = 0;
  diffIdx = 1;
  rng = new Rng(1);
  ents: Ent[] = [];

  // player
  p = { x: 1.5, y: 1.5, a: 0, pitch: 0, bobT: 0, stamina: 100, coh: 100, torchOn: false, battery: 100, water: 0, cells: 0, fuses: 0, keys: 0, inWater: false, slowT: 0, hurtT: 0, hurtCd: 0, moving: false, stepDist: 0, speedNow: 0 };
  time = 0;
  runTime = 0;
  private attract = true;
  private lampScale = 1;
  private ambScale = 1;
  private torchI = 0;
  private blackout = false;
  private blackoutT = 0;
  private nextBlackout = 90;
  private blackoutWarn = 0;
  private nextKill = 50;
  private lampTick = 0;
  private shake = 0;

  // noise
  private noiseR = 0.8;
  private loud: { x: number; y: number; r: number; until: number } | null = null;
  private pf: Int16Array = new Int16Array(1);
  private pfCell = -1;

  // tasks
  private fusesFound = 0;
  private fusesIn = 0;
  private valves = 0;
  private keypadOk = false;
  private genRunning = false;
  private powered = false;
  private exitOpen = false;
  private digits: (string | null)[] = [null, null, null];
  private seenDecals = new Set<Decal>();
  private target: Target | null = null;
  private holdT = 0;
  private holdTarget: Decal | null = null;
  private grT = 0;
  private exploreT = 0;
  private msgT = 0;
  private fovRad = 1.3;

  hud: Hud = {
    coh: 100, stamina: 100, battery: 100, torchOn: false, water: 0, cells: 0, fuses: 0, keys: 0, prompt: null, promptKey: "E", hold: 0,
    message: "", msgId: 0, tasks: [], code: "", levelName: "", levelSub: "", time: 0, danger: 0, hurt: 0, dark: 0, fps: 60, noise: 0,
  };

  // input
  private keys = new Set<string>();
  private useEdge = false;
  private useHeld = false;
  private mouseDown = false;
  touch = { mx: 0, my: 0 };
  mapOpen = false;

  private raf = 0;
  private last = 0;
  private fpsAcc = 0;
  private fpsN = 0;
  private world: World;
  private hadLock = false;

  constructor(canvas: HTMLCanvasElement, private events: GameEvents) {
    this.canvas = canvas;
    canvas.width = 480;
    canvas.height = 270;
    const ctx = canvas.getContext("2d", { alpha: false }) as CanvasRenderingContext2D;
    this.renderer = new Renderer(ctx);
    this.audio.volume = this.settings.volume;
    const g = this;
    this.world = {
      get level() { return g.level; },
      get light() { return g.light; },
      get def() { return g.def; },
      get diff() { return g.diff; },
      get rng() { return g.rng; },
      get audio() { return g.audio; },
      get time() { return g.time; },
      get blackout() { return g.blackout; },
      get p() { return g.p; },
      get pf() { return g.pf; },
      get noiseR() { return g.noiseR; },
      get loud() { return g.loud; },
      hurt: (d, f) => this.hurt(d, f),
      drain: (a) => { this.p.coh = Math.max(0, this.p.coh - a); },
      seenBy: (x, y) => this.seenBy(x, y),
      inTorch: (x, y, r) => this.inTorch(x, y, r),
      lightAt: (x, y) => this.lightAt(x, y),
      flickerNear: (x, y, r) => this.flickerNear(x, y, r),
      slow: (t) => { this.p.slowT = Math.max(this.p.slowT, t); },
      note: (t) => this.msg(t, 3.2),
      onRetreat: () => { this.records.encounters++; },
    };
    this.bind();
    this.raf = requestAnimationFrame(this.loop);
  }

  /* ------------------------------------------------------------------ lifecycle */
  dispose() {
    cancelAnimationFrame(this.raf);
    this.unbind();
  }

  private loadLevel(idx: number, diffIdx: number, seed: number) {
    this.levelIdx = idx;
    this.diffIdx = diffIdx;
    this.def = LEVELS[idx];
    this.diff = DIFFICULTIES[diffIdx];
    this.rng = new Rng(seed ^ 0x9e3779b9);
    this.theme = buildTheme(this.def.theme);
    this.level = generateLevel(this.def, this.diff, seed);
    this.light = new Lighting(this.level, this.def);
    this.light.bake();
    this.renderer.setLevel(this.level, this.light, this.def, this.theme);
    this.audio.setTheme(this.def.theme);
    const P = this.p;
    P.x = this.level.start.x; P.y = this.level.start.y;
    let best = 0, ba = 0;
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      const h = castGrid(this.level, P.x, P.y, Math.cos(a), Math.sin(a), 30);
      const d = h ? h.dist : 30;
      if (d > best) { best = d; ba = a; }
    }
    P.a = ba; P.pitch = 0;
    this.pf = bfs(this.level, P.x, P.y);
    this.pfCell = -1;
    this.time = 0;
    this.lampScale = 1; this.ambScale = 1; this.blackout = false; this.blackoutT = 0; this.blackoutWarn = 0;
    this.nextBlackout = 70 + this.rng.range(0, 40);
    this.nextKill = 40;
    this.loud = null;
    this.noiseR = 0.8;
    this.seenDecals.clear();
    this.target = null;
  }

  /** menu background: a slow look around the first room */
  startAttract(levelIdx: number) {
    this.attract = true;
    this.loadLevel(levelIdx, 1, (Date.now() & 0xffffff) + 7);
    this.ents = [];
    this.setPhase("menu");
  }

  start(levelIdx: number, diffIdx: number) {
    this.audio.init();
    this.attract = false;
    this.loadLevel(levelIdx, diffIdx, (Math.random() * 1e9) | 0);
    const P = this.p;
    P.coh = 100; P.stamina = 100; P.battery = 100; P.torchOn = false; P.water = 1; P.cells = 0; P.fuses = 0; P.keys = 0;
    P.slowT = 0; P.hurtT = 0; P.hurtCd = 0; P.bobT = 0;
    this.fusesFound = 0; this.fusesIn = 0; this.valves = 0; this.keypadOk = false; this.genRunning = false; this.powered = false; this.exitOpen = false;
    this.digits = [null, null, null];
    this.holdT = 0; this.holdTarget = null; this.runTime = 0; this.mapOpen = false;
    this.spawnEntities();
    this.records.runs++;
    saveRecords(this.records);
    this.hud.levelName = this.def.name;
    this.hud.levelSub = this.def.sub;
    this.refreshDecals();
    this.msg(this.def.tagline, 4.5);
    this.setPhase("playing");
  }

  private spawnEntities() {
    const d = this.def.entities;
    const ex = this.diff.extra;
    const list: Ent[] = [];
    const L = this.level;
    const cellPos = (c: number) => ({ x: (c % L.n) + 0.5, y: ((c / L.n) | 0) + 0.5 });
    const farCells = L.spawnCells.length ? L.spawnCells : L.rooms[0].cells;
    const pickFar = () => cellPos(this.rng.pick(farCells));
    if (d.listener) list.push(makeEnt("listener", 0, 0));
    const add = (kind: "crawler" | "warden" | "hound" | "mannequin", n: number) => {
      const cnt = n > 0 ? n + (kind === "warden" ? 0 : ex) : 0;
      for (let i = 0; i < cnt; i++) { const p = pickFar(); list.push(makeEnt(kind, p.x, p.y)); }
    };
    add("crawler", d.crawler);
    add("warden", d.warden);
    add("hound", d.hound);
    add("mannequin", d.mannequin);
    if (d.drowned) {
      const water: number[] = [];
      for (let i = 0; i < L.n * L.n; i++) if (L.floor[i] === 1 && L.map[i] === 0) water.push(i);
      for (let i = 0; i < d.drowned + ex && water.length; i++) { const p = cellPos(this.rng.pick(water)); list.push(makeEnt("drowned", p.x, p.y)); }
    }
    if (d.watcher) list.push(makeEnt("watcher", 0, 0));
    this.ents = list;
  }

  setPhase(p: Phase) {
    this.phase = p;
    this.events.onPhase(p);
    if (p === "paused" || p === "note" || p === "keypad") this.useHeld = false;
  }

  pause() {
    if (this.phase === "playing") {
      this.setPhase("paused");
      this.audio.suspend(true);
      if (document.pointerLockElement) document.exitPointerLock();
    }
  }

  resume() {
    if (this.phase === "paused" || this.phase === "note" || this.phase === "keypad") {
      this.audio.suspend(false);
      this.setPhase("playing");
      this.requestLock();
    }
  }

  requestLock() {
    try {
      const r = this.canvas.requestPointerLock?.() as unknown as Promise<void> | undefined;
      if (r && typeof r.catch === "function") r.catch(() => undefined);
    } catch { /* pointer lock unavailable, drag to look instead */ }
  }

  applySettings(s: Settings) {
    this.settings = s;
    this.audio.setVolume(s.volume);
    saveSettings(s);
  }

  /* ------------------------------------------------------------------ main loop */
  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, (now - (this.last || now)) / 1000);
    this.last = now;
    this.fpsAcc += dt; this.fpsN++;
    if (this.fpsAcc > 0.5) { this.hud.fps = Math.round(this.fpsN / this.fpsAcc); this.fpsAcc = 0; this.fpsN = 0; }
    if (!this.level) return;
    if (this.phase === "playing") this.update(dt);
    else if (this.phase === "menu") this.updateAttract(dt);
    if (this.phase !== "loading") this.draw();
  };

  private updateAttract(dt: number) {
    this.time += dt;
    this.p.a += dt * 0.07;
    this.updateLamps(dt);
    this.p.coh = 100;
  }

  private update(dt: number) {
    const P = this.p;
    this.time += dt;
    this.runTime += dt;
    this.fovRad = (this.settings.fov * Math.PI) / 180;
    this.updateMovement(dt);
    // keep a distance field to the player for every chaser
    const cell = Math.floor(P.y) * this.level.n + Math.floor(P.x);
    this.grT -= dt;
    if (cell !== this.pfCell || this.grT <= 0) { this.pf = bfs(this.level, P.x, P.y); this.pfCell = cell; this.grT = 0.5; }

    this.updateTorch(dt);
    this.updateCoherence(dt);
    this.updateLamps(dt);
    this.updateEvents(dt);
    updateEntities(this.world, this.ents, dt);
    this.updateExplore(dt);
    this.updateInteraction(dt);

    P.hurtT = Math.max(0, P.hurtT - dt);
    P.hurtCd = Math.max(0, P.hurtCd - dt);
    P.slowT = Math.max(0, P.slowT - dt);
    this.shake = Math.max(0, this.shake - dt * 2.2);
    if (this.msgT > 0) { this.msgT -= dt; if (this.msgT <= 0) this.hud.message = ""; }
    if (this.loud && this.loud.until < this.time) this.loud = null;

    this.audio.setListener(P.x, P.y, P.a);
    this.audio.update(dt, { lampNear: Math.min(1, this.light.sample(P.x, P.y)), coherence: P.coh, moving: P.moving });
    this.updateHud();
    if (P.coh <= 0) this.die("coherence");
  }

  /* ------------------------------------------------------------------ player */
  private key(code: string) { return this.keys.has(code); }

  private updateMovement(dt: number) {
    const P = this.p;
    const fwd = (this.key("KeyW") || this.key("ArrowUp") ? 1 : 0) - (this.key("KeyS") || this.key("ArrowDown") ? 1 : 0) - this.touch.my;
    const str = (this.key("KeyD") ? 1 : 0) - (this.key("KeyA") ? 1 : 0) + this.touch.mx;
    if (this.key("ArrowLeft")) P.a -= dt * 2.2;
    if (this.key("ArrowRight")) P.a += dt * 2.2;
    const wantMove = Math.abs(fwd) + Math.abs(str) > 0.05;
    const creep = this.key("ControlLeft") || this.key("KeyC");
    const sprint = (this.key("ShiftLeft") || this.key("ShiftRight")) && P.stamina > 2 && fwd > 0.1 && !creep;
    const lv = this.level;
    const cellI = Math.floor(P.y) * lv.n + Math.floor(P.x);
    P.inWater = lv.floor[cellI] === 1 && this.def.altSurface === "water";
    let speed = 2.1 * (sprint ? 1.75 : 1) * (creep ? 0.48 : 1) * (P.slowT > 0 ? 0.5 : 1) * (P.inWater ? 0.82 : 1);
    if (!wantMove) speed = 0;
    if (wantMove) {
      const mag = Math.hypot(fwd, str) || 1;
      const dx = (Math.cos(P.a) * fwd - Math.sin(P.a) * str) / mag, dy = (Math.sin(P.a) * fwd + Math.cos(P.a) * str) / mag;
      const [nx, ny] = moveCircle(lv, P.x, P.y, dx * speed * dt, dy * speed * dt, PLAYER_R);
      P.speedNow = Math.hypot(nx - P.x, ny - P.y) / dt;
      P.x = nx; P.y = ny;
    } else P.speedNow = 0;
    P.moving = P.speedNow > 0.2;
    if (sprint && P.moving) P.stamina = Math.max(0, P.stamina - 22 * dt);
    else P.stamina = Math.min(100, P.stamina + (P.stamina < 15 ? 8 : 14) * dt);
    if (P.stamina <= 0) this.keys.delete("ShiftLeft");

    // footsteps and the noise they make
    if (P.moving) {
      P.bobT += dt * P.speedNow * 4.2;
      P.stepDist += P.speedNow * dt;
      const stride = sprint ? 1.25 : 1;
      if (P.stepDist >= stride) {
        P.stepDist = 0;
        const k = lv.floor[cellI];
        const surface = k ? this.def.altSurface : this.def.surface;
        this.audio.step(surface, sprint ? 1.5 : creep ? 0.35 : P.inWater ? 1.3 : 1);
      }
    }
    let target = P.moving ? (sprint ? 13 : creep ? 2.2 : 6.5) : 0.8;
    if (P.inWater && P.moving) target *= 1.35;
    if (this.holdTarget) target = Math.max(target, 9);
    this.noiseR += (target - this.noiseR) * Math.min(1, dt * (target > this.noiseR ? 6 : 1.4));
  }

  private updateTorch(dt: number) {
    const P = this.p;
    if (P.torchOn) {
      P.battery -= 0.95 * dt;
      if (P.battery <= 0) {
        if (P.cells > 0) { P.cells--; P.battery = 100; this.msg("Fresh cell in the torch."); this.audio.pickup("cell"); }
        else { P.battery = 0; P.torchOn = false; this.audio.torch(false); this.msg("The torch is dead."); }
      }
    }
    const flick = P.battery < 15 && P.torchOn ? 0.7 + 0.3 * Math.sin(this.time * 41) * Math.sin(this.time * 13) : 1;
    const want = P.torchOn ? 1.35 * flick : 0;
    this.torchI += (want - this.torchI) * Math.min(1, dt * 14);
  }

  private updateCoherence(dt: number) {
    const P = this.p;
    const lit = this.def.ambient * this.ambScale + this.light.sample(P.x, P.y) * this.lampScale;
    let rate: number;
    if (lit < 0.12) rate = -0.6 * this.diff.drain * (P.torchOn ? 0.45 : 1);
    else if (lit < 0.28) rate = -0.08 * this.diff.drain;
    else rate = 0.7;
    if (this.blackout) rate = Math.min(rate, -0.9 * this.diff.drain * (P.torchOn ? 0.45 : 1));
    const near = this.ents.some((e) => e.alpha > 0.3 && Math.hypot(e.x - P.x, e.y - P.y) < 6 && e.kind !== "mannequin");
    if (rate > 0 && near) rate = 0;
    P.coh = clamp(P.coh + rate * dt, 0, 100);
  }

  hurt(dmg: number, from: string) {
    const P = this.p;
    if (P.hurtCd > 0 || this.phase !== "playing") return;
    const scale = 0.85 + this.diffIdx * 0.2;
    P.coh = Math.max(0, P.coh - dmg * scale);
    P.hurtCd = 1.1;
    P.hurtT = 1;
    this.shake = 1;
    this.audio.hurt();
    this.records.encounters++;
    if (P.coh <= 0) this.die(from);
  }

  private die(_from: string) {
    if (this.phase !== "playing") return;
    this.records.deaths++;
    saveRecords(this.records);
    this.audio.duck(0);
    if (document.pointerLockElement) document.exitPointerLock();
    this.setPhase("dead");
    this.events.onDead(DEATH_LINES[Math.floor(Math.random() * DEATH_LINES.length)]);
  }

  /* ------------------------------------------------------------------ light + events */
  private lightAt(x: number, y: number) {
    return this.def.ambient * this.ambScale + this.light.sample(x, y) * this.lampScale;
  }

  private flickerNear(x: number, y: number, r: number) {
    for (const l of this.light.lamps) {
      if (l.mode === "dead") continue;
      if (Math.hypot(l.cx + 0.5 - x, l.cy + 0.5 - y) < r && !l.broken) { l.broken = true; l.flickT = 0.35 + Math.random() * 0.5; }
    }
    this.audio.flicker(x, y);
  }

  private updateLamps(dt: number) {
    this.lampTick += dt;
    if (this.lampTick < 0.05) return;
    const step = this.lampTick;
    this.lampTick = 0;
    const slot = Math.floor(this.time * 20);
    const lamps = this.light.lamps;
    for (let i = 0; i < lamps.length; i++) {
      const l = lamps[i];
      if (l.mode === "dead") continue;
      if (l.mode !== "flicker" && !l.broken) continue;
      l.flickT -= step;
      if (l.flickT <= 0) {
        if (l.broken) { l.broken = false; l.flickT = l.mode === "flicker" ? 1.5 + Math.random() * 5 : 0; }
        else { l.broken = true; l.flickT = 0.3 + Math.random() * 0.4; }
      }
      const v = l.broken ? (hash2(slot, i, 5) > 0.5 ? 1 : 0.08) : 1;
      this.light.setLamp(l, v);
    }
    const ts = this.blackout ? 0.02 : 1;
    this.lampScale += (ts - this.lampScale) * Math.min(1, step * 10);
    this.ambScale += ((this.blackout ? 0.25 : 1) - this.ambScale) * Math.min(1, step * 6);
  }

  private updateEvents(dt: number) {
    const P = this.p;
    if (this.runTime < this.diff.grace * 0.7) return;
    if (this.blackout) {
      this.blackoutT -= dt;
      if (this.blackoutT <= 0) {
        this.blackout = false;
        this.audio.blackout(false);
        this.nextBlackout = (80 + this.rng.range(0, 70)) / (1 + this.levelIdx * 0.12);
      }
    } else if (this.blackoutWarn > 0) {
      this.blackoutWarn -= dt;
      if (this.blackoutWarn <= 0) {
        this.blackout = true;
        this.blackoutT = 3.5 + this.rng.range(0, 3.5) * (0.8 + this.diffIdx * 0.3);
        this.audio.blackout(true);
      }
    } else {
      this.nextBlackout -= dt;
      if (this.nextBlackout <= 0) { this.blackoutWarn = 1.4; this.flickerNear(P.x, P.y, 13); }
    }
    // lamps wear out as the shift goes on
    this.nextKill -= dt;
    if (this.nextKill <= 0) {
      this.nextKill = 35 + this.rng.range(0, 35);
      const cand = this.light.lamps.filter((l) => l.mode === "on" && Math.hypot(l.cx - P.x, l.cy - P.y) > 4 && Math.hypot(l.cx - P.x, l.cy - P.y) < 13);
      if (cand.length) {
        const l = this.rng.pick(cand);
        l.mode = "dead";
        l.broken = false;
        this.light.setLamp(l, 0);
        this.audio.flicker(l.cx + 0.5, l.cy + 0.5);
      }
    }
  }

  private restoreLamps() {
    for (const l of this.light.lamps) {
      if (l.mode === "dead") { l.mode = "on"; l.broken = true; l.flickT = 0.4 + Math.random() * 1.2; }
    }
  }

  /* ------------------------------------------------------------------ perception helpers */
  private seenBy(x: number, y: number) {
    const P = this.p;
    const dx = x - P.x, dy = y - P.y;
    if (Math.abs(angleDiff(Math.atan2(dy, dx), P.a)) > this.fovRad / 2 + 0.1) return false;
    return los(this.level, P.x, P.y, x, y);
  }

  private inTorch(x: number, y: number, range: number) {
    const P = this.p;
    if (!P.torchOn || P.battery <= 0) return false;
    const dx = x - P.x, dy = y - P.y;
    if (Math.hypot(dx, dy) > range) return false;
    if (Math.abs(angleDiff(Math.atan2(dy, dx), P.a)) > 0.45) return false;
    return los(this.level, P.x, P.y, x, y);
  }

  private updateExplore(dt: number) {
    this.exploreT -= dt;
    if (this.exploreT > 0) return;
    this.exploreT = 0.25;
    const P = this.p, L = this.level;
    const px = Math.floor(P.x), py = Math.floor(P.y);
    for (let y = py - 5; y <= py + 5; y++) for (let x = px - 5; x <= px + 5; x++) {
      if (x < 0 || y < 0 || x >= L.n || y >= L.n) continue;
      const i = y * L.n + x;
      if (L.explored[i]) continue;
      if (L.map[i] === 0) { if (los(L, P.x, P.y, x + 0.5, y + 0.5)) L.explored[i] = 1; }
      else if (Math.abs(x - px) < 3 && Math.abs(y - py) < 3) L.explored[i] = 1;
    }
    // walls bordering explored floor count as explored too
    const ri = L.roomOf[py * L.n + px];
    if (ri >= 0) L.rooms[ri].visited = true;
    // spot task furniture and loose items
    for (const d of this.taskDecals()) {
      if (this.seenDecals.has(d)) continue;
      const [ox, oy] = this.openSide(d);
      if (Math.hypot(ox - P.x, oy - P.y) < 9 && this.seenBy(ox, oy)) this.seenDecals.add(d);
    }
    for (const pk of L.pickups) {
      if (pk.taken || pk.seen || (pk.kind !== "fuse" && pk.kind !== "key")) continue;
      if (Math.hypot(pk.x - P.x, pk.y - P.y) < 9 && this.seenBy(pk.x, pk.y)) pk.seen = true;
    }
  }

  private taskDecals() {
    return [...this.level.devices, this.level.exit];
  }

  private openSide(d: Decal): [number, number] {
    const n = this.level.n;
    const cx = d.cell % n, cy = (d.cell / n) | 0;
    const o = d.face === 0 ? [cx - 1, cy] : d.face === 1 ? [cx + 1, cy] : d.face === 2 ? [cx, cy - 1] : [cx, cy + 1];
    return [o[0] + 0.5, o[1] + 0.5];
  }

  /* ------------------------------------------------------------------ interaction + tasks */
  private findTarget(): Target | null {
    const P = this.p, L = this.level;
    let best: Pickup | null = null, bd = 9;
    for (const pk of L.pickups) {
      if (pk.taken) continue;
      const dx = pk.x - P.x, dy = pk.y - P.y;
      const d = Math.hypot(dx, dy);
      if (d > 1.3) continue;
      if (d > 0.55 && Math.abs(angleDiff(Math.atan2(dy, dx), P.a)) > 0.75) continue;
      if (d < bd) { bd = d; best = pk; }
    }
    if (best) return { kind: "pickup", pk: best };
    const ch = this.renderer.centerHit;
    if (ch.cell >= 0 && ch.dist < 1.7) {
      const list = L.decals[ch.cell * 4 + ch.face];
      if (list) {
        for (const d of list) {
          if (d.kind === "deco" || d.kind === "sign") continue;
          if (ch.wallX >= d.u0 - 0.06 && ch.wallX <= d.u1 + 0.06 && ch.z >= d.z0 - 0.14 && ch.z <= d.z1 + 0.14) return { kind: "decal", d };
        }
      }
    }
    return null;
  }

  private exitUnlocked() {
    const k = this.def.task.kind;
    if (k === "power") return this.powered;
    if (k === "code") return this.keypadOk;
    if (k === "valves") return this.valves >= this.def.task.count;
    if (k === "generator") return this.genRunning;
    return this.exitOpen;
  }

  private setDecalState(d: Decal, on: boolean) {
    if (d.alt && !!d.used !== on) { const t = d.tex; d.tex = d.alt; d.alt = t; }
    d.used = on;
  }

  private refreshDecals() {
    this.setDecalState(this.level.exit, this.exitUnlocked());
  }

  private updateInteraction(dt: number) {
    const P = this.p;
    this.target = this.findTarget();
    const t = this.target;
    let prompt: string | null = null;
    let holdNeed = 0;
    let holdDecal: Decal | null = null;
    const need = this.def.task.count;
    if (t) {
      if (t.kind === "pickup") {
        prompt = { water: "Take almond water", cell: "Take torch cell", fuse: "Take fuse", key: "Take key" }[t.pk.kind];
      } else {
        const d = t.d;
        switch (d.kind) {
          case "note": prompt = "Read"; break;
          case "fusebox":
            prompt = P.fuses > 0 ? `Fit ${P.fuses} fuse${P.fuses > 1 ? "s" : ""}` : this.powered ? null : `Breaker panel (${this.fusesIn}/${need} fuses)`;
            break;
          case "generator":
            if (this.genRunning) prompt = null;
            else if (this.fusesIn < need) prompt = P.fuses > 0 ? `Fit ${P.fuses} fuse${P.fuses > 1 ? "s" : ""}` : `Generator (${this.fusesIn}/${need} fuses)`;
            else { prompt = "Hold to start the generator"; holdNeed = 3.8; holdDecal = d; }
            break;
          case "keypad": prompt = this.keypadOk ? null : "Use keypad"; break;
          case "valve": if (!d.used) { prompt = "Hold to turn the valve"; holdNeed = 2.6; holdDecal = d; } break;
          case "exit": prompt = this.exitUnlocked() || (this.def.task.kind === "keys" && P.keys >= need) ? `Leave through the ${this.def.task.exitLabel.toLowerCase()}` : "Locked"; break;
        }
      }
    }
    // hold interactions
    if (holdDecal && this.useHeld) {
      if (this.holdTarget !== holdDecal) { this.holdTarget = holdDecal; this.holdT = 0; if (holdDecal.kind === "generator") this.audio.engineSputter(); }
      this.holdT += dt;
      this.grT = Math.min(this.grT, 0.3);
      this.groanT -= dt;
      if (this.groanT <= 0) {
        this.groanT = holdDecal.kind === "valve" ? 0.75 : 0.9;
        this.audio.groan(holdDecal.kind === "valve" ? 1 : 1.3);
        this.loud = { x: P.x, y: P.y, r: holdDecal.kind === "valve" ? 15 : 22, until: this.time + 1.4 };
      }
      if (this.holdT >= holdNeed) this.finishHold(holdDecal);
    } else {
      this.holdT = Math.max(0, this.holdT - dt * 2);
      if (this.holdT === 0) this.holdTarget = null;
    }
    this.hud.hold = holdNeed > 0 ? clamp(this.holdT / holdNeed, 0, 1) : 0;
    this.hud.prompt = prompt;

    if (this.useEdge) {
      this.useEdge = false;
      if (t) this.activate(t);
    }
  }

  private groanT = 0;

  private finishHold(d: Decal) {
    this.holdT = 0;
    this.holdTarget = null;
    this.useHeld = false;
    if (d.kind === "valve") {
      this.setDecalState(d, true);
      this.valves++;
      this.audio.clunk(true);
      this.msg(`Valve ${this.valves} of ${this.def.task.count} open.`);
      this.loud = { x: this.p.x, y: this.p.y, r: 20, until: this.time + 2 };
      if (this.valves >= this.def.task.count) this.msg("The pipes go quiet. The surface hatch is clear.", 5);
    } else if (d.kind === "generator") {
      this.setDecalState(d, true);
      this.genRunning = true;
      this.audio.startGenerator();
      this.restoreLamps();
      this.loud = { x: d.cell % this.level.n + 0.5, y: ((d.cell / this.level.n) | 0) + 0.5, r: 70, until: this.time + 30 };
      this.msg("The generator catches. Everything on this level heard that. Get to the lift.", 6);
    }
    this.refreshDecals();
  }

  private activate(t: Target) {
    const P = this.p;
    const need = this.def.task.count;
    if (t.kind === "pickup") {
      const pk = t.pk;
      pk.taken = true;
      this.audio.pickup(pk.kind);
      switch (pk.kind) {
        case "water": P.water++; this.msg("Almond water. Press 1 to drink."); break;
        case "cell": P.cells++; this.msg("Torch cell."); break;
        case "fuse": P.fuses++; this.fusesFound++; this.msg(`Fuse (${this.fusesFound} of ${need}).`); break;
        case "key": P.keys++; this.msg(`Brass key (${P.keys} of ${need}).`); break;
      }
      return;
    }
    const d = t.d;
    switch (d.kind) {
      case "note": {
        this.audio.pickup("note");
        if (d.noteId !== undefined && d.noteId >= 0 && !this.records.notes.includes(d.noteId)) { this.records.notes.push(d.noteId); saveRecords(this.records); }
        if (d.noteId === -2) {
          const m = /sheet (\d)/.exec(d.title || ""), n = /digit \d: (\d)/.exec(d.text || "");
          if (m && n) this.digits[Number(m[1]) - 1] = n[1];
        }
        this.setPhase("note");
        this.events.onNote(d.title || "Note", d.text || "");
        if (document.pointerLockElement) document.exitPointerLock();
        break;
      }
      case "fusebox":
      case "generator": {
        if (P.fuses > 0 && this.fusesIn < need) {
          this.fusesIn += P.fuses;
          P.fuses = 0;
          this.audio.clunk(false);
          this.msg(`${Math.min(this.fusesIn, need)} of ${need} fuses fitted.`);
        }
        if (d.kind === "fusebox" && this.fusesIn >= need && !this.powered) {
          this.powered = true;
          this.setDecalState(d, true);
          this.audio.clunk(true);
          this.audio.blackout(false);
          this.restoreLamps();
          this.msg("Power's back. The staff exit should be live.", 5);
          this.refreshDecals();
        }
        break;
      }
      case "keypad":
        if (!this.keypadOk) {
          this.setPhase("keypad");
          if (document.pointerLockElement) document.exitPointerLock();
        }
        break;
      case "exit":
        if (this.exitUnlocked()) this.complete();
        else if (this.def.task.kind === "keys" && P.keys >= need) {
          this.exitOpen = true;
          this.audio.relay();
          this.refreshDecals();
          this.msg("Both keys turn. The lock gives.", 4);
        } else {
          this.audio.keypad(false);
          this.msg(this.lockedReason(), 4);
        }
        break;
    }
  }

  private lockedReason() {
    switch (this.def.task.kind) {
      case "power": return "Dead. No power to the door. Find the fuses.";
      case "code": return "The shutter needs the code from the keypad.";
      case "valves": return "The hatch is sealed behind live steam. Open the valves.";
      case "keys": return `Double locked. You need both keys (${this.p.keys} of ${this.def.task.count}).`;
      default: return "The lift has no power. Start the generator.";
    }
  }

  submitCode(code: string): boolean {
    const ok = code === this.level.code;
    this.audio.keypad(ok);
    if (ok) {
      this.keypadOk = true;
      if (this.level.device) this.setDecalState(this.level.device, true);
      this.refreshDecals();
      this.msg("The shutter relay clicks.", 4);
      this.audio.suspend(false);
      this.setPhase("playing");
      this.requestLock();
    }
    return ok;
  }

  closeOverlay() {
    if (this.phase === "note" || this.phase === "keypad") {
      this.setPhase("playing");
      this.requestLock();
    }
  }

  private complete() {
    this.records.escapes++;
    if (!this.records.cleared.includes(this.levelIdx)) this.records.cleared.push(this.levelIdx);
    const key = String(this.levelIdx);
    if (!this.records.best[key] || this.runTime < this.records.best[key]) this.records.best[key] = Math.round(this.runTime);
    saveRecords(this.records);
    this.audio.duck(0);
    this.audio.relay();
    if (document.pointerLockElement) document.exitPointerLock();
    this.setPhase("complete");
    this.events.onComplete({ time: this.runTime, level: this.levelIdx, last: this.levelIdx >= LEVELS.length - 1 });
  }

  drink() {
    const P = this.p;
    if (this.phase !== "playing" || P.water <= 0 || P.coh >= 99) return;
    P.water--;
    P.coh = Math.min(100, P.coh + 38);
    this.audio.drink();
    this.msg("You feel a little more like a person.");
  }

  toggleTorch() {
    const P = this.p;
    if (this.phase !== "playing") return;
    if (P.battery <= 0 && P.cells <= 0) { this.msg("No charge left."); return; }
    if (P.battery <= 0) { P.cells--; P.battery = 100; }
    P.torchOn = !P.torchOn;
    this.audio.torch(P.torchOn);
  }

  private msg(text: string, secs = 3) {
    this.hud.message = text;
    this.hud.msgId++;
    this.msgT = secs;
  }

  /* ------------------------------------------------------------------ tasks display */
  private buildTasks(): TaskLine[] {
    const T = this.def.task, need = T.count;
    const labels = [...new Set(T.itemRooms.map((t) => this.def.rooms.find((r) => r.type === t)?.label ?? t))].join(", ");
    const L = this.level;
    const dev = L.device ?? L.devices[0];
    const devSeen = dev ? this.seenDecals.has(dev) : false;
    const exitSeen = this.seenDecals.has(L.exit);
    const lines: Omit<TaskLine, "state">[] & { done?: boolean }[] = [];
    const push = (text: string, done: boolean, progress?: string, hint?: string) => (lines as { text: string; done: boolean; progress?: string; hint?: string }[]).push({ text, done, progress, hint });
    const exitHint = exitSeen ? "Seen. Marked on the floor plan." : "It is on the far side of the floor.";
    switch (T.kind) {
      case "power":
        push("Find the fuses", this.fusesFound >= need, `${this.fusesFound}/${need}`, `Try: ${labels}`);
        push("Fit them at the breaker panel", this.powered, `${this.fusesIn}/${need}`, devSeen ? "Panel located." : `It is in ${T.deviceLabel}.`);
        push(`Leave by the ${T.exitLabel.toLowerCase()}`, false, undefined, exitHint);
        break;
      case "code": {
        const found = this.digits.filter(Boolean).length;
        push("Find the dispatch sheets", found >= need, `${found}/${need}`, `Try: ${labels}`);
        push("Enter the code at the keypad", this.keypadOk, undefined, devSeen ? "Keypad located." : `It is in the ${T.deviceLabel}.`);
        push(`Leave by the ${T.exitLabel.toLowerCase()}`, false, undefined, exitHint);
        break;
      }
      case "valves":
        push("Open the steam valves", this.valves >= need, `${this.valves}/${need}`, `They are in: ${labels}`);
        push(`Climb out by the ${T.exitLabel.toLowerCase()}`, false, undefined, exitHint);
        break;
      case "keys":
        push("Find the two brass keys", this.p.keys >= need || this.exitOpen, `${Math.min(this.p.keys, need)}/${need}`, `Try: ${labels}`);
        push(`Unlock the ${T.exitLabel.toLowerCase()}`, this.exitOpen, undefined, exitHint);
        push("Get out", false);
        break;
      default:
        push("Find the fuses", this.fusesFound >= need, `${this.fusesFound}/${need}`, `Try: ${labels}`);
        push("Fit them in the generator panel", this.fusesIn >= need, `${this.fusesIn}/${need}`, devSeen ? "Panel located." : `It is in the ${T.deviceLabel}.`);
        push("Hold the start switch", this.genRunning, undefined, "It is loud. Plan your route first.");
        push(`Take the ${T.exitLabel.toLowerCase()}`, false, undefined, exitHint);
    }
    let activeSet = false;
    return (lines as { text: string; done: boolean; progress?: string; hint?: string }[]).map((l) => {
      let state: TaskLine["state"] = "todo";
      if (l.done) state = "done";
      else if (!activeSet) { state = "active"; activeSet = true; }
      return { text: l.text, progress: l.progress, hint: state === "active" ? l.hint : undefined, state };
    });
  }

  private updateHud() {
    const P = this.p, h = this.hud;
    h.coh = P.coh; h.stamina = P.stamina; h.battery = P.battery; h.torchOn = P.torchOn;
    h.water = P.water; h.cells = P.cells; h.fuses = P.fuses; h.keys = P.keys;
    h.time = this.runTime;
    h.hurt = P.hurtT;
    h.dark = clamp(1 - this.lightAt(P.x, P.y) * 3, 0, 1);
    h.noise = clamp(this.noiseR / 13, 0, 1);
    h.tasks = this.buildTasks();
    h.code = this.def.task.kind === "code" ? this.digits.map((d) => d ?? "_").join(" ") : "";
    let danger = 0;
    for (const e of this.ents) {
      if (e.alpha < 0.3) continue;
      if (e.kind === "mannequin" && e.state !== "awake") continue;
      if (e.kind === "watcher" || e.kind === "drowned") continue;
      danger = Math.max(danger, 1 - Math.hypot(e.x - P.x, e.y - P.y) / 11);
    }
    h.danger = clamp(danger, 0, 1);
    this.audio.duck(this.ents.some((e) => e.kind === "listener" && e.alpha > 0.5 && e.c <= 0 && e.state === "stalk" && this.seenBy(e.x, e.y) && Math.hypot(e.x - P.x, e.y - P.y) < 12) ? 0.8 : 0);
  }

  /* ------------------------------------------------------------------ drawing */
  private draw() {
    const P = this.p, L = this.level;
    const sprites: SpriteInst[] = [];
    for (const pr of L.props) {
      if (Math.abs(pr.x - P.x) > 20 || Math.abs(pr.y - P.y) > 20) continue;
      sprites.push({ x: pr.x, y: pr.y, def: pr.sprite, frame: 0, flip: pr.flip, alpha: 1, glow: 0, scale: 1, zoff: 0, flash: 0 });
    }
    for (const pk of L.pickups) {
      if (pk.taken) continue;
      if (Math.abs(pk.x - P.x) > 16 || Math.abs(pk.y - P.y) > 16) continue;
      const pulse = 0.5 + 0.5 * Math.sin(this.time * 2.2 + pk.phase);
      const quest = pk.kind === "fuse" || pk.kind === "key";
      sprites.push({ x: pk.x, y: pk.y, def: pickupSprite(pk.kind), frame: 0, flip: false, alpha: 1, glow: quest ? 0.1 + pulse * 0.14 : 0.03, scale: 1, zoff: 0.006, flash: 0 });
    }
    if (!this.attract) sprites.push(...entitySprites(this.ents, P.a));
    const bob = this.attract ? 0 : Math.sin(P.bobT) * 0.011 * this.settings.bob * (P.moving ? 1 : 0);
    const sh = this.shake * this.shake;
    const view: View = {
      x: P.x, y: P.y,
      a: P.a + (Math.random() - 0.5) * 0.03 * sh,
      pitch: clamp(P.pitch, -0.35, 0.35) + (Math.random() - 0.5) * 0.02 * sh + Math.cos(P.bobT * 0.5) * 0.002 * this.settings.bob * (P.moving ? 1 : 0),
      eye: 0.5 + bob - (P.inWater ? 0.03 : 0),
      fov: (this.settings.fov * Math.PI) / 180,
      brightness: this.settings.brightness,
      lampScale: this.lampScale,
      ambScale: this.ambScale,
      torch: this.torchI,
      time: this.time,
    };
    this.renderer.render(view, sprites);
  }

  drawMap(ctx: CanvasRenderingContext2D, size: number) {
    const L = this.level, n = L.n, s = size / n, P = this.p;
    ctx.fillStyle = "#0d0d0b";
    ctx.fillRect(0, 0, size, size);
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const i = y * n + x;
      if (L.map[i] === 0 && L.explored[i]) {
        ctx.fillStyle = L.floor[i] === 1 && this.def.altSurface === "water" ? "#2c4a52" : "#5a5646";
        ctx.fillRect(x * s, y * s, s + 0.5, s + 0.5);
      }
    }
    ctx.fillStyle = "#cfc8ae";
    for (let y = 1; y < n - 1; y++) for (let x = 1; x < n - 1; x++) {
      const i = y * n + x;
      if (L.map[i] === 0) continue;
      if ((L.explored[i - 1] || L.explored[i + 1] || L.explored[i - n] || L.explored[i + n]) && L.explored[i] ) ctx.fillRect(x * s, y * s, s + 0.5, s + 0.5);
    }
    ctx.font = "10px 'Courier New', monospace";
    ctx.textAlign = "center";
    for (const r of L.rooms) {
      if (!r.visited || !r.label) continue;
      ctx.fillStyle = "rgba(255,248,220,0.8)";
      ctx.fillText(r.label.toUpperCase(), (r.x + r.w / 2) * s, (r.y + r.h / 2) * s);
    }
    for (const d of this.taskDecals()) {
      if (!this.seenDecals.has(d)) continue;
      const [ox, oy] = this.openSide(d);
      ctx.fillStyle = d.kind === "exit" ? (this.exitUnlocked() ? "#6fe08a" : "#e0604a") : "#e8c050";
      ctx.fillRect(ox * s - 3, oy * s - 3, 7, 7);
    }
    for (const pk of L.pickups) {
      if (pk.taken || !pk.seen) continue;
      ctx.fillStyle = "#e8c050";
      ctx.beginPath(); ctx.arc(pk.x * s, pk.y * s, 3, 0, 7); ctx.fill();
    }
    ctx.save();
    ctx.translate(P.x * s, P.y * s);
    ctx.rotate(P.a);
    ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, 4); ctx.lineTo(-4, -4); ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  /* ------------------------------------------------------------------ input */
  private bind() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("mousemove", this.onMouseMove);
    window.addEventListener("mousedown", this.onMouseDown);
    window.addEventListener("mouseup", this.onMouseUp);
    document.addEventListener("pointerlockchange", this.onLock);
    window.addEventListener("blur", this.onBlur);
  }
  private unbind() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("mousemove", this.onMouseMove);
    window.removeEventListener("mousedown", this.onMouseDown);
    window.removeEventListener("mouseup", this.onMouseUp);
    document.removeEventListener("pointerlockchange", this.onLock);
    window.removeEventListener("blur", this.onBlur);
  }

  private onBlur = () => { this.keys.clear(); this.useHeld = false; this.mouseDown = false; if (this.phase === "playing") this.pause(); };

  private onLock = () => {
    const locked = document.pointerLockElement === this.canvas;
    if (locked) this.hadLock = true;
    else if (this.hadLock && this.phase === "playing") this.pause();
    if (!locked) this.hadLock = false;
  };

  private onKeyDown = (e: KeyboardEvent) => {
    if (this.phase === "keypad") return;
    if (["Space", "ArrowUp", "ArrowDown", "Tab"].includes(e.code) && this.phase === "playing") e.preventDefault();
    if (e.repeat) return;
    if (this.phase === "playing") {
      this.keys.add(e.code);
      switch (e.code) {
        case "KeyE": case "Space": this.useEdge = true; this.useHeld = true; break;
        case "KeyF": this.toggleTorch(); break;
        case "Digit1": case "KeyQ": this.drink(); break;
        case "KeyM": case "Tab": this.mapOpen = !this.mapOpen; break;
        case "KeyP": this.pause(); break;
        case "Escape": if (this.mapOpen) this.mapOpen = false; else this.pause(); break;
      }
    } else if (this.phase === "note" && (e.code === "Escape" || e.code === "KeyE" || e.code === "Space")) {
      this.closeOverlay();
    }
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
    if (e.code === "KeyE" || e.code === "Space") this.useHeld = this.mouseDown;
  };
  private onMouseMove = (e: MouseEvent) => {
    if (this.phase !== "playing") return;
    if (document.pointerLockElement !== this.canvas && !this.mouseDown) return;
    this.look(e.movementX, e.movementY);
  };
  look(dx: number, dy: number) {
    const s = this.settings.sens * 0.0024;
    this.p.a += dx * s;
    this.p.pitch = clamp(this.p.pitch - dy * s * 0.5 * (this.settings.invertY ? -1 : 1), -0.35, 0.35);
  }
  private onMouseDown = (e: MouseEvent) => {
    if (this.phase !== "playing") return;
    if (e.button === 0) {
      this.mouseDown = true; this.useEdge = true; this.useHeld = true;
      if (document.pointerLockElement !== this.canvas) this.requestLock();
    }
    if (e.button === 2) this.toggleTorch();
  };
  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) { this.mouseDown = false; this.useHeld = this.key("KeyE") || this.key("Space"); }
  };
  pressUse(down: boolean) {
    if (down) { this.useEdge = true; this.useHeld = true; } else this.useHeld = false;
  }
}

