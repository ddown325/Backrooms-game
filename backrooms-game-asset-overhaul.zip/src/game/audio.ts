import { clamp } from "./util";
import type { ThemeId } from "./types";

type Surface = "carpet" | "concrete" | "metal" | "tile" | "water";

interface NoiseOpts {
  dur: number;
  type?: BiquadFilterType;
  f?: number;
  f2?: number;
  q?: number;
  g: number;
  a?: number;
  pan?: number;
  send?: number;
  lp?: number;
}
interface ToneOpts {
  type?: OscillatorType;
  f: number;
  f2?: number;
  dur: number;
  g: number;
  a?: number;
  pan?: number;
  send?: number;
  lp?: number;
  am?: number;
}

const THEME_AUDIO: Record<ThemeId, { hum: number; humG: number; rumble: number; hiss: number; hissF: number; lap: number; verb: number; one: string[] }> = {
  yellow: { hum: 120, humG: 0.045, rumble: 0.05, hiss: 0.012, hissF: 1100, lap: 0, verb: 1.6, one: ["thud", "creak", "steps", "zap", "drip"] },
  concrete: { hum: 100, humG: 0.02, rumble: 0.11, hiss: 0.02, hissF: 500, lap: 0, verb: 3.2, one: ["thud", "clank", "creak", "steps", "wind"] },
  pipes: { hum: 48, humG: 0.03, rumble: 0.1, hiss: 0.045, hissF: 3200, lap: 0, verb: 1.1, one: ["knock", "clank", "drip", "steam", "creak"] },
  pool: { hum: 50, humG: 0.03, rumble: 0.03, hiss: 0.008, hissF: 2200, lap: 0.07, verb: 3.8, one: ["drip", "splash", "drip", "thud", "creak"] },
  plant: { hum: 100, humG: 0.07, rumble: 0.09, hiss: 0.012, hissF: 2600, lap: 0, verb: 2.4, one: ["arc", "clank", "thud", "knock", "zap"] },
};

export class AudioEngine {
  ctx: AudioContext | null = null;
  private master!: GainNode;
  private sfx!: GainNode;
  private amb!: GainNode;
  private verbIn!: GainNode;
  private conv!: ConvolverNode;
  private noiseBuf!: AudioBuffer;
  private brownBuf!: AudioBuffer;
  private humGain!: GainNode;
  private rumbleGain!: GainNode;
  private airGain!: GainNode;
  private airFilter!: BiquadFilterNode;
  private lapGain!: GainNode;
  private humOsc: OscillatorNode[] = [];
  private genGain: GainNode | null = null;
  private genNodes: OscillatorNode[] = [];
  private theme: ThemeId = "yellow";
  volume = 0.75;
  private duckT = 0;
  private duckC = 0;
  private nextOne = 6;
  private beat = 0;
  private lx = 0;
  private ly = 0;
  private la = 0;
  private started = false;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const c = new AC();
    this.ctx = c;
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 4; comp.attack.value = 0.005; comp.release.value = 0.25;
    this.master = c.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(comp);
    comp.connect(c.destination);
    this.sfx = c.createGain(); this.sfx.connect(this.master);
    this.amb = c.createGain(); this.amb.connect(this.master);
    this.verbIn = c.createGain();
    this.conv = c.createConvolver();
    this.verbIn.connect(this.conv);
    const ret = c.createGain(); ret.gain.value = 0.8;
    this.conv.connect(ret); ret.connect(this.master);
    // noise sources
    const len = c.sampleRate * 2;
    this.noiseBuf = c.createBuffer(1, len, c.sampleRate);
    const nd = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) nd[i] = Math.random() * 2 - 1;
    this.brownBuf = c.createBuffer(1, len, c.sampleRate);
    const bd = this.brownBuf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) { last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02; bd[i] = last * 3.5; }
    this.buildBeds();
    this.setTheme(this.theme);
    this.started = true;
  }

  private makeIR(sec: number) {
    const c = this.ctx!;
    const len = Math.floor(c.sampleRate * sec);
    const buf = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      let lp = 0;
      for (let i = 0; i < len; i++) {
        const t = i / len;
        const k = 0.15 + 0.85 * (1 - t); // darker as it decays
        lp += (Math.random() * 2 - 1 - lp) * k;
        d[i] = lp * Math.pow(1 - t, 2.6) * (i < 400 ? i / 400 : 1);
      }
    }
    this.conv.buffer = buf;
  }

  private buildBeds() {
    const c = this.ctx!;
    const loopSrc = (buf: AudioBuffer) => {
      const s = c.createBufferSource();
      s.buffer = buf; s.loop = true;
      s.start(0, Math.random());
      return s;
    };
    // mains hum: a stack of harmonics that beat slowly against each other
    this.humGain = c.createGain(); this.humGain.gain.value = 0;
    const humLp = c.createBiquadFilter(); humLp.type = "lowpass"; humLp.frequency.value = 700;
    humLp.connect(this.humGain); this.humGain.connect(this.amb);
    [[1, "sawtooth", 0.5], [2, "sine", 0.6], [3, "sine", 0.22], [2.003, "sine", 0.3]].forEach(([m, type, g]) => {
      const o = c.createOscillator(); o.type = type as OscillatorType; o.frequency.value = 100 * (m as number);
      const gg = c.createGain(); gg.gain.value = g as number;
      o.connect(gg); gg.connect(humLp); o.start();
      this.humOsc.push(o);
    });
    // rumble
    this.rumbleGain = c.createGain(); this.rumbleGain.gain.value = 0;
    const rl = c.createBiquadFilter(); rl.type = "lowpass"; rl.frequency.value = 130;
    loopSrc(this.brownBuf).connect(rl); rl.connect(this.rumbleGain); this.rumbleGain.connect(this.amb);
    // air handling
    this.airGain = c.createGain(); this.airGain.gain.value = 0;
    this.airFilter = c.createBiquadFilter(); this.airFilter.type = "bandpass"; this.airFilter.Q.value = 0.5;
    loopSrc(this.noiseBuf).connect(this.airFilter); this.airFilter.connect(this.airGain); this.airGain.connect(this.amb);
    const lfo = c.createOscillator(); lfo.frequency.value = 0.11;
    const lg = c.createGain(); lg.gain.value = 0.35;
    lfo.connect(lg); lg.connect(this.airGain.gain); lfo.start();
    // water lapping
    this.lapGain = c.createGain(); this.lapGain.gain.value = 0;
    const lf = c.createBiquadFilter(); lf.type = "lowpass"; lf.frequency.value = 900;
    loopSrc(this.noiseBuf).connect(lf); lf.connect(this.lapGain); this.lapGain.connect(this.amb);
    const lfo2 = c.createOscillator(); lfo2.frequency.value = 0.27;
    const lg2 = c.createGain(); lg2.gain.value = 0.03;
    lfo2.connect(lg2); lg2.connect(this.lapGain.gain); lfo2.start();
  }

  setTheme(theme: ThemeId) {
    this.theme = theme;
    if (!this.ctx) return;
    const t = THEME_AUDIO[theme];
    const now = this.ctx.currentTime;
    this.humOsc.forEach((o, i) => o.frequency.setTargetAtTime(t.hum * [1, 2, 3, 2.003][i], now, 0.2));
    this.humGain.gain.setTargetAtTime(t.humG, now, 0.5);
    this.rumbleGain.gain.setTargetAtTime(t.rumble, now, 0.5);
    this.airGain.gain.setTargetAtTime(t.hiss, now, 0.5);
    this.airFilter.frequency.setTargetAtTime(t.hissF, now, 0.5);
    this.lapGain.gain.setTargetAtTime(t.lap, now, 0.5);
    this.makeIR(t.verb);
    this.stopGenerator();
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.ctx) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.05);
  }

  setListener(x: number, y: number, a: number) {
    this.lx = x; this.ly = y; this.la = a;
  }

  /** quiets the room (used while a monster is frozen under your eyes) */
  duck(v: number) {
    this.duckT = v;
  }

  suspend(on: boolean) {
    if (!this.ctx) return;
    if (on) void this.ctx.suspend(); else void this.ctx.resume();
  }

  /* --------------------------------------------------------- building blocks */
  private route(node: AudioNode, pan: number, send: number) {
    const c = this.ctx!;
    let out: AudioNode = node;
    if (pan) {
      const p = c.createStereoPanner();
      p.pan.value = clamp(pan, -1, 1);
      node.connect(p);
      out = p;
    }
    out.connect(this.sfx);
    if (send > 0) {
      const s = c.createGain();
      s.gain.value = send;
      out.connect(s);
      s.connect(this.verbIn);
    }
  }

  private ns(t: number, o: NoiseOpts) {
    const c = this.ctx!;
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    const flt = c.createBiquadFilter();
    flt.type = o.type ?? "bandpass";
    flt.frequency.setValueAtTime(o.f ?? 1000, t);
    if (o.f2) flt.frequency.exponentialRampToValueAtTime(o.f2, t + o.dur);
    flt.Q.value = o.q ?? 1;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.g), t + (o.a ?? 0.004));
    g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    src.connect(flt);
    let tail: AudioNode = flt;
    if (o.lp) {
      const l = c.createBiquadFilter(); l.type = "lowpass"; l.frequency.value = o.lp;
      flt.connect(l); tail = l;
    }
    tail.connect(g);
    this.route(g, o.pan ?? 0, o.send ?? 0.15);
    src.start(t, Math.random() * 1.5, o.dur + 0.05);
    src.stop(t + o.dur + 0.05);
  }

  private tn(t: number, o: ToneOpts) {
    const c = this.ctx!;
    const osc = c.createOscillator();
    osc.type = o.type ?? "sine";
    osc.frequency.setValueAtTime(o.f, t);
    if (o.f2) osc.frequency.exponentialRampToValueAtTime(o.f2, t + o.dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.g), t + (o.a ?? 0.006));
    g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    let tail: AudioNode = osc;
    if (o.lp) {
      const l = c.createBiquadFilter(); l.type = "lowpass"; l.frequency.value = o.lp;
      osc.connect(l); tail = l;
    }
    if (o.am) {
      const mod = c.createOscillator(); mod.frequency.value = o.am;
      const mg = c.createGain(); mg.gain.value = o.g * 0.5;
      mod.connect(mg); mg.connect(g.gain); mod.start(t); mod.stop(t + o.dur + 0.05);
    }
    tail.connect(g);
    this.route(g, o.pan ?? 0, o.send ?? 0.15);
    osc.start(t);
    osc.stop(t + o.dur + 0.05);
  }

  private spatial(x: number, y: number) {
    const dx = x - this.lx, dy = y - this.ly;
    const d = Math.hypot(dx, dy);
    const ang = Math.atan2(dy, dx) - this.la;
    return { d, pan: Math.sin(ang) * Math.min(1, 0.35 + d * 0.15) * (Math.cos(ang) < -0.2 ? 0.6 : 1), gain: 1 / (1 + d * 0.42), lp: 9000 / (1 + d * 0.28) + 500, send: Math.min(0.7, 0.12 + d * 0.045) };
  }

  /* --------------------------------------------------------- the world */
  update(dt: number, s: { lampNear: number; coherence: number; moving: boolean }) {
    if (!this.ctx || !this.started) return;
    const c = this.ctx;
    this.duckC += (this.duckT - this.duckC) * Math.min(1, dt * 3);
    this.amb.gain.setTargetAtTime(1 - this.duckC * 0.75, c.currentTime, 0.1);
    const th = THEME_AUDIO[this.theme];
    this.humGain.gain.setTargetAtTime(th.humG * (0.35 + 0.65 * s.lampNear), c.currentTime, 0.25);
    this.nextOne -= dt;
    if (this.nextOne <= 0) {
      this.nextOne = 6 + Math.random() * 12;
      this.oneShot(th.one[Math.floor(Math.random() * th.one.length)]);
    }
    if (s.coherence < 38) {
      this.beat -= dt;
      if (this.beat <= 0) {
        this.beat = 0.5 + (s.coherence / 38) * 0.7;
        const t = c.currentTime, v = 0.28 * (1 - s.coherence / 45);
        this.tn(t, { f: 58, f2: 38, dur: 0.16, g: v, send: 0.02, lp: 140 });
        this.tn(t + 0.17, { f: 52, f2: 34, dur: 0.16, g: v * 0.7, send: 0.02, lp: 140 });
      }
    }
  }

  private oneShot(kind: string) {
    const c = this.ctx!;
    const t = c.currentTime + 0.02;
    const pan = Math.random() * 1.6 - 0.8;
    switch (kind) {
      case "thud": // a heavy door, a long way off
        this.tn(t, { f: 74, f2: 38, dur: 0.5, g: 0.24, pan, send: 0.5, lp: 180 });
        this.ns(t, { type: "lowpass", f: 300, dur: 0.35, g: 0.18, pan, send: 0.6 });
        break;
      case "creak":
        this.ns(t, { f: 320, f2: 520 + Math.random() * 300, q: 8, dur: 1.2, a: 0.4, g: 0.05, pan, send: 0.5 });
        break;
      case "drip":
        this.tn(t, { f: 1800 + Math.random() * 600, f2: 900, dur: 0.12, g: 0.05, pan, send: 0.8 });
        break;
      case "clank":
        this.ns(t, { f: 1100, q: 14, dur: 0.9, g: 0.09, pan, send: 0.6 });
        this.ns(t, { f: 2400, q: 10, dur: 0.5, g: 0.04, pan, send: 0.6 });
        break;
      case "knock":
        for (let i = 0; i < 3; i++) this.tn(t + i * 0.42, { f: 160, f2: 110, dur: 0.12, g: 0.13, pan, send: 0.4, lp: 600 });
        break;
      case "steps": // somebody else, walking slowly
        for (let i = 0; i < 5; i++) this.ns(t + i * 0.62, { type: "lowpass", f: 380, dur: 0.1, g: 0.06, pan: pan * 0.7, send: 0.5 });
        break;
      case "zap":
        this.ns(t, { type: "highpass", f: 3500, dur: 0.18, g: 0.07, pan, send: 0.2 });
        break;
      case "arc":
        for (let i = 0; i < 6; i++) this.ns(t + i * 0.025, { type: "highpass", f: 2500 + Math.random() * 2000, dur: 0.04, g: 0.1, pan, send: 0.3 });
        break;
      case "steam":
        this.ns(t, { type: "highpass", f: 2600, dur: 1.8, a: 0.5, g: 0.06, pan, send: 0.4 });
        break;
      case "splash":
        this.ns(t, { type: "bandpass", f: 900, q: 0.7, dur: 0.5, g: 0.07, pan, send: 0.7 });
        break;
      case "wind":
        this.ns(t, { f: 260, f2: 420, q: 4, dur: 3.5, a: 1.4, g: 0.04, pan, send: 0.6 });
        break;
    }
  }

  step(surface: Surface, vol: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = vol;
    const pan = (Math.random() - 0.5) * 0.12;
    switch (surface) {
      case "carpet":
        this.ns(t, { type: "lowpass", f: 520, dur: 0.1, g: 0.2 * v, pan, send: 0.08 });
        this.tn(t, { f: 90, f2: 55, dur: 0.07, g: 0.1 * v, lp: 200, send: 0 });
        break;
      case "concrete":
        this.ns(t, { f: 1500 + Math.random() * 300, q: 1.1, dur: 0.07, g: 0.22 * v, pan, send: 0.3 });
        this.tn(t, { f: 110, f2: 60, dur: 0.06, g: 0.1 * v, lp: 260, send: 0 });
        break;
      case "metal":
        this.ns(t, { f: 900, q: 3, dur: 0.14, g: 0.2 * v, pan, send: 0.3 });
        this.ns(t, { f: 2100 + Math.random() * 200, q: 8, dur: 0.22, g: 0.06 * v, pan, send: 0.4 });
        this.tn(t, { f: 90, f2: 55, dur: 0.06, g: 0.08 * v, lp: 220, send: 0 });
        break;
      case "tile":
        this.ns(t, { type: "highpass", f: 1900, dur: 0.05, g: 0.2 * v, pan, send: 0.5 });
        this.ns(t, { f: 3300, q: 2, dur: 0.09, g: 0.1 * v, pan, send: 0.6 });
        break;
      case "water":
        this.ns(t, { f: 650, q: 0.6, dur: 0.25, g: 0.24 * v, pan, send: 0.5 });
        this.ns(t + 0.02, { type: "highpass", f: 2600, dur: 0.14, g: 0.1 * v, pan, send: 0.5 });
        break;
    }
  }

  /* --------------------------------------------------------- interface + items */
  click(kind: "tick" | "back" | "confirm" = "tick") {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.ns(t, { type: "highpass", f: kind === "back" ? 1800 : 3000, dur: 0.02, g: 0.12, send: 0 });
    this.tn(t, { f: kind === "back" ? 200 : kind === "confirm" ? 330 : 280, f2: 130, dur: 0.05, g: 0.06, send: 0, lp: 600 });
  }

  torch(on: boolean) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.ns(t, { type: "highpass", f: 2200, dur: 0.015, g: 0.14, send: 0 });
    this.tn(t, { f: on ? 240 : 170, f2: on ? 160 : 110, dur: 0.06, g: 0.08, lp: 500, send: 0 });
  }

  pickup(kind: string) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    switch (kind) {
      case "water":
        this.tn(t, { f: 900, f2: 700, dur: 0.05, g: 0.09, send: 0.1 });
        this.ns(t, { f: 2400, q: 2, dur: 0.12, g: 0.07, send: 0.1 });
        break;
      case "cell":
        this.tn(t, { f: 2300, dur: 0.18, g: 0.07, send: 0.2 });
        this.tn(t + 0.01, { f: 3150, dur: 0.12, g: 0.05, send: 0.2 });
        this.ns(t, { f: 1400, q: 4, dur: 0.06, g: 0.08, send: 0.1 });
        break;
      case "fuse":
        this.tn(t, { f: 1700, dur: 0.1, g: 0.08, send: 0.2 });
        this.tn(t + 0.07, { f: 2650, dur: 0.14, g: 0.05, send: 0.2 });
        break;
      case "key":
        for (let i = 0; i < 4; i++) this.tn(t + i * 0.05, { f: 2800 + i * 330 + Math.random() * 120, dur: 0.16, g: 0.045, send: 0.3 });
        break;
      case "note":
        this.ns(t, { f: 3200, q: 0.8, dur: 0.22, a: 0.06, g: 0.1, send: 0.1 });
        this.ns(t + 0.12, { f: 2600, q: 0.8, dur: 0.18, a: 0.04, g: 0.07, send: 0.1 });
        break;
    }
  }

  drink() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    for (let i = 0; i < 3; i++) this.ns(t + i * 0.3, { type: "lowpass", f: 420, dur: 0.22, a: 0.05, g: 0.16, send: 0.05 });
  }

  clunk(heavy = true) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tn(t, { f: heavy ? 70 : 120, f2: 38, dur: 0.4, g: 0.34, lp: 220, send: 0.3 });
    this.ns(t, { type: "lowpass", f: 700, dur: 0.18, g: 0.2, send: 0.3 });
    this.ns(t, { f: 1300, q: 16, dur: 0.8, g: 0.07, send: 0.5 });
  }

  relay() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.ns(t, { f: 1800, q: 3, dur: 0.05, g: 0.18, send: 0.1 });
    this.ns(t + 0.09, { f: 1200, q: 3, dur: 0.07, g: 0.2, send: 0.1 });
    this.tn(t + 0.12, { type: "sawtooth", f: 90, f2: 220, dur: 0.9, g: 0.05, lp: 500, send: 0.2 });
  }

  keypad(ok: boolean | null) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    if (ok === null) { this.ns(t, { f: 2600, q: 2, dur: 0.03, g: 0.12, send: 0 }); return; }
    if (ok) this.relay();
    else { this.tn(t, { f: 130, f2: 90, dur: 0.22, g: 0.2, lp: 300, send: 0.1 }); this.ns(t, { f: 900, dur: 0.08, g: 0.08 }); }
  }

  /** stiff, squealing metal; call repeatedly while holding */
  groan(strength = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const f = 280 + Math.random() * 160;
    this.ns(t, { f, f2: f * 1.5, q: 10, dur: 0.55, a: 0.15, g: 0.1 * strength, send: 0.5 });
    this.tn(t, { type: "sawtooth", f: 55, f2: 70, dur: 0.5, g: 0.06 * strength, lp: 200, send: 0.3 });
  }

  blackout(on: boolean) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    if (on) {
      this.tn(t, { type: "sawtooth", f: 130, f2: 22, dur: 1.4, g: 0.16, lp: 400, send: 0.3 });
      this.clunk(true);
    } else {
      this.clunk(false);
      this.tn(t + 0.1, { type: "sawtooth", f: 40, f2: 110, dur: 1.2, g: 0.1, lp: 400, send: 0.3 });
    }
  }

  flicker(x: number, y: number) {
    if (!this.ctx) return;
    const s = this.spatial(x, y);
    if (s.d > 14) return;
    const t = this.ctx.currentTime;
    for (let i = 0; i < 3; i++) this.ns(t + i * 0.05, { type: "highpass", f: 3200, dur: 0.03, g: 0.1 * s.gain, pan: s.pan, send: 0.2 });
  }

  hurt() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tn(t, { f: 90, f2: 35, dur: 0.5, g: 0.5, lp: 220, send: 0.2 });
    this.ns(t, { type: "lowpass", f: 600, dur: 0.25, g: 0.3 });
    this.tn(t + 0.05, { f: 3400, dur: 1.6, g: 0.035, send: 0.4 }); // tinnitus
    this.duckT = 0.9;
    setTimeout(() => { this.duckT = 0; }, 900);
  }

  startGenerator() {
    if (!this.ctx || this.genGain) return;
    const c = this.ctx;
    this.genGain = c.createGain();
    this.genGain.gain.setValueAtTime(0.0001, c.currentTime);
    this.genGain.gain.exponentialRampToValueAtTime(0.1, c.currentTime + 3);
    const o = c.createOscillator(); o.type = "sawtooth"; o.frequency.value = 43;
    const f = c.createBiquadFilter(); f.type = "lowpass"; f.frequency.value = 240;
    const lfo = c.createOscillator(); lfo.frequency.value = 11;
    const lg = c.createGain(); lg.gain.value = 0.04;
    lfo.connect(lg); lg.connect(this.genGain.gain);
    o.connect(f); f.connect(this.genGain); this.genGain.connect(this.amb);
    o.start(); lfo.start();
    this.genNodes = [o, lfo];
  }

  stopGenerator() {
    if (this.ctx && this.genGain) {
      const t = this.ctx.currentTime;
      this.genGain.gain.cancelScheduledValues(t);
      this.genGain.gain.setTargetAtTime(0.0001, t, 0.15);
      for (const n of this.genNodes) { try { n.stop(t + 1); } catch { /* already stopped */ } }
    }
    this.genNodes = [];
    this.genGain = null;
  }

  engineSputter() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    for (let i = 0; i < 5; i++) this.tn(t + i * (0.18 - i * 0.02), { type: "sawtooth", f: 60 + i * 12, f2: 40, dur: 0.14, g: 0.2, lp: 300, send: 0.3 });
  }

  /* --------------------------------------------------------- creatures */
  emit(name: string, x: number, y: number, vol = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const s = this.spatial(x, y);
    if (s.d > 26) return;
    const g = vol * s.gain;
    const o = { pan: s.pan, send: s.send, lp: s.lp };
    switch (name) {
      case "listenerTick": {
        const n = 2 + Math.floor(Math.random() * 3);
        let tt = t;
        for (let i = 0; i < n; i++) { this.tn(tt, { type: "triangle", f: 1700 + Math.random() * 500, dur: 0.012, g: 0.2 * g, ...o }); tt += 0.04 + Math.random() * 0.1; }
        break;
      }
      case "listenerBreath":
        this.ns(t, { f: 520, f2: 380, q: 1.4, dur: 1.1, a: 0.5, g: 0.16 * g, ...o });
        break;
      case "listenerRush":
        this.tn(t, { type: "sawtooth", f: 340, f2: 1000, dur: 0.7, g: 0.2 * g, am: 31, ...o, lp: 3200 });
        this.ns(t, { f: 1800, f2: 900, q: 1.2, dur: 0.7, g: 0.2 * g, ...o });
        break;
      case "listenerMimic": // your own footsteps, a little wrong
        this.ns(t, { type: "lowpass", f: 480, dur: 0.1, g: 0.2 * g, ...o });
        this.ns(t + 0.52, { type: "lowpass", f: 420, dur: 0.1, g: 0.18 * g, ...o });
        break;
      case "skitter": {
        let tt = t;
        for (let i = 0; i < 9; i++) { this.ns(tt, { f: 3400 + Math.random() * 1200, q: 3, dur: 0.012, g: 0.16 * g, ...o }); tt += 0.03 + Math.random() * 0.035; }
        break;
      }
      case "chitter":
        this.tn(t, { type: "square", f: 880, f2: 760, dur: 0.6, g: 0.1 * g, am: 38, ...o, lp: 4200 });
        break;
      case "lunge":
        this.ns(t, { f: 500, f2: 3200, q: 1.5, dur: 0.5, g: 0.28 * g, ...o });
        this.tn(t, { type: "sawtooth", f: 620, f2: 1500, dur: 0.4, g: 0.12 * g, ...o, lp: 3800 });
        break;
      case "wardenStep":
        this.tn(t, { f: 56, f2: 34, dur: 0.28, g: 0.5 * g, ...o, lp: 160 });
        this.ns(t, { type: "lowpass", f: 400, dur: 0.12, g: 0.3 * g, ...o });
        for (let i = 0; i < 3; i++) this.tn(t + 0.05 + i * 0.045 + Math.random() * 0.03, { f: 2400 + Math.random() * 1800, dur: 0.1, g: 0.05 * g, ...o });
        break;
      case "wardenBreath":
        this.ns(t, { f: 720, q: 1.6, dur: 1.2, a: 0.55, g: 0.15 * g, ...o });
        break;
      case "wardenSpot":
        this.tn(t, { type: "sawtooth", f: 90, f2: 60, dur: 1, g: 0.3 * g, am: 14, ...o, lp: 400 });
        this.ns(t, { f: 700, q: 0.6, dur: 0.8, g: 0.2 * g, ...o });
        break;
      case "growl":
        this.tn(t, { type: "sawtooth", f: 64, f2: 52, dur: 0.9, g: 0.26 * g, am: 22, ...o, lp: 320 });
        this.ns(t, { f: 380, q: 1.2, dur: 0.7, a: 0.1, g: 0.1 * g, ...o });
        break;
      case "pant":
        this.ns(t, { f: 1500, q: 0.8, dur: 0.18, a: 0.04, g: 0.1 * g, ...o });
        this.ns(t + 0.28, { f: 1400, q: 0.8, dur: 0.18, a: 0.04, g: 0.08 * g, ...o });
        break;
      case "howl":
        this.tn(t, { type: "sawtooth", f: 260, f2: 430, dur: 0.5, g: 0.2 * g, ...o, lp: 1800 });
        this.tn(t + 0.5, { type: "sawtooth", f: 430, f2: 250, dur: 0.8, g: 0.18 * g, ...o, lp: 1500 });
        break;
      case "paws": {
        let tt = t;
        for (let i = 0; i < 4; i++) { this.ns(tt, { type: "lowpass", f: 700, dur: 0.05, g: 0.14 * g, ...o }); tt += 0.12; }
        break;
      }
      case "clack":
        this.tn(t, { type: "triangle", f: 210, f2: 150, dur: 0.07, g: 0.3 * g, ...o });
        this.ns(t, { f: 2200, q: 2, dur: 0.03, g: 0.2 * g, ...o });
        break;
      case "ring":
        this.tn(t, { f: 5900, dur: 1.6, a: 0.5, g: 0.04 * g, ...o, send: 0.1 });
        break;
      case "gurgle":
        for (let i = 0; i < 4; i++) this.tn(t + i * 0.13 + Math.random() * 0.05, { f: 260 + Math.random() * 100, f2: 620 + Math.random() * 300, dur: 0.1, g: 0.16 * g, ...o });
        this.ns(t, { type: "lowpass", f: 500, dur: 0.6, a: 0.2, g: 0.12 * g, ...o });
        break;
      case "splash":
        this.ns(t, { f: 800, q: 0.7, dur: 0.4, g: 0.26 * g, ...o });
        break;
      case "groanFar":
        this.ns(t, { f: 300, f2: 480, q: 8, dur: 1.2, a: 0.3, g: 0.14 * g, ...o });
        break;
    }
  }
}
