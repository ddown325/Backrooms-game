import { fbm, hash2, mixc, pack, shade, TAU } from "./util";
import type { Tex, ThemeId } from "./types";

export interface ThemeTex {
  wallA: Tex;
  wallB: Tex;
  floorA: Tex;
  floorB: Tex[]; // alt floor, animated for water
  ceil: Tex;
  ceilLamp: Tex; // panel pixels carry alpha 254 so the renderer can treat them as emissive
}

const S = 128;

export function gen(w: number, h: number, fn: (u: number, v: number, x: number, y: number) => number): Tex {
  const d = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const c = fn(x / w, y / h, x, y);
      const i = (y * w + x) * 4;
      d[i] = (c >> 16) & 255;
      d[i + 1] = (c >> 8) & 255;
      d[i + 2] = c & 255;
      d[i + 3] = 255;
    }
  }
  return { w, h, d };
}

const frac = (v: number) => v - Math.floor(v);
const ss = (a: number, b: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
const grain = (x: number, y: number, s: number) => hash2(x, y, s) - 0.5;

/* ------------------------------------------------------------------ LEVEL 0 */
function yellowWall(variant: number): Tex {
  const seed = 11 + variant * 7;
  return gen(S, S, (u, v, x, y) => {
    let r = 203, g = 176, b = 98;
    const stripe = Math.sin(u * TAU * 8) * 0.5 + 0.5;
    let k = 0.94 + 0.07 * stripe;
    // damask diamonds
    const dx = Math.abs(frac(u * 8) - 0.5), dy = Math.abs(frac(v * 8) - 0.5);
    const dd = dx + dy;
    if (dd < 0.24 && dd > 0.17) k *= 0.93;
    if (dd < 0.07) k *= 0.9;
    if (variant === 1) {
      // lower wood panelling with a chair rail
      if (v > 0.58) {
        r = 128; g = 92; b = 58;
        k = 0.82 + 0.25 * fbm(u * 3, v * 36, 3, seed + 3, 3);
        const pan = frac(u * 2);
        if (pan < 0.02 || pan > 0.98) k *= 0.55;
      }
      if (v > 0.55 && v < 0.585) { r = 214; g = 190; b = 140; k = 1.04 - (v - 0.55) * 8; }
    }
    // water stains running from the ceiling, mould creeping from the floor
    const stain = fbm(u * 3, v * 2.2, 4, seed, 3);
    const streak = fbm(u * 14, v * 1.6, 3, seed + 5, 14);
    const wet = ss(0.5, 0.78, stain) * (0.25 + 0.75 * streak) * (1 - v * 0.55);
    k *= 1 - wet * 0.38;
    const mould = ss(0.72, 1, v + (fbm(u * 6, v * 6, 3, seed + 9, 6) - 0.5) * 0.35) * 0.4;
    r = r * k - mould * 70; g = g * k - mould * 25; b = b * k - mould * 40;
    if (v > 0.9) { // skirting
      const s = 0.55 + (v - 0.9) * -1.2 + 0.1 * fbm(u * 8, v * 8, 2, seed, 8);
      r = 104 * s * 1.3; g = 78 * s * 1.3; b = 48 * s * 1.3;
      if (v < 0.915) { r *= 1.35; g *= 1.35; b *= 1.35; }
    }
    if (v < 0.03) { r *= 1.07; g *= 1.07; b *= 1.05; }
    const n = grain(x, y, seed) * 9;
    return pack(r + n, g + n, b + n * 0.7);
  });
}

function yellowFloor(): Tex {
  return gen(S, S, (u, v, x, y) => {
    const mott = fbm(u * 8, v * 8, 4, 31, 8, 8);
    const wear = fbm(u * 3, v * 3, 3, 33, 3, 3);
    let k = 0.82 + mott * 0.32 - wear * 0.1;
    // woven fibres
    const f = hash2(x, y, 5) * 0.22 + (((x + (y >> 1)) & 3) === 0 ? 0.06 : 0);
    k += f - 0.12;
    const stain = ss(0.62, 0.8, fbm(u * 2, v * 2, 3, 37, 2, 2));
    return pack(120 * k * (1 - stain * 0.25), 104 * k * (1 - stain * 0.2), 56 * k * (1 - stain * 0.1));
  });
}

function yellowCeil(lamp: boolean): Tex {
  const t = gen(S, S, (u, v, x, y) => {
    const tu = frac(u * 2), tv = frac(v * 2);
    let k = 0.93 + 0.1 * fbm(u * 6, v * 6, 3, 41, 6, 6);
    // perforations
    const pu = frac(u * 16), pv = frac(v * 16);
    if (Math.hypot(pu - 0.5, pv - 0.5) < 0.13 && hash2(Math.floor(u * 16), Math.floor(v * 16), 3) > 0.35) k *= 0.72;
    let r = 214 * k, g = 207 * k, b = 182 * k;
    if (tu < 0.035 || tu > 0.965 || tv < 0.035 || tv > 0.965) { r = 164; g = 160; b = 146; }
    const stain = ss(0.66, 0.85, fbm(u * 2, v * 2, 3, 45, 2, 2));
    r *= 1 - stain * 0.3; g *= 1 - stain * 0.28; b *= 1 - stain * 0.4;
    r += grain(x, y, 4) * 5; g += grain(x, y, 4) * 5; b += grain(x, y, 4) * 5;
    return pack(r, g, b);
  });
  if (lamp) panel(t, 0.14, 0.22, 0.86, 0.78, [255, 252, 226], 8);
  return t;
}

/** paints an emissive rectangular diffuser (alpha 254) into a ceiling texture */
function panel(t: Tex, u0: number, v0: number, u1: number, v1: number, col: number[], ribs: number) {
  for (let y = 0; y < t.h; y++) {
    for (let x = 0; x < t.w; x++) {
      const u = x / t.w, v = y / t.h;
      const i = (y * t.w + x) * 4;
      const edge = Math.min(u - u0, u1 - u, v - v0, v1 - v);
      if (edge < -0.012) continue;
      if (edge < 0) { // frame
        t.d[i] = 150; t.d[i + 1] = 150; t.d[i + 2] = 146;
        continue;
      }
      const rib = ribs > 0 ? 0.93 + 0.07 * Math.sin(((u - u0) / (u1 - u0)) * ribs * TAU) : 1;
      const fall = 0.82 + 0.18 * Math.min(1, edge * 14);
      t.d[i] = col[0] * rib * fall;
      t.d[i + 1] = col[1] * rib * fall;
      t.d[i + 2] = col[2] * rib * fall;
      t.d[i + 3] = 254;
    }
  }
}

/* ------------------------------------------------------------------ LEVEL 1 */
function concreteWall(variant: number): Tex {
  const seed = 71 + variant * 5;
  return gen(S, S, (u, v, x, y) => {
    let base = 138;
    const pu = frac(u * 2), pv = frac(v * 2);
    const seam = Math.min(pu, 1 - pu, pv, 1 - pv);
    let k = 0.9 + 0.2 * fbm(u * 10, v * 10, 4, seed, 10, 10);
    if (seam < 0.012) k *= 0.55;
    else if (seam < 0.024) k *= 0.88;
    // formwork tie holes
    const hx = frac(u * 2 + 0.25), hy = frac(v * 2 + 0.25);
    if (Math.hypot(hx - 0.5, hy - 0.5) < 0.026) k *= 0.38;
    // board grain from the plywood forms
    k *= 0.96 + 0.06 * fbm(u * 2, v * 40, 2, seed + 2, 2);
    const streak = fbm(u * 9, v * 1.3, 3, seed + 3, 9);
    k *= 1 - ss(0.5, 0.8, streak) * 0.3 * (1 - v * 0.5);
    let r = base * k, g = base * k * 0.99, b = base * k * 0.94;
    const damp = ss(0.78, 1, v) * 0.35;
    r *= 1 - damp; g *= 1 - damp * 0.9; b *= 1 - damp * 0.7;
    if (variant === 1) {
      if (v > 0.5) { // painted institutional green lower half
        const paint = 0.8 + 0.25 * fbm(u * 12, v * 12, 3, seed + 8, 12, 12);
        r = 96 * paint; g = 118 * paint; b = 100 * paint;
        if (fbm(u * 7, v * 7, 3, seed + 11, 7, 7) > 0.66) { r = 140 * k; g = 138 * k; b = 130 * k; } // peeling
      }
      if (v > 0.495 && v < 0.52) { r = 190; g = 188; b = 170; }
    } else if (v > 0.9) {
      // safety stripe
      const s = Math.floor((u * 8 + (v - 0.9) * 8) % 2 + 2) % 2;
      r = s ? 200 * k : 40; g = s ? 160 * k : 38; b = s ? 40 * k : 36;
    }
    const n = grain(x, y, seed) * 8;
    return pack(r + n, g + n, b + n);
  });
}

function concreteFloor(): Tex {
  return gen(S, S, (u, v, x, y) => {
    let k = 0.86 + 0.22 * fbm(u * 6, v * 6, 4, 81, 6, 6);
    const crack = Math.abs(fbm(u * 5, v * 5, 4, 83, 5, 5) - 0.5);
    if (crack < 0.012) k *= 0.45;
    const joint = Math.min(u, v, 1 - u, 1 - v);
    if (joint < 0.012) k *= 0.55;
    const oil = ss(0.66, 0.78, fbm(u * 3, v * 3, 3, 85, 3, 3));
    k *= 1 - oil * 0.35;
    const g = grain(x, y, 6) * 10;
    return pack(116 * k + g, 114 * k + g, 108 * k + g);
  });
}

function concreteCeil(lamp: boolean): Tex {
  const t = gen(S, S, (u, v, x, y) => {
    let k = 0.62 + 0.25 * fbm(u * 8, v * 8, 4, 91, 8, 8);
    const beam = Math.abs(u - 0.5);
    if (beam < 0.1) k *= 0.62 + beam * 2.5;
    if (beam > 0.098 && beam < 0.11) k *= 1.25;
    // cable tray
    if (v > 0.45 && v < 0.5) k *= 0.5;
    const g = grain(x, y, 8) * 7;
    return pack(98 * k + g, 98 * k + g, 94 * k + g);
  });
  if (lamp) panel(t, 0.34, 0.34, 0.66, 0.66, [255, 205, 140], 0);
  return t;
}

/* ------------------------------------------------------------------ LEVEL 2 */
function pipesWall(variant: number): Tex {
  const seed = 131 + variant * 3;
  if (variant === 0) {
    return gen(S, S, (u, v, x, y) => {
      // brick, running bond, 8 courses per cell
      const row = Math.floor(v * 8);
      const bu = frac(u * 4 + (row & 1) * 0.5);
      const bv = frac(v * 8);
      const mortar = bu < 0.045 || bu > 0.955 || bv < 0.1 || bv > 0.9;
      const id = hash2(Math.floor(u * 4 + (row & 1) * 0.5), row, seed);
      let k = 0.78 + id * 0.45 + (fbm(u * 12, v * 12, 3, seed, 12, 12) - 0.5) * 0.25;
      let r = 128 * k, g = 66 * k, b = 50 * k;
      if (mortar) { r = 78; g = 72; b = 66; }
      const soot = ss(0.4, 1, 1 - v) * 0.2 + ss(0.55, 0.8, fbm(u * 3, v * 3, 3, seed + 4, 3, 3)) * 0.3;
      r *= 1 - soot; g *= 1 - soot * 0.8; b *= 1 - soot * 0.7;
      const salt = ss(0.7, 0.9, fbm(u * 5, v * 5, 3, seed + 6, 5, 5)) * (v > 0.5 ? 0.35 : 0);
      r += salt * 90; g += salt * 90; b += salt * 90;
      const n = grain(x, y, seed) * 10;
      return pack(r + n, g + n, b + n);
    });
  }
  return gen(S, S, (u, v, x, y) => {
    // riveted steel plates with a heavy pipe run
    const pu = frac(u * 2), pv = frac(v * 2);
    const seam = Math.min(pu, 1 - pu, pv, 1 - pv);
    let k = 0.86 + 0.2 * fbm(u * 8, v * 8, 4, seed, 8, 8);
    let r = 96 * k, g = 88 * k, b = 80 * k;
    if (seam < 0.014) { r *= 0.5; g *= 0.5; b *= 0.5; }
    for (const [cx, cy] of [[0.06, 0.06], [0.44, 0.06], [0.06, 0.44], [0.44, 0.44]]) {
      for (let q = 0; q < 4; q++) {
        const ox = (q & 1) * 0.5, oy = (q >> 1) * 0.5;
        if (Math.hypot(u - cx - ox, v - cy - oy) < 0.016) { r *= 1.35; g *= 1.35; b *= 1.35; }
      }
    }
    const rust = ss(0.5, 0.75, fbm(u * 6, v * 5, 4, seed + 2, 6, 5)) * 0.8;
    r = r * (1 - rust) + 150 * rust * k; g = g * (1 - rust) + 80 * rust * k; b = b * (1 - rust) + 36 * rust * k;
    const py = (v - 0.3) / 0.12;
    if (Math.abs(py) < 1) {
      const cyl = Math.sqrt(1 - py * py);
      const l = 0.28 + 0.9 * cyl * cyl;
      r = 108 * l; g = 104 * l; b = 98 * l + 6;
      const band = frac(u * 4);
      if (band < 0.03) { r *= 0.55; g *= 0.55; b *= 0.55; }
      if (fbm(u * 10, v * 10, 3, seed + 8, 10, 10) > 0.62) { r = r * 0.7 + 60; g = g * 0.7 + 34; b = b * 0.7 + 14; }
    }
    const n = grain(x, y, seed) * 8;
    return pack(r + n, g + n, b + n);
  });
}

function pipesFloor(): Tex {
  return gen(S, S, (u, v, x, y) => {
    // diamond plate
    const gx = frac(u * 8), gy = frac(v * 8);
    const a = Math.abs(gx - 0.5) + Math.abs(gy - 0.5);
    const cell = (Math.floor(u * 8) + Math.floor(v * 8)) & 1;
    let k = 0.6 + 0.2 * fbm(u * 5, v * 5, 3, 151, 5, 5);
    const lug = cell ? Math.abs(gx - 0.5) * 0.9 : Math.abs(gy - 0.5) * 0.9;
    if (a < 0.42) k += 0.28 * (0.6 - lug);
    const puddle = ss(0.58, 0.66, fbm(u * 3, v * 3, 4, 155, 3, 3));
    k *= 1 - puddle * 0.45;
    const g = grain(x, y, 9) * 8;
    return pack(66 * k + g + puddle * 4, 66 * k + g + puddle * 6, 64 * k + g + puddle * 12);
  });
}

function pipesCeil(lamp: boolean): Tex {
  const t = gen(S, S, (u, v, x, y) => {
    let k = 0.4 + 0.2 * fbm(u * 8, v * 8, 3, 161, 8, 8);
    let r = 70 * k, g = 62 * k, b = 56 * k;
    for (const [c, rad, col] of [[0.18, 0.1, 110], [0.62, 0.07, 90], [0.82, 0.045, 100]] as [number, number, number][]) {
      const d = (u - c) / rad;
      if (Math.abs(d) < 1) {
        const cyl = Math.sqrt(1 - d * d);
        const l = 0.2 + 0.9 * cyl * cyl;
        r = col * l; g = (col - 6) * l; b = (col - 14) * l;
        if (frac(v * 3) < 0.04) { r *= 0.5; g *= 0.5; b *= 0.5; }
      }
    }
    const n = grain(x, y, 3) * 6;
    return pack(r + n, g + n, b + n);
  });
  if (lamp) {
    // caged bulb
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const u = x / S, v = y / S;
      const d = Math.hypot(u - 0.5, v - 0.5);
      const i = (y * S + x) * 4;
      if (d < 0.14) {
        const cage = Math.abs(frac(u * 7) - 0.5) < 0.06 || Math.abs(frac(v * 7) - 0.5) < 0.06;
        const l = 1 - d * 2;
        t.d[i] = cage ? 90 : 255 * (0.75 + l * 0.25);
        t.d[i + 1] = cage ? 80 : 188 * (0.75 + l * 0.25);
        t.d[i + 2] = cage ? 60 : 112 * (0.75 + l * 0.25);
        t.d[i + 3] = cage ? 255 : 254;
      } else if (d < 0.165) { t.d[i] = 40; t.d[i + 1] = 38; t.d[i + 2] = 36; }
    }
  }
  return t;
}

/* ------------------------------------------------------------------ LEVEL 3 */
function poolWall(variant: number): Tex {
  const seed = 211 + variant * 9;
  return gen(S, S, (u, v, x, y) => {
    const n = variant === 0 ? 8 : 16;
    const tu = frac(u * n), tv = frac(v * n);
    const id = hash2(Math.floor(u * n), Math.floor(v * n), seed);
    const grout = tu < 0.07 || tv < 0.07;
    let r: number, g: number, b: number;
    if (variant === 0) {
      const band = v > 0.78 && v < 0.9;
      const k = 0.94 + id * 0.1;
      if (band) { r = 70 * k; g = 150 * k; b = 168 * k; }
      else { r = 214 * k; g = 228 * k; b = 226 * k; }
      if (grout) { r = 150; g = 166; b = 164; }
    } else {
      const k = 0.78 + id * 0.4;
      r = 70 * k; g = 160 * k; b = 170 * k;
      if (id > 0.82) { r = 210; g = 226; b = 226; }
      if (grout) { r = 120; g = 150; b = 152; }
    }
    // gloss streak and water line
    const gloss = ss(0.44, 0.5, u) * (1 - ss(0.5, 0.58, u)) * 0.08 * (grout ? 0 : 1);
    r += gloss * 255; g += gloss * 255; b += gloss * 255;
    const scum = ss(0.82, 0.86, v) * 0.18 * fbm(u * 10, v * 4, 3, seed, 10);
    r -= scum * 90; g -= scum * 50; b -= scum * 80;
    const grit = ss(0.6, 0.75, fbm(u * 5, v * 5, 3, seed + 1, 5, 5)) * 0.14;
    r *= 1 - grit; g *= 1 - grit; b *= 1 - grit * 1.2;
    const nn = grain(x, y, seed) * 6;
    return pack(r + nn, g + nn, b + nn);
  });
}

function poolFloor(): Tex {
  return gen(S, S, (u, v, x, y) => {
    const tu = frac(u * 4), tv = frac(v * 4);
    const id = hash2(Math.floor(u * 4), Math.floor(v * 4), 221);
    let k = 0.92 + id * 0.1;
    let r = 224 * k, g = 224 * k, b = 212 * k;
    if (tu < 0.04 || tv < 0.04) { r = 150; g = 154; b = 146; }
    const dirt = ss(0.55, 0.78, fbm(u * 4, v * 4, 4, 223, 4, 4)) * 0.3;
    r *= 1 - dirt; g *= 1 - dirt * 0.95; b *= 1 - dirt * 0.8;
    const n = grain(x, y, 4) * 6;
    return pack(r + n, g + n, b + n);
  });
}

function poolWater(phase: number): Tex {
  return gen(S, S, (u, v, x, y) => {
    // two interfering warped sine fields give caustic filaments
    const w1 = Math.sin((u * 4 + Math.sin(v * TAU * 2 + phase) * 0.18) * TAU);
    const w2 = Math.sin((v * 4 + Math.sin(u * TAU * 3 - phase * 1.3) * 0.16) * TAU);
    const c = Math.pow(1 - Math.abs(w1 * w2), 6);
    const depth = 0.72 + 0.25 * fbm(u * 3 + phase * 0.1, v * 3, 3, 227, 3, 3);
    const tile = (frac(u * 4) < 0.03 || frac(v * 4) < 0.03) ? 0.82 : 1;
    const r = (34 + 120 * c) * depth * tile, g = (112 + 120 * c) * depth * tile, b = (136 + 100 * c) * depth * tile;
    return pack(r + grain(x, y, 5) * 4, g + grain(x, y, 5) * 4, b + grain(x, y, 5) * 4);
  });
}

function poolCeil(lamp: boolean): Tex {
  const t = gen(S, S, (u, v, x, y) => {
    let k = 0.9 + 0.1 * fbm(u * 6, v * 6, 3, 231, 6, 6);
    const rib = 0.94 + 0.06 * Math.sin(u * TAU * 8);
    k *= rib;
    const tu = frac(u * 2), tv = frac(v * 2);
    let r = 218 * k, g = 224 * k, b = 224 * k;
    if (tu < 0.03 || tv < 0.03) { r = 168; g = 176; b = 176; }
    const stain = ss(0.65, 0.82, fbm(u * 3, v * 3, 3, 233, 3, 3)) * 0.2;
    r *= 1 - stain; g *= 1 - stain * 0.8; b *= 1 - stain * 0.5;
    const n = grain(x, y, 6) * 5;
    return pack(r + n, g + n, b + n);
  });
  if (lamp) panel(t, 0.1, 0.1, 0.9, 0.9, [236, 250, 255], 0);
  return t;
}

/* ------------------------------------------------------------------ LEVEL 4 */
function plantWall(variant: number): Tex {
  const seed = 311 + variant * 4;
  return gen(S, S, (u, v, x, y) => {
    let r: number, g: number, b: number;
    const pu = frac(u * 2);
    let k = 0.86 + 0.2 * fbm(u * 8, v * 8, 4, seed, 8, 8);
    if (variant === 0) {
      r = 52 * k; g = 78 * k; b = 82 * k;
      if (pu < 0.016 || pu > 0.984) { r *= 0.5; g *= 0.5; b *= 0.5; }
      // bolts
      for (let q = 0; q < 2; q++) for (const by of [0.08, 0.92]) {
        if (Math.hypot(u - (q * 0.5 + 0.06), v - by) < 0.014) { r += 50; g += 50; b += 50; }
      }
      // conduit
      for (const cy of [0.2, 0.27]) {
        const d = (v - cy) / 0.028;
        if (Math.abs(d) < 1) {
          const l = 0.3 + 0.9 * (1 - d * d);
          r = 120 * l; g = 126 * l; b = 126 * l;
          if (frac(u * 4) < 0.03) { r *= 0.5; g *= 0.5; b *= 0.5; }
        }
      }
      const drip = ss(0.55, 0.8, fbm(u * 12, v * 1.4, 3, seed + 3, 12));
      r *= 1 - drip * 0.3; g *= 1 - drip * 0.3; b *= 1 - drip * 0.25;
    } else {
      // painted concrete with a hazard band and a stencilled panel
      r = 112 * k; g = 116 * k; b = 112 * k;
      if (v > 0.84 && v < 0.96) {
        const s = Math.floor(((u + (v - 0.84)) * 8) % 2 + 2) % 2;
        r = s ? 214 * k : 30; g = s ? 170 * k : 30; b = s ? 28 * k : 30;
      }
      if (v > 0.16 && v < 0.26 && u > 0.2 && u < 0.8) { r = 40; g = 44; b = 44; if (frac(u * 24) < 0.5 && hash2(Math.floor(u * 24), 1, seed) > 0.35) { r = 190; g = 190; b = 180; } }
      const stain = ss(0.55, 0.8, fbm(u * 4, v * 3, 3, seed + 1, 4, 3));
      r *= 1 - stain * 0.3; g *= 1 - stain * 0.3; b *= 1 - stain * 0.3;
    }
    const n = grain(x, y, seed) * 8;
    return pack(r + n, g + n, b + n);
  });
}

function plantFloor(alt: boolean): Tex {
  return gen(S, S, (u, v, x, y) => {
    if (alt) { // hazard painted plate
      const s = Math.floor(((u + v) * 6) % 2 + 2) % 2;
      let k = 0.8 + 0.25 * fbm(u * 6, v * 6, 3, 331, 6, 6);
      const edge = Math.min(u, v, 1 - u, 1 - v);
      let r = s ? 205 * k : 34 * k, g = s ? 160 * k : 34 * k, b = s ? 24 * k : 32 * k;
      if (edge < 0.025) { r *= 0.5; g *= 0.5; b *= 0.5; }
      return pack(r, g, b);
    }
    const gx = frac(u * 8), gy = frac(v * 8);
    const hole = gx > 0.2 && gx < 0.8 && gy > 0.2 && gy < 0.8;
    let k = 0.7 + 0.25 * fbm(u * 5, v * 5, 3, 333, 5, 5);
    let r = 74 * k, g = 78 * k, b = 78 * k;
    if (hole) { r = 10; g = 12; b = 14; const lip = Math.min(gx - 0.2, 0.8 - gx, gy - 0.2, 0.8 - gy); if (lip < 0.05) { r += 30; g += 32; b += 34; } }
    const n = grain(x, y, 5) * 6;
    return pack(r + n, g + n, b + n);
  });
}

function plantCeil(lamp: boolean): Tex {
  const t = gen(S, S, (u, v, x, y) => {
    let k = 0.4 + 0.2 * fbm(u * 8, v * 8, 3, 341, 8, 8);
    let r = 52 * k, g = 60 * k, b = 62 * k;
    const tray = Math.abs(v - 0.5);
    if (tray < 0.14) { const l = 0.5 + 0.5 * (tray < 0.12 ? 1 : 0.4); r = 66 * l; g = 70 * l; b = 70 * l; if (frac(u * 8) < 0.1) { r *= 0.5; g *= 0.5; b *= 0.5; } }
    for (const c of [0.44, 0.5, 0.56]) if (Math.abs(v - c) < 0.012) { r = 24; g = 26; b = 26; }
    const n = grain(x, y, 3) * 6;
    return pack(r + n, g + n, b + n);
  });
  if (lamp) panel(t, 0.12, 0.4, 0.88, 0.6, [214, 242, 255], 0);
  return t;
}

const cache: Partial<Record<ThemeId, ThemeTex>> = {};

export function buildTheme(id: ThemeId): ThemeTex {
  const hit = cache[id];
  if (hit) return hit;
  let t: ThemeTex;
  switch (id) {
    case "yellow":
      t = { wallA: yellowWall(0), wallB: yellowWall(1), floorA: yellowFloor(), floorB: [tileFloorWarm()], ceil: yellowCeil(false), ceilLamp: yellowCeil(true) };
      break;
    case "concrete":
      t = { wallA: concreteWall(0), wallB: concreteWall(1), floorA: concreteFloor(), floorB: [concreteFloor()], ceil: concreteCeil(false), ceilLamp: concreteCeil(true) };
      break;
    case "pipes":
      t = { wallA: pipesWall(0), wallB: pipesWall(1), floorA: pipesFloor(), floorB: [pipesFloor()], ceil: pipesCeil(false), ceilLamp: pipesCeil(true) };
      break;
    case "pool":
      t = { wallA: poolWall(0), wallB: poolWall(1), floorA: poolFloor(), floorB: [poolWater(0), poolWater(1.1), poolWater(2.2), poolWater(3.3)], ceil: poolCeil(false), ceilLamp: poolCeil(true) };
      break;
    default:
      t = { wallA: plantWall(0), wallB: plantWall(1), floorA: plantFloor(false), floorB: [plantFloor(true)], ceil: plantCeil(false), ceilLamp: plantCeil(true) };
  }
  cache[id] = t;
  return t;
}

/** checkered vinyl used in break rooms and restrooms on the first level */
function tileFloorWarm(): Tex {
  return gen(S, S, (u, v, x, y) => {
    const a = (Math.floor(u * 4) + Math.floor(v * 4)) & 1;
    const edge = Math.min(frac(u * 4), frac(v * 4));
    let k = 0.86 + 0.2 * fbm(u * 6, v * 6, 3, 351, 6, 6);
    let c = a ? mixc(0xc8c0a4, 0x000000, 0) : mixc(0x7a6a44, 0x000000, 0);
    c = shade(c, k);
    if (edge < 0.03) c = shade(c, 0.6);
    const n = grain(x, y, 2) * 8;
    return pack((c >> 16 & 255) + n, (c >> 8 & 255) + n, (c & 255) + n);
  });
}
