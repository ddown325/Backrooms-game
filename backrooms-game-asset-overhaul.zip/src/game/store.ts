export interface Settings {
  sens: number;
  volume: number;
  brightness: number;
  fov: number;
  bob: number;
  grain: number;
  invertY: boolean;
  showFps: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  sens: 1,
  volume: 0.75,
  brightness: 1,
  fov: 74,
  bob: 1,
  grain: 0.5,
  invertY: false,
  showFps: false,
};

export interface Records {
  runs: number;
  deaths: number;
  escapes: number;
  cleared: number[]; // levels cleared at least once
  best: Record<string, number>; // best time per level
  notes: number[];
  encounters: number;
}

export const EMPTY_RECORDS: Records = { runs: 0, deaths: 0, escapes: 0, cleared: [], best: {}, notes: [], encounters: 0 };

const SK = "backrooms.settings.v1";
const RK = "backrooms.records.v1";

export function loadSettings(): Settings {
  try {
    const s = JSON.parse(localStorage.getItem(SK) || "null");
    if (s && typeof s === "object") return { ...DEFAULT_SETTINGS, ...s };
  } catch { /* storage unavailable */ }
  return { ...DEFAULT_SETTINGS };
}
export function saveSettings(s: Settings) {
  try { localStorage.setItem(SK, JSON.stringify(s)); } catch { /* ignore */ }
}
export function loadRecords(): Records {
  try {
    const r = JSON.parse(localStorage.getItem(RK) || "null");
    if (r && typeof r === "object") return { ...EMPTY_RECORDS, ...r };
  } catch { /* ignore */ }
  return { ...EMPTY_RECORDS, cleared: [], best: {}, notes: [] };
}
export function saveRecords(r: Records) {
  try { localStorage.setItem(RK, JSON.stringify(r)); } catch { /* ignore */ }
}
