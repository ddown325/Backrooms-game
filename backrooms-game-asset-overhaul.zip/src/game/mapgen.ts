import { Rng } from "./util";
import { NOTES, type LevelDef } from "./levels";
import type { Decal, Difficulty, Lamp, Level, Pickup, PickupKind, Prop, Room } from "./types";
import { decalArt } from "./decals";
import { propSprite } from "./sprites";

export const DIRS: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
export const faceFrom = (dx: number, dy: number) => (dx === 1 ? 0 : dx === -1 ? 1 : dy === 1 ? 2 : 3);

const LOBBY: Record<string, string> = { yellow: "Lobby", concrete: "Loading Bay", pipes: "Access Shaft", pool: "Reception", plant: "Gatehouse" };

export function generateLevel(def: LevelDef, diff: Difficulty, seed: number): Level {
  const rng = new Rng(seed);
  const n = def.size;
  const idx = (x: number, y: number) => y * n + x;
  const inside = (x: number, y: number) => x > 0 && y > 0 && x < n - 1 && y < n - 1;
  const map = new Uint8Array(n * n).fill(1);
  const floor = new Uint8Array(n * n);
  const carve = (x: number, y: number) => { if (inside(x, y)) map[idx(x, y)] = 0; };

  const rects: { x: number; y: number; w: number; h: number }[] = [];
  const rectFree = (x: number, y: number, w: number, h: number, margin: number) =>
    rects.every((r) => x > r.x + r.w + margin || x + w + margin < r.x || y > r.y + r.h + margin || y + h + margin < r.y);

  const placeRooms = (count: number, minS: number, maxS: number, odd: boolean) => {
    for (let a = 0; a < count * 60 && rects.length < count; a++) {
      let w = rng.int(minS, maxS), h = rng.int(minS, maxS);
      if (odd) { w |= 1; h |= 1; }
      let x = rng.int(2, n - w - 3), y = rng.int(2, n - h - 3);
      if (odd) { x |= 1; y |= 1; }
      if (x + w >= n - 1 || y + h >= n - 1) continue;
      if (!rectFree(x, y, w, h, odd ? 1 : 2)) continue;
      rects.push({ x, y, w, h });
    }
  };
  const carveRect = (r: { x: number; y: number; w: number; h: number }) => {
    for (let y = r.y; y < r.y + r.h; y++) for (let x = r.x; x < r.x + r.w; x++) carve(x, y);
  };
  const hline = (xa: number, xb: number, y: number, w: number) => {
    for (let x = Math.min(xa, xb); x <= Math.max(xa, xb); x++) for (let k = 0; k < w; k++) carve(x, y + k);
  };
  const vline = (ya: number, yb: number, x: number, w: number) => {
    for (let y = Math.min(ya, yb); y <= Math.max(ya, yb); y++) for (let k = 0; k < w; k++) carve(x + k, y);
  };
  const connect = (a: number, b: number) => {
    const ra = rects[a], rb = rects[b];
    const ax = ra.x + (ra.w >> 1), ay = ra.y + (ra.h >> 1), bx = rb.x + (rb.w >> 1), by = rb.y + (rb.h >> 1);
    const w = rng.chance(def.wideChance) ? 2 : 1;
    if (rng.chance(0.5)) { hline(ax, bx, ay, w); vline(ay, by, bx, w); } else { vline(ay, by, ax, w); hline(ax, bx, by, w); }
  };

  if (def.layout === "maze") {
    // recursive backtracker on the odd lattice, then braided so there are loops to run around
    const stack: [number, number][] = [[1, 1]];
    carve(1, 1);
    while (stack.length) {
      const [cx, cy] = stack[stack.length - 1];
      const opts = DIRS.filter(([dx, dy]) => inside(cx + dx * 2, cy + dy * 2) && map[idx(cx + dx * 2, cy + dy * 2)] === 1);
      if (!opts.length) { stack.pop(); continue; }
      const [dx, dy] = rng.pick(opts);
      carve(cx + dx, cy + dy);
      carve(cx + dx * 2, cy + dy * 2);
      stack.push([cx + dx * 2, cy + dy * 2]);
    }
    for (let y = 1; y < n - 1; y++) for (let x = 1; x < n - 1; x++) {
      if (map[idx(x, y)] === 0) continue;
      if (((x & 1) ^ (y & 1)) === 0) continue;
      const open = DIRS.filter(([dx, dy]) => map[idx(x + dx, y + dy)] === 0).length;
      if (open >= 2 && rng.chance(0.14)) carve(x, y);
    }
    placeRooms(def.roomCount, def.roomMin, def.roomMax, true);
    rects.forEach(carveRect);
  } else {
    placeRooms(def.roomCount, def.roomMin, def.roomMax, false);
    rects.forEach(carveRect);
    const done = [0];
    const left = rects.map((_, i) => i).slice(1);
    while (left.length) {
      let best = -1, bi = -1, bd = 1e9;
      for (const a of done) for (let k = 0; k < left.length; k++) {
        const b = left[k];
        const d = Math.hypot(rects[a].x - rects[b].x, rects[a].y - rects[b].y);
        if (d < bd) { bd = d; best = a; bi = k; }
      }
      connect(best, left[bi]);
      done.push(left[bi]);
      left.splice(bi, 1);
    }
    for (let i = 0; i < Math.floor(rects.length * 0.5); i++) {
      const a = rng.int(0, rects.length - 1), b = rng.int(0, rects.length - 1);
      if (a !== b) connect(a, b);
    }
  }

  // columns inside the big rooms
  if (def.pillars) {
    for (const r of rects) {
      if (r.w < 7 || r.h < 7) continue;
      for (let px = r.x + 2; px <= r.x + r.w - 3; px += 3) for (let py = r.y + 2; py <= r.y + r.h - 3; py += 3) map[idx(px, py)] = 2;
    }
  }

  const start = { x: rects[0].x + (rects[0].w >> 1), y: rects[0].y + (rects[0].h >> 1) };
  map[idx(start.x, start.y)] = 0;

  // flood from the start; anything unreachable becomes wall
  const dist = new Int32Array(n * n).fill(-1);
  const queue: number[] = [idx(start.x, start.y)];
  dist[queue[0]] = 0;
  for (let qi = 0; qi < queue.length; qi++) {
    const c = queue[qi], cx = c % n, cy = (c / n) | 0;
    for (const [dx, dy] of DIRS) {
      const nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= n || ny >= n) continue;
      const ni = idx(nx, ny);
      if (map[ni] !== 0 || dist[ni] >= 0) continue;
      dist[ni] = dist[c] + 1;
      queue.push(ni);
    }
  }
  for (let i = 0; i < n * n; i++) if (map[i] === 0 && dist[i] < 0) map[i] = 1;

  /* ---------------- rooms ---------------- */
  const rooms: Room[] = rects.map((r) => ({ ...r, type: "", label: "", cells: [], visited: false }));
  const roomOf = new Int16Array(n * n).fill(-1);
  rooms.forEach((r, i) => {
    for (let y = r.y; y < r.y + r.h; y++) for (let x = r.x; x < r.x + r.w; x++) {
      if (map[idx(x, y)] === 0) { r.cells.push(idx(x, y)); roomOf[idx(x, y)] = i; }
    }
  });
  const usable = rooms.map((_, i) => i).filter((i) => rooms[i].cells.length >= 4);
  const roomDist = (i: number) => {
    let b = 1e9;
    for (const c of rooms[i].cells) if (dist[c] >= 0 && dist[c] < b) b = dist[c];
    return b;
  };
  const rd = rooms.map((_, i) => (rooms[i].cells.length ? roomDist(i) : 0));
  const first = usable[0];
  rooms[first].type = "lobby";
  rooms[first].label = LOBBY[def.theme];
  const ordered = usable.filter((i) => i !== first).sort((a, b) => rd[b] - rd[a]);
  const exitRoom = ordered.shift() as number;
  rooms[exitRoom].type = "exit";
  rooms[exitRoom].label = def.task.exitLabel;
  let deviceRoom = -1;
  if (def.task.deviceType !== "none") {
    const pool = ordered.slice(0, 3);
    deviceRoom = rng.pick(pool);
    ordered.splice(ordered.indexOf(deviceRoom), 1);
    rooms[deviceRoom].type = def.task.deviceType;
    rooms[deviceRoom].label = def.task.deviceLabel;
  }
  const labelOf = (t: string) => def.rooms.find((r) => r.type === t)?.label ?? t;
  const rest = rng.shuffle(ordered.slice());
  const farFirst = rest.filter((i) => rd[i] > 8).concat(rest.filter((i) => rd[i] <= 8));
  const itemRoomIds: number[] = [];
  for (let k = 0; k < def.task.count; k++) {
    const i = farFirst.find((r) => !rooms[r].type && !itemRoomIds.includes(r));
    const t = def.task.itemRooms[k % def.task.itemRooms.length];
    if (i === undefined) { itemRoomIds.push(itemRoomIds[k % Math.max(1, itemRoomIds.length)] ?? first); continue; }
    rooms[i].type = t;
    rooms[i].label = labelOf(t);
    itemRoomIds.push(i);
  }
  const weights = def.rooms.flatMap((r) => Array(r.weight).fill(r));
  for (const i of rest) {
    if (rooms[i].type) continue;
    const k = rng.pick(weights);
    rooms[i].type = k.type;
    rooms[i].label = k.label;
  }

  // alternate floors
  rooms.forEach((r) => {
    if (!def.altRooms.includes(r.type)) return;
    const basin = def.altSurface === "water" && r.w >= 6 && r.h >= 6;
    for (const c of r.cells) {
      const x = c % n, y = (c / n) | 0;
      if (basin && !(x > r.x && x < r.x + r.w - 1 && y > r.y && y < r.y + r.h - 1)) continue;
      floor[c] = 1;
    }
  });
  // keep the start dry
  floor[idx(start.x, start.y)] = 0;

  // alternate wall paper around certain rooms
  rooms.forEach((r) => {
    if (!def.wallBRooms.includes(r.type)) return;
    for (let y = r.y - 1; y <= r.y + r.h; y++) for (let x = r.x - 1; x <= r.x + r.w; x++) {
      if (x >= 0 && y >= 0 && x < n && y < n && map[idx(x, y)] === 1) map[idx(x, y)] = 3;
    }
  });
  // type 3 walls = style B (type 2 pillars are style B as well)

  /* ---------------- lamps ---------------- */
  const lamps: Lamp[] = [];
  const lampAt = new Int16Array(n * n).fill(-1);
  const addLamp = (x: number, y: number) => {
    if (map[idx(x, y)] !== 0 || lampAt[idx(x, y)] >= 0) return;
    let mode: Lamp["mode"] = "on";
    if (rng.chance(def.deadChance)) mode = "dead";
    else if (rng.chance(def.flickerChance)) mode = "flicker";
    if (Math.hypot(x - start.x, y - start.y) < 5) mode = "on";
    lampAt[idx(x, y)] = lamps.length;
    lamps.push({ cx: x, cy: y, base: 1, cur: mode === "dead" ? 0 : 1, mode, patch: new Float32Array(0), px: 0, py: 0, pw: 0, ph: 0, flickT: 0, broken: false });
  };
  for (const r of rooms) {
    if (!r.cells.length) continue;
    const s = Math.max(3, def.lampMod);
    const cx = Math.max(1, Math.round(r.w / s)), cy = Math.max(1, Math.round(r.h / s));
    for (let i = 0; i < cx; i++) for (let j = 0; j < cy; j++) {
      const x = r.x + Math.floor(((i + 0.5) * r.w) / cx), y = r.y + Math.floor(((j + 0.5) * r.h) / cy);
      if (map[idx(x, y)] !== 0) { // nudge off pillars
        for (const [dx, dy] of DIRS) if (map[idx(x + dx, y + dy)] === 0 && lampAt[idx(x + dx, y + dy)] < 0) { addLamp(x + dx, y + dy); break; }
      } else addLamp(x, y);
    }
  }
  for (let y = 1; y < n - 1; y++) for (let x = 1; x < n - 1; x++) {
    if (map[idx(x, y)] !== 0 || roomOf[idx(x, y)] >= 0) continue;
    if ((x + y) % (def.lampMod + 1) === 0 && rng.chance(0.85)) addLamp(x, y);
  }

  /* ---------------- wall faces for decals ---------------- */
  const usedFaces = new Set<number>();
  const decals: (Decal[] | undefined)[] = new Array(n * n * 4);
  const addDecal = (cell: number, face: number, art: ReturnType<typeof decalArt>, extra: Partial<Decal> = {}): Decal => {
    const d: Decal = { cell, face, u0: art.u0, u1: art.u1, z0: art.z0, z1: art.z1, tex: art.tex, alt: art.alt, glow: art.glow, kind: art.kind, ...extra };
    const k = cell * 4 + face;
    (decals[k] ||= []).push(d);
    usedFaces.add(k);
    return d;
  };
  const faceCandidates = (cells: number[]) => {
    const out: { cell: number; face: number }[] = [];
    for (const c of cells) {
      const x = c % n, y = (c / n) | 0;
      for (const [dx, dy] of DIRS) {
        const nx = x + dx, ny = y + dy;
        if (!inside(nx, ny) || map[idx(nx, ny)] === 0) continue;
        const key = idx(nx, ny) * 4 + faceFrom(dx, dy);
        if (usedFaces.has(key)) continue;
        out.push({ cell: idx(nx, ny), face: faceFrom(dx, dy) });
      }
    }
    return out;
  };
  const pickFace = (cells: number[]) => {
    const c = faceCandidates(cells);
    return c.length ? rng.pick(c) : null;
  };

  /* ---------------- props ---------------- */
  const props: Prop[] = [];
  const propCells = new Set<number>();
  rooms.forEach((r, ri) => {
    if (r.cells.length < 12 || r.type === "exit") return;
    const kinds = def.roomProps[r.type] ?? def.props;
    const count = Math.round(r.cells.length * def.propDensity * 0.06);
    const cand = rng.shuffle(r.cells.slice());
    let placed = 0;
    for (const c of cand) {
      if (placed >= count) break;
      const x = c % n, y = (c / n) | 0;
      if (floor[c] === 1 && def.altSurface === "water") continue;
      if (Math.hypot(x - start.x, y - start.y) < 2.2) continue;
      if (lampAt[c] >= 0 && rng.chance(0.5)) continue;
      let door = false, wallDx = 0, wallDy = 0;
      for (const [dx, dy] of DIRS) {
        const ni = idx(x + dx, y + dy);
        if (map[ni] === 0 && roomOf[ni] !== ri) door = true;
        if (map[ni] !== 0) { wallDx = dx; wallDy = dy; }
      }
      if (door) continue;
      let near = false;
      for (let dy = -1; dy <= 1 && !near; dy++) for (let dx = -1; dx <= 1; dx++) if (propCells.has(idx(x + dx, y + dy))) { near = true; break; }
      if (near) continue;
      const kind = rng.pick(kinds);
      const sprite = propSprite(kind);
      props.push({ x: x + 0.5 + wallDx * 0.18 + rng.range(-0.08, 0.08), y: y + 0.5 + wallDy * 0.18 + rng.range(-0.08, 0.08), kind, sprite, frame: 0, flip: rng.chance(0.5) });
      propCells.add(c);
      placed++;
    }
  });

  /* ---------------- pickups ---------------- */
  const pickups: Pickup[] = [];
  const freeCell = (room: number, minGap: number) => {
    const cells = rooms[room].cells.filter((c) => floor[c] === 0 || def.altSurface !== "water");
    for (let a = 0; a < 40; a++) {
      const c = rng.pick(cells);
      const x = c % n + 0.5 + rng.range(-0.25, 0.25), y = ((c / n) | 0) + 0.5 + rng.range(-0.25, 0.25);
      if (pickups.some((p) => Math.hypot(p.x - x, p.y - y) < minGap)) continue;
      if (props.some((p) => p.sprite.solid && Math.hypot(p.x - x, p.y - y) < p.sprite.r + 0.2)) continue;
      return { x, y };
    }
    const c = rng.pick(cells);
    return { x: (c % n) + 0.5, y: ((c / n) | 0) + 0.5 };
  };
  const supplyRooms = usable.filter((i) => rooms[i].type !== "lobby" && rooms[i].type !== "exit");
  const addPickup = (kind: PickupKind, room: number) => {
    const p = freeCell(room, 1.5);
    pickups.push({ kind, x: p.x, y: p.y, taken: false, phase: rng.range(0, 6) });
  };
  const nWater = Math.max(2, Math.round(def.water * diff.supply)), nCell = Math.max(2, Math.round(def.cells * diff.supply));
  for (let i = 0; i < nWater; i++) addPickup("water", rng.pick(supplyRooms));
  for (let i = 0; i < nCell; i++) addPickup("cell", rng.pick(supplyRooms));
  // a little something in the lobby, so nobody starts blind
  { const p = freeCell(first, 1); pickups.push({ kind: "cell", x: p.x, y: p.y, taken: false, phase: 1, }); }

  /* ---------------- task furniture ---------------- */
  const devices: Decal[] = [];
  let device: Decal | null = null;
  let code = "";
  const kind = def.task.kind;
  const taskRooms = itemRoomIds.map((i) => (rooms[i] ? i : first));
  if (kind === "power" || kind === "generator") {
    taskRooms.forEach((ri) => addPickup("fuse", ri));
    const f = pickFace(rooms[deviceRoom].cells)!;
    device = addDecal(f.cell, f.face, decalArt(kind === "power" ? "fusebox" : "generator"), { kind: kind === "power" ? "fusebox" : "generator" });
    devices.push(device);
  } else if (kind === "keys") {
    taskRooms.forEach((ri) => addPickup("key", ri));
  } else if (kind === "code") {
    code = String(rng.int(100, 999));
    taskRooms.forEach((ri, i) => {
      const f = pickFace(rooms[ri].cells);
      if (!f) return;
      addDecal(f.cell, f.face, decalArt("note", "code" + i, "code"), { kind: "note", noteId: -2, title: "Dispatch sheet " + (i + 1) + " of 3", text: `Dispatch sheet ${i + 1} of 3.\n\nShutter code, digit ${i + 1}: ${code[i]}\n\n(The other digits are on the other sheets.)` });
    });
    const f = pickFace(rooms[deviceRoom].cells)!;
    device = addDecal(f.cell, f.face, decalArt("keypad"), { kind: "keypad" });
    devices.push(device);
  } else if (kind === "valves") {
    taskRooms.forEach((ri) => {
      const f = pickFace(rooms[ri].cells);
      if (!f) return;
      devices.push(addDecal(f.cell, f.face, decalArt("valve"), { kind: "valve" }));
    });
  }

  // exit
  const ef = pickFace(rooms[exitRoom].cells)!;
  const exit = addDecal(ef.cell, ef.face, decalArt("exit", "", def.theme === "plant" ? "lift" : ""), { kind: "exit" });
  const exitCell = { x: ef.cell % n, y: (ef.cell / n) | 0 };

  /* ---------------- signs, notes, decoration ---------------- */
  for (const ri of usable) {
    const f = pickFace(rooms[ri].cells);
    if (f) addDecal(f.cell, f.face, decalArt("sign", rooms[ri].label), { kind: "sign" });
  }
  { // briefing by the start
    const f = pickFace(rooms[first].cells);
    if (f) addDecal(f.cell, f.face, decalArt("note", "brief"), { kind: "note", noteId: -1, title: "Shift briefing", text: def.briefing });
  }
  const pool = NOTES.map((nt, i) => ({ nt, i })).filter((o) => o.nt.theme === "any" || o.nt.theme === def.theme);
  rng.shuffle(pool);
  for (let k = 0; k < Math.min(def.notes, pool.length); k++) {
    const ri = rng.pick(supplyRooms);
    const f = pickFace(rooms[ri].cells);
    if (f) addDecal(f.cell, f.face, decalArt("note", pool[k].nt.title), { kind: "note", noteId: pool[k].i, title: pool[k].nt.title, text: pool[k].nt.text });
  }
  const GRAF = ["TURN BACK", "IT LISTENS", "NO EXIT", "STAY STILL", "LOOK UP", "DON'T RUN", "ONE MORE"];
  for (const ri of usable) {
    const cnt = rng.int(1, 3);
    for (let k = 0; k < cnt; k++) {
      const f = pickFace(rooms[ri].cells);
      if (!f) continue;
      const name = rng.pick(def.deco);
      const text = name === "graffiti" ? rng.pick(GRAF) : name === "poster" ? rng.pick(["MISSING|Last seen on Level 0. If found, do not talk to them.", "SAFETY|Keep corridors clear. Report all unattended lights.", "NOTICE|The fire drill is cancelled. It has already happened."]) : name === "depth" ? rng.pick(["1.2 m", "1.5 m", "2.0 m", "DEEP"]) : "";
      addDecal(f.cell, f.face, decalArt(name, text), { kind: "deco" });
    }
  }
  const corridorCells: number[] = [];
  for (let i = 0; i < n * n; i++) if (map[i] === 0 && roomOf[i] < 0) corridorCells.push(i);
  for (let k = 0; k < Math.floor(corridorCells.length / 10); k++) {
    const f = pickFace([rng.pick(corridorCells)]);
    if (!f) continue;
    const name = rng.pick(def.deco);
    const text = name === "graffiti" ? rng.pick(GRAF) : name === "depth" ? "1.5 m" : name === "poster" ? "NOTICE|Please keep to the marked path." : "";
    addDecal(f.cell, f.face, decalArt(name, text), { kind: "deco" });
  }

  const spawnCells: number[] = [];
  for (const ri of usable) {
    if (rooms[ri].type === "lobby") continue;
    for (const c of rooms[ri].cells) if (dist[c] > 12) spawnCells.push(c);
  }

  return {
    n, map, floor, rooms, roomOf, lamps, lampAt, props, pickups, decals,
    start: { x: start.x + 0.5, y: start.y + 0.5 },
    exit, exitCell, device, devices,
    explored: new Uint8Array(n * n),
    spawnCells,
    code,
  };
}
