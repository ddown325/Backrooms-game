import type { Level } from "./types";
import type { LevelDef } from "./levels";

/** lightmap texels per map cell. Four is enough once the samples are filtered bilinearly. */
export const LM = 4;

export interface DynLight {
  x: number;
  y: number;
  r: number;
  i: number;
  r0: number;
  g0: number;
  b0: number;
}

function visible(map: Uint8Array, n: number, ax: number, ay: number, bx: number, by: number) {
  let x = Math.floor(ax), y = Math.floor(ay);
  const ex = Math.floor(bx), ey = Math.floor(by);
  if (x === ex && y === ey) return true;
  const dx = bx - ax, dy = by - ay;
  const sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1;
  const tdx = dx !== 0 ? Math.abs(1 / dx) : 1e30, tdy = dy !== 0 ? Math.abs(1 / dy) : 1e30;
  let tmx = dx > 0 ? (x + 1 - ax) * tdx : dx < 0 ? (ax - x) * tdx : 1e30;
  let tmy = dy > 0 ? (y + 1 - ay) * tdy : dy < 0 ? (ay - y) * tdy : 1e30;
  while (x !== ex || y !== ey) {
    if (tmx < tmy) { tmx += tdx; x += sx; } else { tmy += tdy; y += sy; }
    if (x === ex && y === ey) return true;
    if (map[y * n + x] > 0) return false;
  }
  return true;
}

export class Lighting {
  lw: number;
  lm: Float32Array;
  lampCur: Float32Array;
  dyn: DynLight[] = [];
  get lamps() { return this.level.lamps; }
  constructor(public level: Level, public def: LevelDef) {
    this.lw = level.n * LM;
    this.lm = new Float32Array(this.lw * this.lw);
    this.lampCur = new Float32Array(level.n * level.n).fill(-1);
  }

  /** Builds one soft-shadowed patch per lamp, then sums them. Lamps can be changed afterwards by adding a scaled patch. */
  bake() {
    const { level: lv, def } = this;
    const n = lv.n, lw = this.lw, R = def.lampRadius;
    const offs = [[-0.3, -0.3], [0.3, -0.3], [-0.3, 0.3], [0.3, 0.3], [0, 0]];
    for (const l of lv.lamps) {
      const lx = l.cx + 0.5, ly = l.cy + 0.5;
      const x0 = Math.max(0, Math.floor((lx - R) * LM)), x1 = Math.min(lw - 1, Math.ceil((lx + R) * LM));
      const y0 = Math.max(0, Math.floor((ly - R) * LM)), y1 = Math.min(lw - 1, Math.ceil((ly + R) * LM));
      const pw = x1 - x0 + 1, ph = y1 - y0 + 1;
      const patch = new Float32Array(pw * ph);
      const open = new Uint8Array(pw * ph);
      for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
        const wx = (tx + 0.5) / LM, wy = (ty + 0.5) / LM;
        if (lv.map[Math.floor(wy) * n + Math.floor(wx)] > 0) continue;
        const pi = (ty - y0) * pw + (tx - x0);
        open[pi] = 1;
        const d = Math.hypot(wx - lx, wy - ly);
        if (d >= R) continue;
        let vis = 0;
        for (const [ox, oy] of offs) if (visible(lv.map, n, lx + ox, ly + oy, wx, wy)) vis++;
        if (!vis) continue;
        const t = d / R;
        const fall = (1 - t * t) * (1 - t * t);
        patch[pi] = def.lampGain * fall * (0.3 + 0.7 / (1 + 1.4 * d * d)) * (vis / offs.length);
      }
      // wall texels next to lit floor inherit a darker copy so edges stay soft and walls can be sampled
      const copy = patch.slice();
      for (let j = 0; j < ph; j++) for (let i = 0; i < pw; i++) {
        const pi = j * pw + i;
        if (open[pi]) continue;
        let s = 0, c = 0;
        if (i > 0 && open[pi - 1]) { s += copy[pi - 1]; c++; }
        if (i < pw - 1 && open[pi + 1]) { s += copy[pi + 1]; c++; }
        if (j > 0 && open[pi - pw]) { s += copy[pi - pw]; c++; }
        if (j < ph - 1 && open[pi + pw]) { s += copy[pi + pw]; c++; }
        if (c) patch[pi] = (s / c) * 0.75;
      }
      l.patch = patch;
      l.px = x0; l.py = y0; l.pw = pw; l.ph = ph;
      const c = l.cur;
      l.cur = 0;
      this.setLamp(l, c);
    }
  }

  setLamp(l: Level["lamps"][number], v: number) {
    const delta = v - l.cur;
    if (Math.abs(delta) > 1e-4) {
      const { lm, lw } = this;
      const { patch, px, py, pw, ph } = l;
      for (let j = 0; j < ph; j++) {
        let o = (py + j) * lw + px;
        let p = j * pw;
        for (let i = 0; i < pw; i++, o++, p++) lm[o] += patch[p] * delta;
      }
      l.cur = v;
    }
    this.lampCur[l.cy * this.level.n + l.cx] = l.mode === "dead" && v === 0 ? 0 : v;
  }

  sample(x: number, y: number) {
    const lw = this.lw;
    const fx = x * LM - 0.5, fy = y * LM - 0.5;
    let ix = Math.floor(fx), iy = Math.floor(fy);
    const tx = fx - ix, ty = fy - iy;
    if (ix < 0) ix = 0;
    if (iy < 0) iy = 0;
    if (ix > lw - 2) ix = lw - 2;
    if (iy > lw - 2) iy = lw - 2;
    const i = iy * lw + ix, lm = this.lm;
    return (lm[i] * (1 - tx) + lm[i + 1] * tx) * (1 - ty) + (lm[i + lw] * (1 - tx) + lm[i + lw + 1] * tx) * ty;
  }
}
