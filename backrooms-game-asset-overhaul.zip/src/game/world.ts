import type { Level } from "./types";

export const DIRS8: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

export const isWall = (lv: Level, x: number, y: number) => {
  const cx = Math.floor(x), cy = Math.floor(y);
  if (cx < 0 || cy < 0 || cx >= lv.n || cy >= lv.n) return true;
  return lv.map[cy * lv.n + cx] > 0;
};

export interface Hit {
  cell: number;
  face: number;
  dist: number;
  wallX: number;
}
const hit: Hit = { cell: -1, face: 0, dist: 0, wallX: 0 };

/** logic ray against the grid. Returns a shared object, copy it if you need to keep it. */
export function castGrid(lv: Level, px: number, py: number, dx: number, dy: number, maxDist: number): Hit | null {
  const n = lv.n;
  let mx = Math.floor(px), my = Math.floor(py);
  const ddx = dx === 0 ? 1e30 : Math.abs(1 / dx), ddy = dy === 0 ? 1e30 : Math.abs(1 / dy);
  const sx = dx < 0 ? -1 : 1, sy = dy < 0 ? -1 : 1;
  let tx = dx < 0 ? (px - mx) * ddx : (mx + 1 - px) * ddx;
  let ty = dy < 0 ? (py - my) * ddy : (my + 1 - py) * ddy;
  let side = 0;
  for (let i = 0; i < 128; i++) {
    if (tx < ty) { tx += ddx; mx += sx; side = 0; } else { ty += ddy; my += sy; side = 1; }
    if (mx < 0 || my < 0 || mx >= n || my >= n) return null;
    if (lv.map[my * n + mx] > 0) {
      const d = side === 0 ? tx - ddx : ty - ddy;
      if (d > maxDist) return null;
      let wx = side === 0 ? py + d * dy : px + d * dx;
      wx -= Math.floor(wx);
      if (side === 0 && dx > 0) wx = 1 - wx;
      if (side === 1 && dy < 0) wx = 1 - wx;
      hit.cell = my * n + mx;
      hit.face = side === 0 ? (sx > 0 ? 0 : 1) : sy > 0 ? 2 : 3;
      hit.dist = d;
      hit.wallX = wx;
      return hit;
    }
  }
  return null;
}

export function los(lv: Level, ax: number, ay: number, bx: number, by: number): boolean {
  const dx = bx - ax, dy = by - ay;
  const d = Math.hypot(dx, dy);
  if (d < 0.001) return true;
  const h = castGrid(lv, ax, ay, dx / d, dy / d, d);
  return h === null;
}

export function bfs(lv: Level, sx: number, sy: number, allow?: (cell: number) => boolean, maxD = 9999): Int16Array {
  const n = lv.n;
  const f = new Int16Array(n * n).fill(-1);
  const start = Math.floor(sy) * n + Math.floor(sx);
  const q: number[] = [start];
  f[start] = 0;
  for (let i = 0; i < q.length; i++) {
    const c = q[i];
    if (f[c] >= maxD) continue;
    const cx = c % n, cy = (c / n) | 0;
    for (let k = 0; k < 8; k++) {
      const [dx, dy] = DIRS8[k];
      const nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= n || ny >= n) continue;
      const ni = ny * n + nx;
      if (f[ni] >= 0 || lv.map[ni] > 0) continue;
      if (k >= 4 && (lv.map[cy * n + nx] > 0 || lv.map[ny * n + cx] > 0)) continue; // no corner cutting
      if (allow && !allow(ni)) continue;
      f[ni] = f[c] + 1;
      q.push(ni);
    }
  }
  return f;
}

/** best neighbour towards the lowest value of a distance field */
export function nextStep(lv: Level, f: Int16Array, x: number, y: number): [number, number] | null {
  const n = lv.n;
  const cx = Math.floor(x), cy = Math.floor(y);
  const here = f[cy * n + cx];
  if (here < 0) return null;
  let best = here, bx = -1, by = -1;
  for (let k = 0; k < 8; k++) {
    const [dx, dy] = DIRS8[k];
    const nx = cx + dx, ny = cy + dy;
    if (nx < 0 || ny < 0 || nx >= n || ny >= n) continue;
    const v = f[ny * n + nx];
    if (v < 0 || v >= best) continue;
    if (k >= 4 && (lv.map[cy * n + nx] > 0 || lv.map[ny * n + cx] > 0)) continue;
    best = v; bx = nx; by = ny;
  }
  if (bx < 0) return null;
  return [bx + 0.5, by + 0.5];
}

export function blocked(lv: Level, x: number, y: number, r: number): boolean {
  if (isWall(lv, x - r, y - r) || isWall(lv, x + r, y - r) || isWall(lv, x - r, y + r) || isWall(lv, x + r, y + r)) return true;
  for (const p of lv.props) {
    if (!p.sprite.solid) continue;
    const dx = p.x - x, dy = p.y - y;
    const rr = p.sprite.r + r;
    if (dx * dx + dy * dy < rr * rr) return true;
  }
  return false;
}

export function moveCircle(lv: Level, x: number, y: number, dx: number, dy: number, r: number): [number, number] {
  let nx = x, ny = y;
  if (!blocked(lv, x + dx, y, r)) nx = x + dx;
  if (!blocked(lv, nx, y + dy, r)) ny = y + dy;
  return [nx, ny];
}
