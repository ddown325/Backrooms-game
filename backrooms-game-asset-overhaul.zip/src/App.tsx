import { useCallback, useEffect, useRef, useState } from "react";
import { Game, type Phase } from "./game/game";
import { LEVELS } from "./game/levels";
import { EMPTY_RECORDS, saveRecords, type Records, type Settings } from "./game/store";
import { HudView, MapView, useHud } from "./ui/Hud";
import { Archive, Complete, Controls, Dead, Keypad, Levels, Loading, NoteView, Pause, SettingsView, Title } from "./ui/Screens";
import { TouchControls } from "./ui/Touch";

type View = "main" | "levels" | "settings" | "archive" | "controls";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const grainRef = useRef<HTMLDivElement>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [phase, setPhase] = useState<Phase>("menu");
  const [view, setView] = useState<View>("main");
  const [pauseView, setPauseView] = useState<"main" | "settings" | "controls">("main");
  const [diff, setDiff] = useState(1);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [records, setRecords] = useState<Records>(EMPTY_RECORDS);
  const [note, setNote] = useState<{ title: string; text: string } | null>(null);
  const [deadLine, setDeadLine] = useState("");
  const [done, setDone] = useState<{ time: number; level: number; last: boolean } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const touch = typeof window !== "undefined" && window.matchMedia?.("(pointer: coarse)").matches;

  useEffect(() => {
    if (!canvasRef.current) return;
    const g = new Game(canvasRef.current, {
      onPhase: (p) => { setPhase(p); setRecords({ ...g.records }); },
      onNote: (title, text) => setNote({ title, text }),
      onDead: (l) => setDeadLine(l),
      onComplete: (i) => setDone(i),
    });
    setSettings(g.settings);
    setRecords({ ...g.records });
    g.audio.volume = g.settings.volume;
    g.startAttract(0);
    setGame(g);
    return () => g.dispose();
  }, []);

  // film grain tile
  useEffect(() => {
    const c = document.createElement("canvas");
    c.width = c.height = 160;
    const x = c.getContext("2d");
    if (!x || !grainRef.current) return;
    const id = x.createImageData(160, 160);
    for (let i = 0; i < id.data.length; i += 4) {
      const v = Math.random() * 255;
      id.data[i] = id.data[i + 1] = id.data[i + 2] = v;
      id.data[i + 3] = 255;
    }
    x.putImageData(id, 0, 0);
    grainRef.current.style.backgroundImage = `url(${c.toDataURL()})`;
  }, []);

  const hud = useHud(game, phase === "playing");

  const begin = useCallback((lvl: number) => {
    if (!game) return;
    game.audio.init();
    setBusy(`${LEVELS[lvl].sub} · ${LEVELS[lvl].name}`);
    setDone(null);
    setTimeout(() => {
      game.start(lvl, diff);
      game.requestLock();
      setBusy(null);
      setView("main");
      setPauseView("main");
    }, 70);
  }, [game, diff]);

  const toTitle = () => {
    if (!game) return;
    game.startAttract(0);
    setView("main");
    setDone(null);
  };

  const changeSettings = (s: Settings) => {
    setSettings(s);
    game?.applySettings(s);
  };

  const coh = hud ? hud.coh : 100;
  const v = hud ? Math.min(0.92, 0.4 + (1 - coh / 100) * 0.45 + hud.dark * 0.12 + hud.danger * 0.22) : 0.5;
  const sat = phase === "playing" ? 0.35 + 0.65 * Math.min(1, coh / 70) : 1;
  const grain = settings ? settings.grain * 0.35 : 0.2;

  return (
    <div
      onPointerDownCapture={() => game?.audio.init()}
      onClickCapture={(e) => { if ((e.target as HTMLElement).closest("button")) game?.audio.click(); }}
      style={{ ["--v" as string]: v, ["--grain" as string]: grain } as React.CSSProperties}
    >
      <canvas ref={canvasRef} className="view" style={{ filter: `saturate(${sat.toFixed(2)})` }} />
      <div className="fx vignette" />
      <div className="fx lines" />
      <div ref={grainRef} className="fx grain" />
      {hud ? <div className="fx hurt" style={{ opacity: Math.min(0.55, hud.hurt * 0.55) }} /> : null}

      {phase === "playing" && hud ? <HudView h={hud} showFps={!!settings?.showFps} /> : null}
      {phase === "playing" && hud?.mapOpen && game ? <MapView game={game} /> : null}
      {phase === "playing" && touch && game ? <TouchControls game={game} /> : null}

      {phase === "menu" && !busy && settings ? (
        view === "main" ? <Title diff={diff} setDiff={setDiff} onBegin={() => begin(0)} onGo={(s) => setView(s as View)} hasProgress={records.runs > 0} />
        : view === "levels" ? <Levels records={records} onPick={begin} onBack={() => setView("main")} />
        : view === "settings" ? <SettingsView s={settings} onChange={changeSettings} onBack={() => setView("main")} />
        : view === "archive" ? <Archive records={records} onBack={() => setView("main")} onErase={() => { const r = { ...EMPTY_RECORDS, cleared: [], best: {}, notes: [] }; if (game) game.records = r; saveRecords(r); setRecords(r); }} />
        : <Controls onBack={() => setView("main")} />
      ) : null}

      {phase === "paused" && game && settings ? (
        pauseView === "main" ? (
          <Pause
            onResume={() => game.resume()}
            onSettings={() => setPauseView("settings")}
            onControls={() => setPauseView("controls")}
            onMap={() => { game.mapOpen = true; game.resume(); }}
            onQuit={toTitle}
          />
        ) : pauseView === "settings" ? <SettingsView s={settings} onChange={changeSettings} onBack={() => setPauseView("main")} />
        : <Controls onBack={() => setPauseView("main")} />
      ) : null}

      {phase === "note" && note && game ? <NoteView title={note.title} text={note.text} onClose={() => game.closeOverlay()} /> : null}
      {phase === "keypad" && game ? <Keypad onSubmit={(c) => game.submitCode(c)} onClose={() => game.closeOverlay()} /> : null}
      {phase === "dead" && game ? <Dead line={deadLine} onRetry={() => begin(game.levelIdx)} onQuit={toTitle} /> : null}
      {phase === "complete" && done ? <Complete info={done} onNext={() => begin(done.level + 1)} onQuit={toTitle} /> : null}
      {busy ? <Loading name={busy} /> : null}
    </div>
  );
}
