import { useEffect, useRef, useState } from "react";
import type { Game, Hud } from "../game/game";
import { pad2 } from "../game/util";

export type HudSnap = Hud & { mapOpen: boolean };

export function useHud(game: Game | null, active: boolean) {
  const [h, setH] = useState<HudSnap | null>(null);
  useEffect(() => {
    if (!game || !active) return;
    const id = setInterval(() => setH({ ...game.hud, tasks: game.hud.tasks, mapOpen: game.mapOpen }), 100);
    return () => clearInterval(id);
  }, [game, active]);
  return h;
}

const fmt = (t: number) => `${pad2(t / 60)}:${pad2(t % 60)}`;

export function HudView({ h, showFps }: { h: HudSnap; showFps: boolean }) {
  const lowCoh = h.coh < 35;
  return (
    <div className="fixed inset-0 pointer-events-none osd">
      {/* top left: camcorder stamp and tasks */}
      <div style={{ position: "absolute", left: 22, top: 18, maxWidth: 360 }}>
        <div>
          <span className="rec-dot">●</span> REC <span className="dim">&nbsp;{h.levelSub}</span> <span className="dim">&nbsp;{fmt(h.time)}</span>
        </div>
        <div style={{ marginTop: 14 }}>
          {h.tasks.map((t, i) => (
            <div key={i} style={{ marginBottom: 4 }}>
              <div className={`task ${t.state}`}>
                <span>{t.state === "done" ? "[x]" : t.state === "active" ? "[>]" : "[ ]"}</span>
                <span>
                  {t.text}
                  {t.progress ? <span className="dim"> {t.progress}</span> : null}
                </span>
              </div>
              {t.hint ? <div className="dim" style={{ marginLeft: 30, fontStyle: "italic" }}>{t.hint}</div> : null}
              {t.state === "active" && h.code ? <div style={{ marginLeft: 30 }}>code: {h.code}</div> : null}
            </div>
          ))}
        </div>
      </div>

      {showFps ? <div style={{ position: "absolute", right: 22, top: 18 }} className="dim">{h.fps} fps</div> : null}

      {/* bottom left: vitals */}
      <div style={{ position: "absolute", left: 22, bottom: 20 }}>
        <Bar label="coherence" v={h.coh} low={lowCoh} />
        <Bar label="stamina" v={h.stamina} low={h.stamina < 20} />
        <Bar label="noise" v={h.noise * 100} low={h.noise > 0.7} />
        <div className="dim" style={{ marginTop: 8 }}>
          water {h.water} &nbsp; cells {h.cells}
          {h.fuses > 0 ? <> &nbsp; fuses {h.fuses}</> : null}
          {h.keys > 0 ? <> &nbsp; keys {h.keys}</> : null}
        </div>
      </div>

      {/* bottom right: torch */}
      <div style={{ position: "absolute", right: 22, bottom: 20, textAlign: "right" }}>
        <div className={h.torchOn ? "" : "dim"}>torch {h.torchOn ? "on" : "off"} · {Math.round(h.battery)}%</div>
        <div className="faint">F light · 1 drink · M plan</div>
      </div>

      {/* centre: crosshair, prompt, message */}
      <div style={{ position: "absolute", left: "50%", top: "50%", width: 3, height: 3, marginLeft: -1, marginTop: -1, background: "rgba(232,227,207,0.7)", borderRadius: 2 }} />
      <div style={{ position: "absolute", left: 0, right: 0, bottom: "20%", textAlign: "center" }}>
        {h.message ? <div key={h.msgId} className="msg" style={{ marginBottom: 12, padding: "0 20px" }}>{h.message}</div> : null}
        {h.prompt ? (
          <div>
            <span className="dim">[E]</span> {h.prompt}
            {h.hold > 0 ? (
              <div style={{ margin: "7px auto 0", width: 130 }} className="meter"><i style={{ width: `${h.hold * 100}%` }} /></div>
            ) : null}
          </div>
        ) : null}
      </div>
    </div>
  );
}

function Bar({ label, v, low }: { label: string; v: number; low?: boolean }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 5 }}>
      <span className="dim" style={{ width: 78 }}>{label}</span>
      <div className={`meter ${low ? "low" : ""}`}><i style={{ width: `${Math.max(0, Math.min(100, v))}%` }} /></div>
    </div>
  );
}

export function MapView({ game }: { game: Game }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const c = ref.current;
      if (c) game.drawMap(c.getContext("2d") as CanvasRenderingContext2D, c.width);
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [game]);
  return (
    <div className="fixed inset-0 flex items-center justify-center pointer-events-none" style={{ background: "rgba(0,0,0,0.45)" }}>
      <div>
        <canvas ref={ref} width={560} height={560} style={{ width: "min(80vh, 90vw)", height: "min(80vh, 90vw)", border: "1px solid #3a372c" }} />
        <div className="osd dim" style={{ marginTop: 8 }}>Floor plan. Only what you have seen is drawn. Yellow marks are task locations you have found. M to close.</div>
      </div>
    </div>
  );
}
