import { useRef } from "react";
import type { Game } from "../game/game";

export function TouchControls({ game }: { game: Game }) {
  const origin = useRef<{ id: number; x: number; y: number } | null>(null);
  const lookId = useRef<{ id: number; x: number; y: number } | null>(null);

  const down = (e: React.TouchEvent) => {
    for (const t of Array.from(e.changedTouches)) {
      if (t.clientX < window.innerWidth * 0.45 && !origin.current) origin.current = { id: t.identifier, x: t.clientX, y: t.clientY };
      else if (t.clientX >= window.innerWidth * 0.45 && !lookId.current) lookId.current = { id: t.identifier, x: t.clientX, y: t.clientY };
    }
  };
  const move = (e: React.TouchEvent) => {
    for (const t of Array.from(e.changedTouches)) {
      const o = origin.current;
      if (o && o.id === t.identifier) {
        game.touch.mx = Math.max(-1, Math.min(1, (t.clientX - o.x) / 50));
        game.touch.my = Math.max(-1, Math.min(1, (t.clientY - o.y) / 50));
      }
      const l = lookId.current;
      if (l && l.id === t.identifier) {
        game.look((t.clientX - l.x) * 1.6, (t.clientY - l.y) * 1.6);
        l.x = t.clientX; l.y = t.clientY;
      }
    }
  };
  const up = (e: React.TouchEvent) => {
    for (const t of Array.from(e.changedTouches)) {
      if (origin.current?.id === t.identifier) { origin.current = null; game.touch.mx = 0; game.touch.my = 0; }
      if (lookId.current?.id === t.identifier) lookId.current = null;
    }
  };
  return (
    <div className="fixed inset-0" style={{ touchAction: "none" }} onTouchStart={down} onTouchMove={move} onTouchEnd={up} onTouchCancel={up}>
      <button className="touchbtn" style={{ right: 24, bottom: 96 }} onTouchStart={(e) => { e.stopPropagation(); game.pressUse(true); }} onTouchEnd={(e) => { e.stopPropagation(); game.pressUse(false); }}>use</button>
      <button className="touchbtn" style={{ right: 96, bottom: 40 }} onTouchStart={(e) => { e.stopPropagation(); game.toggleTorch(); }}>light</button>
      <button className="touchbtn" style={{ right: 96, bottom: 112, width: 46, height: 46 }} onTouchStart={(e) => { e.stopPropagation(); game.drink(); }}>drink</button>
      <button className="touchbtn" style={{ right: 20, top: 20, width: 42, height: 42 }} onTouchStart={(e) => { e.stopPropagation(); game.pause(); }}>II</button>
      <button className="touchbtn" style={{ right: 70, top: 20, width: 42, height: 42 }} onTouchStart={(e) => { e.stopPropagation(); game.mapOpen = !game.mapOpen; }}>map</button>
    </div>
  );
}
