import { useEffect, useState, type ReactNode } from "react";
import { DIFFICULTIES, LEVELS, NOTES, END_LINES } from "../game/levels";
import { DEFAULT_SETTINGS, type Records, type Settings } from "../game/store";
import { pad2 } from "../game/util";

const fmt = (t: number) => `${pad2(t / 60)}:${pad2(t % 60)}`;

export function Back({ onClick, label = "Back" }: { onClick: () => void; label?: string }) {
  return <button className="linkbtn" style={{ marginTop: 28 }} onClick={onClick}>{label}</button>;
}

export function Shell({ children, clear }: { children: ReactNode; clear?: boolean }) {
  return (
    <div className={`screen ${clear ? "clear" : ""}`}>
      <div className="col">{children}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ title */
export function Title({ diff, setDiff, onBegin, onGo, hasProgress }: { diff: number; setDiff: (d: number) => void; onBegin: () => void; onGo: (s: string) => void; hasProgress: boolean }) {
  return (
    <Shell clear>
      <div className="kicker">● REC &nbsp; tape 04 &nbsp; do not copy</div>
      <h1 className="title-main">Backrooms</h1>
      <div className="tagline">You have been here before.</div>
      <div className="menu">
        <button className="primary" onClick={onBegin}>{hasProgress ? "New shift" : "Begin"}</button>
        <button onClick={() => onGo("levels")}>Level select</button>
        <button onClick={() => onGo("archive")}>Archive</button>
        <button onClick={() => onGo("settings")}>Settings</button>
        <button onClick={() => onGo("controls")}>Controls</button>
      </div>
      <div style={{ marginTop: 34, fontSize: 14 }} className="dim">
        difficulty &nbsp;
        {DIFFICULTIES.map((d, i) => (
          <button key={d.id} onClick={() => setDiff(i)} style={{ background: "none", border: 0, font: "inherit", cursor: "pointer", marginRight: 14, color: i === diff ? "var(--ink)" : "var(--faint)", textDecoration: i === diff ? "underline" : "none", textUnderlineOffset: 4 }}>
            {d.name.toLowerCase()}
          </button>
        ))}
        <div className="faint" style={{ marginTop: 6 }}>{DIFFICULTIES[diff].desc}</div>
      </div>
      <div className="faint" style={{ position: "fixed", left: "7vw", bottom: 22, fontSize: 12 }}>Headphones help. Everything here is listening too.</div>
    </Shell>
  );
}

/* ------------------------------------------------------------------ levels */
export function Levels({ records, onPick, onBack }: { records: Records; onPick: (i: number) => void; onBack: () => void }) {
  return (
    <Shell>
      <h2 className="h">Levels</h2>
      {LEVELS.map((l, i) => (
        <button key={l.id} className="lvl" onClick={() => onPick(i)}>
          <span className="n">{i}</span>
          <span>
            <div className="name">{l.name}</div>
            <div className="faint" style={{ fontSize: 13, marginTop: 3 }}>{taskBlurb(i)}</div>
          </span>
          <span className="faint" style={{ fontSize: 13, textAlign: "right" }}>
            {records.cleared.includes(i) ? <>cleared<br />{records.best[String(i)] ? fmt(records.best[String(i)]) : ""}</> : ""}
          </span>
        </button>
      ))}
      <Back onClick={onBack} />
    </Shell>
  );
}

function taskBlurb(i: number) {
  return ["Restore the power. Three fuses, one breaker panel.", "Find the dispatch sheets, key in the shutter code.", "Open three steam valves by hand. They are loud.", "Find two keys. Stay out of the water.", "Fit two fuses and start the generator. It is loud."][i];
}

/* ------------------------------------------------------------------ settings */
export function SettingsView({ s, onChange, onBack }: { s: Settings; onChange: (s: Settings) => void; onBack: () => void }) {
  const slider = (key: keyof Settings, label: string, min: number, max: number, step: number, f: (v: number) => string) => (
    <div className="row">
      <span>{label}</span>
      <span style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <input type="range" min={min} max={max} step={step} value={s[key] as number} onChange={(e) => onChange({ ...s, [key]: Number(e.target.value) })} />
        <span className="v">{f(s[key] as number)}</span>
      </span>
    </div>
  );
  const toggle = (key: keyof Settings, label: string) => (
    <div className="row" style={{ cursor: "pointer" }} onClick={() => onChange({ ...s, [key]: !s[key] })}>
      <span>{label}</span>
      <span><span className={`check ${s[key] ? "on" : ""}`} /></span>
    </div>
  );
  return (
    <Shell>
      <h2 className="h">Settings</h2>
      {slider("sens", "Look sensitivity", 0.3, 2.5, 0.05, (v) => v.toFixed(2))}
      {slider("volume", "Volume", 0, 1, 0.05, (v) => Math.round(v * 100) + "%")}
      {slider("brightness", "Brightness", 0.7, 1.7, 0.05, (v) => v.toFixed(2))}
      {slider("fov", "Field of view", 60, 100, 1, (v) => v + "°")}
      {slider("bob", "Head bob", 0, 1.5, 0.05, (v) => Math.round(v * 100) + "%")}
      {slider("grain", "Film grain", 0, 1, 0.05, (v) => Math.round(v * 100) + "%")}
      {toggle("invertY", "Invert look Y")}
      {toggle("showFps", "Show frame rate")}
      <div style={{ display: "flex", gap: 28 }}>
        <Back onClick={onBack} />
        <button className="linkbtn" style={{ marginTop: 28 }} onClick={() => onChange({ ...DEFAULT_SETTINGS })}>Reset</button>
      </div>
    </Shell>
  );
}

/* ------------------------------------------------------------------ archive */
export function Archive({ records, onBack, onErase }: { records: Records; onBack: () => void; onErase: () => void }) {
  const found = NOTES.map((n, i) => ({ n, i })).filter((o) => records.notes.includes(o.i));
  return (
    <Shell>
      <h2 className="h">Archive</h2>
      <div className="row"><span>Shifts started</span><span className="v">{records.runs}</span></div>
      <div className="row"><span>Levels escaped</span><span className="v">{records.escapes}</span></div>
      <div className="row"><span>Times lost</span><span className="v">{records.deaths}</span></div>
      <div className="row"><span>Contacts with something</span><span className="v">{records.encounters}</span></div>
      <div className="row"><span>Notes found</span><span className="v">{found.length}/{NOTES.length}</span></div>
      <div style={{ marginTop: 26 }}>
        {found.length === 0 ? <div className="faint">Nothing yet. Notes are pinned to walls inside rooms.</div> : null}
        {found.map(({ n, i }) => (
          <div key={i} style={{ marginBottom: 20 }}>
            <div className="dim" style={{ fontSize: 12 }}>{n.title}{n.theme !== "any" ? ` · ${LEVELS.find((l) => l.theme === n.theme)?.sub}` : ""}</div>
            <div style={{ fontSize: 14, lineHeight: 1.55, marginTop: 4 }}>{n.text}</div>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", gap: 28 }}>
        <Back onClick={onBack} />
        <button className="linkbtn" style={{ marginTop: 28 }} onClick={onErase}>Erase file</button>
      </div>
    </Shell>
  );
}

/* ------------------------------------------------------------------ controls */
export function Controls({ onBack }: { onBack: () => void }) {
  const rows: [string, string][] = [
    ["W A S D", "Move"],
    ["Mouse", "Look"],
    ["Shift", "Sprint. Fast, and the loudest thing you can do."],
    ["Ctrl or C", "Creep. Slow and almost silent."],
    ["E, Space or click", "Use. Hold for valves and the generator."],
    ["F or right click", "Torch. Costs charge, hurts some things for a moment."],
    ["1 or Q", "Drink almond water"],
    ["M or Tab", "Floor plan"],
    ["Esc", "Pause"],
  ];
  return (
    <Shell>
      <h2 className="h">Controls</h2>
      {rows.map(([k, v]) => (
        <div className="row" key={k}><span>{k}</span><span className="dim" style={{ textAlign: "right" }}>{v}</span></div>
      ))}
      <div className="dim" style={{ marginTop: 24, lineHeight: 1.65, fontSize: 14 }}>
        Monsters hunt by sound and by sight. Watch the noise bar: the louder it is, the further away they hear you.
        Lights keep you steady and the dark wears you down. Read the walls: notes tell you where things are.
      </div>
      <Back onClick={onBack} />
    </Shell>
  );
}

/* ------------------------------------------------------------------ in game overlays */
export function Pause({ onResume, onSettings, onControls, onQuit, onMap }: { onResume: () => void; onSettings: () => void; onControls: () => void; onQuit: () => void; onMap: () => void }) {
  return (
    <Shell>
      <h2 className="h">Paused</h2>
      <div className="menu">
        <button className="primary" onClick={onResume}>Resume</button>
        <button onClick={onMap}>Floor plan</button>
        <button onClick={onSettings}>Settings</button>
        <button onClick={onControls}>Controls</button>
        <button onClick={onQuit}>Leave the building</button>
      </div>
    </Shell>
  );
}

export function NoteView({ title, text, onClose }: { title: string; text: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.6)" }} onClick={onClose}>
      <div className="paper">
        <h3>{title}</h3>
        {text}
        <div style={{ marginTop: 20, fontSize: 12, opacity: 0.6 }}>E to put it back</div>
      </div>
    </div>
  );
}

export function Keypad({ onSubmit, onClose }: { onSubmit: (c: string) => boolean; onClose: () => void }) {
  const [code, setCode] = useState("");
  const [bad, setBad] = useState(false);
  const press = (d: string) => { setBad(false); setCode((c) => (c.length < 3 ? c + d : c)); };
  const submit = (c: string) => {
    if (c.length < 3) return;
    if (!onSubmit(c)) { setBad(true); setTimeout(() => { setBad(false); setCode(""); }, 450); }
  };
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (/^\d$/.test(e.key)) press(e.key);
      else if (e.key === "Backspace") setCode((c) => c.slice(0, -1));
      else if (e.key === "Enter") submit(code);
      else if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });
  return (
    <div className="fixed inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.6)" }}>
      <div>
        <div className="keypad">
          <div className={`disp ${bad ? "bad" : ""}`}>{code.padEnd(3, "·")}</div>
          <div className="keys">
            {["1", "2", "3", "4", "5", "6", "7", "8", "9", "<", "0", "OK"].map((k) => (
              <button key={k} onClick={() => (k === "<" ? setCode((c) => c.slice(0, -1)) : k === "OK" ? submit(code) : press(k))}>{k}</button>
            ))}
          </div>
        </div>
        <button className="linkbtn" style={{ marginTop: 14 }} onClick={onClose}>Step away</button>
      </div>
    </div>
  );
}

export function Dead({ line, onRetry, onQuit }: { line: string; onRetry: () => void; onQuit: () => void }) {
  return (
    <div className="screen" style={{ background: "rgba(10,0,0,0.88)" }}>
      <div className="col" style={{ alignSelf: "center" }}>
        <h2 className="h" style={{ fontSize: 44 }}>Signal lost</h2>
        <div className="dim" style={{ fontFamily: "Georgia, serif", fontStyle: "italic", fontSize: 18, marginBottom: 34 }}>{line}</div>
        <div className="menu">
          <button className="primary" onClick={onRetry}>Try again</button>
          <button onClick={onQuit}>Title</button>
        </div>
      </div>
    </div>
  );
}

export function Complete({ info, onNext, onQuit }: { info: { time: number; level: number; last: boolean }; onNext: () => void; onQuit: () => void }) {
  const l = LEVELS[info.level];
  return (
    <div className="screen">
      <div className="col" style={{ alignSelf: "center" }}>
        <div className="kicker">{l.sub} · {fmt(info.time)}</div>
        <h2 className="h" style={{ fontSize: 44 }}>{info.last ? "Out" : "Through"}</h2>
        <div className="dim" style={{ fontFamily: "Georgia, serif", fontSize: 18, lineHeight: 1.6, marginBottom: 34 }}>
          {info.last ? END_LINES[0] : `You leave ${l.name}. The next floor is already humming.`}
        </div>
        <div className="menu">
          {info.last ? null : <button className="primary" onClick={onNext}>Go down to {LEVELS[info.level + 1].sub}</button>}
          <button className={info.last ? "primary" : ""} onClick={onQuit}>Title</button>
        </div>
      </div>
    </div>
  );
}

export function Loading({ name }: { name: string }) {
  return (
    <div className="screen" style={{ background: "#000", alignItems: "center", justifyContent: "center" }}>
      <div className="dim">{name}</div>
    </div>
  );
}
